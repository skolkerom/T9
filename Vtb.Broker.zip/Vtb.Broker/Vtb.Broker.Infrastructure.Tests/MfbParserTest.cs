﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Vtb.Broker.Infrastructure.FileDetector;
using Vtb.Broker.Infrastructure.FileDetector.Parsers.RiskRates;

namespace Vtb.Broker.Infrastructure.Tests
{
    [TestClass]
    public class MfbParserTest
    {
        [TestMethod]
        public void ParseNewMfbFileTest()
        {
            var parser = new MfbParser();
            var riskRates = parser.Parse(new NewFileMessage { Path = @"Files\Mfb\BloomRates-20191218-566.xml", FileName = "BloomRates-20191218-566.xml"});
            
            Assert.AreEqual(2, riskRates.Length);
            
            var chevronRate = riskRates[0];
            Assert.AreEqual(new { Isin = "US1667641005", RateLong = 0.0675m, RateShort = 0.0675m, RateDate = new DateTime(2019,10,15)}, 
                new {chevronRate.Isin, chevronRate.RateLong, chevronRate.RateShort, chevronRate.RateDate });

            var ciscoRate = riskRates[1];
            Assert.AreEqual(new { Isin = "US17275R1023", RateLong = 0.07m, RateShort = 0.0675m, RateDate = new DateTime(2019,11,19)}, 
                new {ciscoRate.Isin, ciscoRate.RateLong, ciscoRate.RateShort, ciscoRate.RateDate });
        }

        [TestMethod]
        public void ParseMfbFileTest()
        {
            var parser = new MfbParser();
            var riskRates = parser.Parse(new NewFileMessage { Path = @"Files\Mfb\rates-20191230_192100.xml", FileName = "rates-20191230_192100.xml"});
            
            Assert.AreEqual(2, riskRates.Length);
            
            var appleRate = riskRates[0];
            Assert.AreEqual(new { Isin = "US0378331005", RateLong = 0.09m, RateShort = 0.09m, RateDate = new DateTime(2019,10,31)}, 
                new {appleRate.Isin, appleRate.RateLong, appleRate.RateShort, appleRate.RateDate });

            var abodeRate = riskRates[1];
            Assert.AreEqual(new { Isin = "US00724F1012", RateLong = 0.085m, RateShort = 0.085m, RateDate = new DateTime(2019,12,19)}, 
                new {abodeRate.Isin, abodeRate.RateLong, abodeRate.RateShort, abodeRate.RateDate });
        }
    }
}