using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities.Interfaces
{
    public interface IHistoryService    
    {
        Task<TEntity[]> GetHistory<TEntity>(long id)
            where TEntity : class, IEntity;
    } 
}
