namespace Vtb.Broker.Domain.Entities.Interfaces
{
    public interface IUserService
    {
        User GetUser(string login);
    }
}
