using System.Threading.Tasks;

namespace Vtb.Broker.Domain.Entities.Interfaces
{
    public interface ICurrentUserProvider
    {
        User GetCurrentUser();
    }
}
