﻿using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution
{
    public class OvernightDistributionCurrencyPositionAggregate
    {
        [DisplayName("Валюта")]
        public string Currency { get; set; }

        [DisplayName("Позиция на начало")]
        public decimal PositionStart { get; set; }

        [DisplayName("Позиция на конец")]
        public decimal PositionEnd { get; set; }
        
        [DisplayName("Комиссия РЕПО 1")]
        public decimal CommissionRepo1 { get; set; }
        
        [DisplayName("Комиссия РЕПО 2")]
        public decimal CommissionRepo2 { get; set; }

        [DisplayName("Комиссия всего")] 
        public decimal Commission => CommissionRepo1 + CommissionRepo2;
    }
}