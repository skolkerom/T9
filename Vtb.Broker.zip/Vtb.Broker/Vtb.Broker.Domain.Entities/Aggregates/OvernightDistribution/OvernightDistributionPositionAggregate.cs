﻿using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution
{
    public class OvernightDistributionPositionAggregate
    {
        [DisplayName("Код инструмента")]
        public string InstrumentCode { get; set; }
        
        [DisplayName("Валюта")]
        public string Currency { get; set; }

        [DisplayName("Позиция на начало")]
        public decimal PositionStart { get; set; }

        [DisplayName("Позиция на конец")]
        public decimal PositionEnd { get; set; }
    }
}