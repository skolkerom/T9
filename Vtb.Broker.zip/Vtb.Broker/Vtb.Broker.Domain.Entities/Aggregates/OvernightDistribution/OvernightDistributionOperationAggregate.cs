﻿using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution
{
    public class OvernightDistributionOperationAggregate
    {

        [DisplayName("Код инструмента пер.")]
        public string BaseInstrumentCode { get; set; }
        
        [DisplayName("Курс пер.")]
        public decimal BaseInstrumentFX { get; set; }

        [DisplayName("Код инструмента")]
        public string InstrumentCode { get; set; }

        [DisplayName("Код валюты")]
        public string Currency { get; set; }
        
        [DisplayName("Тип операции")]
        public OvernightDistributionOperationType OperationType { get; set; }
        
        [DisplayName("Тип инструмента")]
        public OvernightDistributionInstrumentType InstrumentType { get; set; }

        [DisplayName("Курс")]
        public decimal FX { get; set; }

        [DisplayName("Количество")]
        public decimal Quantity { get; set; }

        [DisplayName("Комиссия РЕПО 1")]

        public decimal CommissionRepo1 { get; set; }

        [DisplayName("Комиссия РЕПО 2")]

        public decimal CommissionRepo2 { get; set; }
    }
}