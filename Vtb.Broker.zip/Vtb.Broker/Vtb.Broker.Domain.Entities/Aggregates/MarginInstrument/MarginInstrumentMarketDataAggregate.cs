﻿using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities.Aggregates.MarginInstrument
{
    public class MarginInstrumentReestrAggregate : Entities.MarginInstrument 
    {
        [DisplayName("Цена закрытия")]
        public decimal? ClosePrice { get; set; }
        
        [DisplayName("Размер лота")]
        public int LotSize { get; set; }
        
        [DisplayName("Short разрешен")]
        public bool IsShort { get; set; }
        
        [DisplayName("Long разрешен")]
        public bool IsLong { get; set; }
        
        [DisplayName("Лимит Short в лотах")]
        public long? ShortLimitInLots => (int?) (ShortLimit / ClosePrice / LotSize * (1 - Discount));
    }
}