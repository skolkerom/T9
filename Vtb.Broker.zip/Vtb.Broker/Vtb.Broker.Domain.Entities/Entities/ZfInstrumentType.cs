using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("v_zfront_instrument_type", Schema = "rm")]
    public class ZfInstrumentType
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("type_id")]
        public int Id { get; set; }
        [Column("short_type")]
        public string ShortName{ get; set; }
    }
}