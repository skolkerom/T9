using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{

    [Table("RiskCategory", Schema = "rm")]
    [Historable(typeof(RiskCategoryHistory))]
    [Audit(AuditActionType.RiskCategoryEdit)]
    public class RiskCategory : IEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [DisplayName("ID")]
        public long Id { get; set; }

        [DisplayName("Код")]
        [Required(ErrorMessage = "Код не заполнен")]
        [MaxLength(30)]
        public string Code { get; set; }

        [DisplayName("Наименование")]
        [Required(ErrorMessage = "Наименование не заполнено")]
        public string Name { get; set; }

        [DisplayName("Маркетплейс")]
        public List<RiskCategoryMarketplace> Marketplaces { get; set; } = new List<RiskCategoryMarketplace>();

        [DisplayName("Принцип формирования")]
        public FormingPrinciple FormingPrinciple { get; set; }

        [DisplayName("Коэф.")]
        [DefaultDecimalColumn]
        public decimal Rate { get; set; }

        [DisplayName("КВАЛ")]
        public QualifiedInvestor QualifiedInvestor { get; set; }

        [DisplayName("ИИС")]
        public IndividualInvestmentAccount IndividualInvestmentAccount { get; set; }

        [DisplayName("Базовая категория")]
        [Range(1, int.MaxValue, ErrorMessage = "Выберите базовую категорию")]
        public long BaseRiskCategoryId { get; set; }

        [DisplayName("Базовая категория")]
        public BaseRiskCategory BaseRiskCategory { get; set; }

        [Required(ErrorMessage = "Шаблон QUIK не заполнен")]
        [DisplayName("Шаблон QUIK")]
        public string QuikTemplate { get; set; }
        [Required]
        [DisplayName("Создал")]
        public string CreatedUser { get; set; }

        [Required]
        [DisplayName("Дата создания")]
        public DateTime CreatedDate { get; set; }

        [Required]
        [DisplayName("Изменил")]
        public string ModifiedUser { get; set; }

        [Required]
        [DisplayName("Дата изменения")]
        public DateTime ModifiedDate { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }

        [DisplayName("Удалена")]
        public bool IsDeleted { get; set; }
        
        [DisplayName("Список ЦБ")]
        public MarginInstrumentList MarginInstrumentList { get; set; }
        [DisplayName("Список ЦБ")]
        public long? MarginInstrumentListId { get; set; }

        public string Comment { get; set; }
        
        public long? QuikLeverageId { get; set; }

        public override string ToString()
        {
            return $"Id = {Id}, Код = {Code}, Наименование = {Name}";
        }
    }
}
