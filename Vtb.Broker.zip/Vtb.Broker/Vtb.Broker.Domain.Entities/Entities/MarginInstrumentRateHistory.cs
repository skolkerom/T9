﻿using System;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    public class MarginInstrumentRateHistory : IHistory
    {
        public long Id { get; set; }
        public DateTime ModifiedDate { get; set; }
        public long EntityId { get; set; }
    }
}