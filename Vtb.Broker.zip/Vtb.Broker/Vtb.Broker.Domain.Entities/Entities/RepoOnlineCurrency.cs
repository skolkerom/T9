﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RepoOnlineCurrency", Schema = "rm")]
    public class RepoOnlineCurrency
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string Currency { get; set; }
        public decimal Position { get; set; }
    }
}