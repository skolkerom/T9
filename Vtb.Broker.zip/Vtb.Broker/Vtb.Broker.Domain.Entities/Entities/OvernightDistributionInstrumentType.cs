﻿using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities
{
    public enum OvernightDistributionInstrumentType : byte
    {
        [Description("")]
        None = 0,
        [Description("Бумаги")]
        Security = 1,
        [Description("Валюта")]
        Currency = 2
    }
}