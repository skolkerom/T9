﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("OvernightDistributionOperation", Schema = "rm")]
    public class OvernightDistributionOperation
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public long OvernightDistributionId { get; set; }

        public OvernightDistribution OvernightDistribution { get; set; }

        [DisplayName("Код инструмента пер.")]
        public string BaseInstrumentCode { get; set; }
        
        [DisplayName("Место хранения пер.")]
        public int BaseInstrumentStorageId { get; set; }

        [Column(TypeName = "decimal(19,8)")]
        [DisplayName("Курс пер.")]
        public decimal BaseInstrumentFX { get; set; }

        [DisplayName("Код клиента")]
        public string ClientCode { get; set; }

        [DisplayName("Код инструмента")]
        public string InstrumentCode { get; set; }
        
        [DisplayName("Место хранения")]
        public int InstrumentStorageId { get; set; }

        [DisplayName("Код валюты")]
        public string Currency { get; set; }

        [Column(TypeName = "decimal(19,8)")]

        [DisplayName("Курс")]
        public decimal FX { get; set; }
        
        [Column(TypeName = "decimal(38,15)")]
        [DisplayName("Цена РЕПО 1")]
        public decimal PriceRepo1 { get; set; }
        
        [Column(TypeName = "decimal(38,15)")]
        [DisplayName("Цена РЕПО 2")]
        public decimal PriceRepo2 { get; set; }

        [Column(TypeName = "decimal(19,8)")]
        [DisplayName("Количество")]
        public decimal Quantity { get; set; }
        
        [Column(TypeName = "decimal(19,8)")]
        [DisplayName("Объем РЕПО 1")]
        public decimal Volume1 { get; set; }
        
        [Column(TypeName = "decimal(19,8)")]
        [DisplayName("Объем РЕПО 2")]
        public decimal Volume2 { get; set; }

        [DisplayName("Комиссия РЕПО 1")]
        [Column(TypeName = "decimal(19,2)")]
        public decimal CommissionRepo1 { get; set; }

        [DisplayName("Комиссия РЕПО 2")]
        [Column(TypeName = "decimal(19,2)")]
        public decimal CommissionRepo2 { get; set; }
        
        [DisplayName("Тип инструмента")]
        public OvernightDistributionInstrumentType InstrumentType { get; set; }
        
        [DisplayName("Тип операции")]
        public OvernightDistributionOperationType OperationType { get; set; }

        [DisplayName("НКД РЕПО 1")]
        [Column(TypeName = "decimal(38,15)")]
        public decimal? Nkd1 { get; set; }
        
        [DisplayName("НКД РЕПО 2")]
        [Column(TypeName = "decimal(38,15)")]
        public decimal? Nkd2 { get; set; }
    }
}