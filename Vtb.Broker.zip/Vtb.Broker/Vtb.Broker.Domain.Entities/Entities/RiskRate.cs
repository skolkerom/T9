using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RiskRate", Schema = "rm")]
    [Historable(typeof(RiskRateHistory))]
    [Audit(AuditActionType.RiskRateEdit)]
    public class RiskRate : IEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required(ErrorMessage = "Источник ставки не заполнен")]
        [DisplayName("Источник ставки")]
        public RiskRateSource Source { get; set; }

        //[RegularExpression("^[a-zA-Z0-9]{12}$", ErrorMessage = "Invalid ISIN")]
        [Required(ErrorMessage = "ISIN не заполнен")]
        [DisplayName("Инструмент(ISIN)")]
        public string Isin { get; set; }

        private DateTime _rateDate;
        [Required]
        [DisplayName("Дата ставки")]
        [Column(TypeName = "date")]
        public DateTime RateDate
        {
            get
            {
                return _rateDate;
            }
            set
            {
                _rateDate = value.Date;
            }
        }

        private decimal _rateShort;

        [DisplayName("D+(КПУР)")]
        [DefaultDecimalColumn]
        public decimal RateLong
        {
            get => _rateLong;
            set
            {
                _rateLong = value.NormalizeRate();
                RateLongStandart = _rateLong.GetStandartRate().NormalizeRate();
            }
        }

        private decimal _rateLong;
        [DisplayName("D-(КПУР)")]
        [DefaultDecimalColumn]
        public decimal RateShort
        {
            get => _rateShort;
            set
            {
                _rateShort = value.NormalizeRate();
                RateShortStandart = _rateShort.GetStandartRate().NormalizeRate();
            }
        }

        [DisplayName("D+(КСУР)")]
        [DefaultDecimalColumn]
        public decimal RateLongStandart { get; private set; }

        [DisplayName("D-(КСУР)")]
        [DefaultDecimalColumn]
        public decimal RateShortStandart { get; private set; }

        [DisplayName("Файл")]
        public string FileName { get; set; }

        [Required]
        [DisplayName("Создал")]
        public string CreatedUser { get; set; }

        [Required]
        [DisplayName("Дата создания")]
        public DateTime CreatedDate { get; set; }

        [Required]
        [DisplayName("Изменил")]
        public string ModifiedUser { get; set; }

        [Required]
        [DisplayName("Дата изменения")]
        public DateTime ModifiedDate { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }

        [DisplayName("Удалена")]
        public bool IsDeleted { get; set; }

        [DisplayName("Список")]
        public MarginInstrumentList MarginInstrumentList { get; set; }

        [DisplayName("Список")]
        public long? MarginInstrumentListId { get; set; }


        public override string ToString()
        {
            return $"Id = {Id}, ISIN = {Isin}, Источник ставки = {Source.GetDescription()}";
        }
    }
}
