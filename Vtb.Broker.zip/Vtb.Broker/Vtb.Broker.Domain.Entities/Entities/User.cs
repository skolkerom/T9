using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{    
    public class User
    {
        public string Login { get; set; }
        public string Name { get; set; }
        
        [NotMapped]
        public string IpAddress { get; set; }

        public static User SystemUser { get; } = new User
        {
            Login = "system",
            Name = "system"
        };
    }
}