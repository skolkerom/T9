﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("v_zfront_security_type_rate", Schema = "rm")]
    public class SecurityTypeRate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        
        [DisplayName("Наименование")]
        public string Name { get; set; }
    }
}