using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrumentTransferPlace", Schema = "rm")]
    [Historable(typeof(MarginInstrumentHistoryTransferPlace))]
    public class MarginInstrumentTransferPlace  : IHasId
    {
        private InstrumentInMarginInstrumentList _instrumentInList;
        private Board _transferPlace;

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long InstrumentInListId { get; set; }

        public InstrumentInMarginInstrumentList InstrumentInList
        {
            get => _instrumentInList;
            set
            {
                _instrumentInList = value;
                InstrumentInListId = _instrumentInList?.Id ?? 0;
            }
        }

        public long TransferPlaceId { get; set; }

        public Board TransferPlace
        {
            get => _transferPlace;
            set
            {
                _transferPlace = value;
                TransferPlaceId = _transferPlace?.Id ?? 0;
            }
        }

        public override string ToString()
        {
            return
                $"{nameof(InstrumentInListId)} = {InstrumentInListId}, {nameof(TransferPlaceId)} = {TransferPlaceId}";
        }
    }
}
