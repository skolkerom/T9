using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("v_zfront_instrument", Schema = "rm")]
    public class ZfInstrument
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("act_id")]
        public int Id {get;set;}
        [Column("type_id")]
        public int TypeId {get;set;}
        [Column("ISIN")]
        public string Isin {get;set;}
     
        [Column("lot_size")]
        public int LotSize { get; set; }
        
        [Column("code")]
        public string InstrumentCode { get; set; }
    }
}