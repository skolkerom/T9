using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("Securities", Schema = "olb")]
    public class OlbSecurity
    {
        public string Isin { get; set; }
        public string ShortName { get; set; }
        public string CbCode { get; set; }
    }
}