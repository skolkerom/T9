using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("OlbParameters", Schema = "dbo")]
    public class OlbParameter
    {
        [Key]
        public string Name { get; set; }
        public string Data { get; set; }
        public string Description { get; set; }
    }
}