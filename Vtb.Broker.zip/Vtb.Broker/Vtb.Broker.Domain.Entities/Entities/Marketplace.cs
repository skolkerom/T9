using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("Market", Schema = "lgst")]
    public class Marketplace
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [DisplayName("Код")]
        public string Code { get; set; }
        [DisplayName("Наименование")]
        public string Description { get; set; } 
    }
}