using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RiskCategoryHistory", Schema = "rm")]
    public class RiskCategoryHistory : IHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [DisplayName("ID")]
        public long Id { get; set; }

        public string Code { get; set; }
        [DisplayName("Наименование")]
        public string Name { get; set; }

        [DisplayName("Коэф.")]
        [DefaultDecimalColumn]
        public decimal Rate { get; set; }

        [DisplayName("КВАЛ")]
        public bool IsQualified { get; set; }

        [DisplayName("ИИС")]
        public bool IsIndividualInvestmentAccount { get; set; }

        [DisplayName("ID базовой категории")]
        public long BaseRiskCategoryId { get; set; }
        public BaseRiskCategory BaseRiskCategory { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }

        public string QuikTemplate { get; set; }

        public long EntityId { get; set; }
        public RiskCategory Entity { get; set; }

        public MarginInstrumentList MarginInstrumentList { get; set; }
        
        public long? MarginInstrumentListId { get; set; }

        [DisplayName("Маркетплейс")]
        public List<RiskCategoryHistoryMarketplace> Marketplaces { get; set; } = new List<RiskCategoryHistoryMarketplace>();
    }


}
