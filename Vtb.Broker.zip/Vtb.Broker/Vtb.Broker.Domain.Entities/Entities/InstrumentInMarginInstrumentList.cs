using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("InstrumentInMarginInstrumentList", Schema = "rm")]
    [Historable(typeof(InstrumentInMarginInstrumentListHistory))]
    [Audit(AuditActionType.InstrumentInMarginInstrumentListEdit)]
    public class InstrumentInMarginInstrumentList : IEntity {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [DisplayName("ID инструмента в списке")]
        public long Id { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Выберите список")]
        [DisplayName("Список ЦБ")]
        public long ListId { get; set; }
        public MarginInstrumentList List { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "Выберите инструмент")]
        [DisplayName("Инструмент")]
        public long MarginInstrumentId { get; set; }
         
        public MarginInstrument MarginInstrument { get; set; }

        [DisplayName("Только ВТБ")]
        public bool IsVtbOnly { get; set; }

        [DisplayName("Биржевой перенос")]
        public bool IsExchangeRepo { get; set; } 

        [DisplayName("Марж.")]
        public bool IsMarginal { get; set; }

        [DisplayName("Запрещен")]
        public bool IsRestricted { get; set; } = false;

        private bool _isLong = true;

        [DisplayName("Лонг")]
        public bool IsLong {
            get => _isLong;
            set {
                _isLong = value;
                IsMarginal = _isLong || _isShort;
            }
        }

        private bool _isShort = false;
        [DisplayName("Шорт")]
        public bool IsShort 
        { 
            get => _isShort; 
            set { 
                _isShort = value; 
                IsMarginal = _isLong || _isShort;
            } 
        }
        [Column(TypeName="Date")]
        public DateTime StartDate { get; set; }
        [Column(TypeName="Date")]
        public DateTime? EndDate { get; set; }
        
        [DisplayName("Места переноса")]
        public List<MarginInstrumentTransferPlace> TransferPlaces { get; set; } = new List<MarginInstrumentTransferPlace>();

        [Required]
        [DisplayName("Создал")]
        public string CreatedUser { get; set; }
        [DisplayName("Дата создания")]
        public DateTime CreatedDate { get; set; }
        [DisplayName("Изменил")]
        public string ModifiedUser { get; set; }
        [DisplayName("Изменил")]
        public DateTime ModifiedDate { get; set; }
        [Timestamp]
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }

        public override string ToString()
        {
            return $"Id = {Id}, Инструмент = {MarginInstrument?.Isin}, Список = {List?.Name}";
        }
    }
}
