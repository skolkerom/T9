using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrumentListHistory", Schema = "rm")]
    public class MarginInstrumentListHistory : IHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public long EntityId { get; set; }
        public MarginInstrumentList Entity { get; set; }

        [DisplayName("Наименование")]
        [Required]
        public string Name { get; set; }
        [Required]
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        [Required]
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        [Timestamp]
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
    }
}
