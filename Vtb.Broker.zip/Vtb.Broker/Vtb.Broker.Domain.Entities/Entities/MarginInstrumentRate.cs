﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    
    [Historable(typeof(InstrumentInMarginInstrumentListHistory))]
    [Table("MarginInstrumentRate", Schema = "rm")]
    public class MarginInstrumentRate : IEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        
        public long InstrumentInMarginInstrumentListId { get; set; }

        public InstrumentInMarginInstrumentList InstrumentInMarginInstrumentList { get; set; }
        
        public string Isin { get; set; }
        
        public long ListId { get; set; }

        [DisplayName("D+(КПУР)")]
        [DefaultDecimalColumn]
        public decimal? RateLong { get; set; }

        [DisplayName("D-(КПУР)")]
        [DefaultDecimalColumn]
        public decimal? RateShort { get; set; }
        
        [DisplayName("D+(КCУР)")]
        [DefaultDecimalColumn]
        public decimal? RateLongStandart { get; set; }

        [DisplayName("D-(КCУР)")]
        [DefaultDecimalColumn]
        public decimal? RateShortStandart { get; set; }

        [DisplayName("Создал")]
        public string CreatedUser { get; set; }

        [DisplayName("Дата создания")]
        public DateTime CreatedDate { get; set; }

        [DisplayName("Изменил")]
        public string ModifiedUser { get; set; }

        [DisplayName("Дата изменения")]
        public DateTime ModifiedDate { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }

        [DisplayName("Удален")]
        public bool IsDeleted { get; set; }

        public DateTime? RateDate { get; set; }
        
        public DateTime RateDateTime { get; set; }
        
        public  bool IsVtbOnly { get; set; }
        public  bool IsMarginal { get; set; }
        public  bool IsRestricted { get; set; }
        public bool IsLong { get; set; }
        public bool IsShort { get; set; }
        
        public bool IsSentToOlb { get; set; }
        public bool IsExchangeRepo { get; set; }
        
        public string Ticker { get; set; }
        
        public string ShortName { get; set; }
        
        public string Type { get; set; }
    }
}
