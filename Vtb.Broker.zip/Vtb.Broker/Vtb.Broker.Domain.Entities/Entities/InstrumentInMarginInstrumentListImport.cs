﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("InstrumentInMarginInstrumentListImport", Schema = "rm")]
    public class InstrumentInMarginInstrumentListImport
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public Guid FileId { get; set; }
        public string ListCode { get; set; }
        public string InstrumentCode { get; set; }
        public bool? IsLong { get; set; }
        public decimal? RateLong { get; set; }
        public bool? IsShort { get; set; }
        public decimal? RateShort { get; set; }
        
        [NotMapped]
        public MarginInstrumentList List { get; set; }
        [NotMapped]
        public MarginInstrument MarginInstrument { get; set; }

        [NotMapped] public long? InstrumentListId { get; set; }
    }
}