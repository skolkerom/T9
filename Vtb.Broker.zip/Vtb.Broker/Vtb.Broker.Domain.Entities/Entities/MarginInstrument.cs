using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrument", Schema = "rm")]
    [Historable(typeof(MarginInstrumentHistory))]
    [Audit(AuditActionType.MarginInstrumentEdit)]
    public class MarginInstrument : IEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [Required(ErrorMessage = "ISIN не заполнен")]
        [DisplayName("ISIN")]
        public string Isin { get; set; }
        [DisplayName("Наименование")]
        public string ShortName { get; set; }
        [DisplayName("Торговый код")]
        public string Ticker { get; set; }
        [DisplayName("Тип")]
        public string Type { get; set; }

        
        [DisplayName("Дисконт РЕПО")]
        public decimal? RepoRate { get; set; }
        
        [DisplayName("Лимит Long")]
        public decimal? LongLimit { get; set; }
        
        [DisplayName("Лимит Short")]
        public decimal? ShortLimit { get; set; }
        
        [DisplayName("Дисконт Short")]
        public decimal Discount { get; set; }
        
        [DisplayName("Приоритет залога")]
        public int? MarginPriority { get; set; }
        
        [DisplayName("Тариф валютного внебирж. спец РЕПО")]
        public int? SecurityTypeRateId { get; set; }
        
        private SecurityTypeRate _securityTypeRate;
        
        [DisplayName("Тариф валютного внебирж. спец РЕПО")]
        public SecurityTypeRate SecurityTypeRate
        {
            get => _securityTypeRate;
            set
            {
                _securityTypeRate = value;
                SecurityTypeRateId = value?.Id;
            }
        }

        [DisplayName("Создал")]
        public string CreatedUser { get; set; }
        [DisplayName("Дата создания")]
        public DateTime CreatedDate { get; set; }
        [DisplayName("Изменил")]
        public string ModifiedUser { get; set; }

        public DateTime ModifiedDate { get; set; }

        public bool? IsDiscountLastDealPrice { get; set; }
        public string TransferCurrency { get; set; }
        public byte[] RowVersion { get; set; }
        [DisplayName("Удален")]
        public bool IsDeleted { get; set; }
        public List<InstrumentInMarginInstrumentList> InstrumentInMarginInstrumentLists { get; set; }


        public override string ToString()
        {
            return $"Id = {Id}, ISIN = {Isin}, Наименование = {ShortName}, Торговый код = {Ticker}, Тип = {Type}";
        }
    }
}