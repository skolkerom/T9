﻿namespace Vtb.Broker.Domain.Entities
{
    public enum RiskRateSource
    {
        Mfb = 0,
        Nsd = 1,
        Vtb = 2,
        Moex = 3
    }
}
