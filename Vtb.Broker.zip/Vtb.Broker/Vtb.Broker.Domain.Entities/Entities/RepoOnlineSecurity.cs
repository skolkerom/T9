﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RepoOnlineSecurity", Schema = "rm")]
    public class RepoOnlineSecurity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string InstrumentCode { get; set; }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string BaseInstrumentCode { get; set; }
        public decimal Quantity { get; set; }
        public decimal Volume { get; set; }
    }
}