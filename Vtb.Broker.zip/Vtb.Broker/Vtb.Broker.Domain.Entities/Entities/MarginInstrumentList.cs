﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrumentList", Schema = "rm")]
    [Historable(typeof(MarginInstrumentListHistory))]
    [Audit(AuditActionType.MarginInstrumentListEdit)]
    public class MarginInstrumentList : IEntity
    {   
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [DisplayName("Наименование")]
        [Required(ErrorMessage = "Наименование не заполнено")]
        public string Name { get; set; }
        
        [DisplayName("Код")]
        [Required(ErrorMessage = "Код не заполнен")]
        public string Code { get; set; }

        [DisplayName("Дата создания")]
        public DateTime CreatedDate { get; set; }
        public List<InstrumentInMarginInstrumentList> Instruments { get; set; } = new List<InstrumentInMarginInstrumentList>();
        [Required]
        public string CreatedUser { get; set; }

        [Required]
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
        
        public bool NotifyTradingSystem { get; set; }
        
        public ICollection<RiskRate> RiskRates { get; set; }

        
        public override string ToString()
        {
            return $"Id = {Id}, Наименование = {Name}";
        }
    }
}
