﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MoexRiskRateFile", Schema = "rm")]
    public class MoexRiskRateFile
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public DateTime? Date { get; set; }
        public byte[] Content { get; set; }
    }
}