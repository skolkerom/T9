﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("BaseRiskCategory", Schema = "rm")]
    public class BaseRiskCategory : IHasId
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public long Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }

        public override string ToString()
        {
            return $"{nameof(Id)} = {Id}, {nameof(Name)} = {Name}, {nameof(Code)} = {Code}";
        }
    }
}
