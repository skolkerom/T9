using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrumentHistory", Schema = "rm")]
    public class MarginInstrumentHistory : IHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public string Isin { get; set; }

        public string ShortName { get; set; }

        public string Ticker { get; set; }

        public string Type { get; set; }
        
        public decimal? RepoRate { get; set; }
        
        public decimal? LongLimit { get; set; }
        
        public decimal? ShortLimit { get; set; }
        
        public int? MarginPriority { get; set; }
        
        public int? SecurityTypeRateId { get; set; }

        public string CreatedUser { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedUser { get; set; }
        public bool? IsDiscountLastDealPrice { get; set; }
        public string TransferCurrency { get; set; }

        public DateTime ModifiedDate { get; set; }
        public byte[] RowVersion { get; set; }

        public bool IsDeleted { get; set; }
        public long EntityId { get; set; }
        public MarginInstrument Entity { get; set; }
        
        [DisplayName("Места переноса")]

        public List<MarginInstrumentHistoryTransferPlace> TransferPlaces { get; set; } = new List<MarginInstrumentHistoryTransferPlace>();
    }
}