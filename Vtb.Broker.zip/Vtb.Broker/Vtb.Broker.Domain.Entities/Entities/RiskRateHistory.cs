using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RiskRateHistory", Schema = "rm")]
    public class RiskRateHistory : IHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; } 

        [Required]
        public RiskRateSource Source { get; set; }
        [MaxLength(12)]
        [MinLength(12)]
        [Required]
        public string Isin { get; set; }

        private DateTime _rateDate;
        [Required]
        public DateTime RateDate
        {
            get
            {
                return _rateDate;
            }
            set
            {
                _rateDate = value.Date;
            }
        }
        [DefaultDecimalColumn]
        public decimal RateLong { get; set; }
        [DefaultDecimalColumn]
        public decimal RateShort { get; set; }

        public long FileId { get; set; }

        [Required]
        public string CreatedUser { get; set; }
        [Required]
        public DateTime CreatedDate { get; set; }
        [Required]
        public string ModifiedUser { get; set; }
        [Required]
        public DateTime ModifiedDate { get; set; }
        [Timestamp]
        public byte[] RowVersion { get; set; }

        public long EntityId { get; set; }
        public RiskRate Entity { get; set; }
    }
}