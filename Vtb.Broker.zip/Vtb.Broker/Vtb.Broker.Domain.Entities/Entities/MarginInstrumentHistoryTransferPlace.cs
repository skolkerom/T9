using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrumentHistoryTransferPlace", Schema = "rm")]
    public class MarginInstrumentHistoryTransferPlace  : IHasId
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long MarginInstrumentId { get; set; }
        public MarginInstrumentHistory MarginInstrument { get; set; }
        public long TransferPlaceId { get; set; }
        public Board TransferPlace { get; set; }
    }
}