using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("InstrumentInMarginInstrumentListHistory", Schema = "rm")]
    public class InstrumentInMarginInstrumentListHistory : IHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Выберите список")]
        [DisplayName("Список ЦБ")]
        public long ListId { get; set; }

        public MarginInstrumentList List { get; set; }

        public long MarginInstrumentId { get; set; }
        public MarginInstrument MarginInstrument { get; set; }

        [DisplayName("Только ВТБ")]
        public bool IsVtbOnly { get; set; }

        [DisplayName("Место переноса")]
        public string TransferPlace { get; set; }

        [DisplayName("Марж.")]
        public bool IsMarginal { get; set; }

        [DisplayName("Запрещен")]
        public bool IsRestricted { get; set; }

        [DisplayName("Лонг")]
        public bool IsLong { get; set; }

        [DisplayName("Шорт")]
        public bool IsShort { get; set; }
        
        public bool IsExchangeRepo { get; set; }

        [Required]
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }

        [Required]
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }

        public long EntityId { get; set; }

        public InstrumentInMarginInstrumentList Entity { get; set; }
    }
}
