using System.ComponentModel.DataAnnotations;

namespace Vtb.Broker.Domain.Entities
{
    public class OlbMarketRiskParameter
    {
        [Key]
        public int Id { get; set; }
        public string Isin { get; set; }
        public int RangeNumber { get; set; }
        public decimal BeginQuantity { get; set; }

        public decimal EndQuantity { get; set; }

        public decimal DiscountH { get; set; }

        public decimal DiscountL { get; set; }

        public decimal BeginLcy { get; set; }

        public decimal EndLcy { get; set; }

        public decimal LowBoardLcy { get; set; }

        public decimal HighBoardLcy { get; set; }

    }
}