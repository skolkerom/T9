﻿using System;

namespace Vtb.Broker.Domain.Entities
{
    public class MarketData
    {
        public long RecordOrder { get; set; }
        public int InstrumentId { get; set; }
        public string InstrumentCode { get; set; }
        public DateTime ValueDate { get; set; }
        public double? ClosePrice { get; set; }
        public double? AvgPrice { get; set; }
        public double? OpenPrice { get; set; }
        public double? LastPrice { get; set; }
        public double? MaxPrice { get; set; }
        public double? MinPrice { get; set; }
    }
}