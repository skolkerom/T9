using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("OvernightDistribution", Schema = "rm")]
    public class OvernightDistribution : IHasId
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]        
        public long Id { get; set; }

        [DisplayName("Операционный день")]
        public DateTime Date { get; set; }

        [DisplayName("Время запуска")]
        public DateTime StartDate { get; set; } = DateTime.Now;
        [DisplayName("Время окончания")]
        public DateTime EndDate { get; set; }
        
        public int? RequestId { get; set; }
        
        public string User { get; set; }

        public List<OvernightDistributionOperation> OvernightDistributionOperations { get; set; } = new List<OvernightDistributionOperation>();

        public List<OvernightDistributionPosition> OvernightDistributionPositions { get; set; } = new List<OvernightDistributionPosition>();
    }
}