using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RiskCategoryHistoryMarketplace", Schema = "rm")]
    public class RiskCategoryHistoryMarketplace : IHasId
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public Marketplace Marketplace { get; set; }
        public int MarketplaceId { get; set; }

        public RiskCategoryHistory RiskCategory { get; set; }

        public long RiskCategoryId { get; set; }
    }
}