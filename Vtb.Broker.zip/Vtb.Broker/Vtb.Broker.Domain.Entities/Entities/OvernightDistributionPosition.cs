using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("OvernightDistributionPosition", Schema = "rm")]
    public class OvernightDistributionPosition
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public long OvernightDistributionId { get; set; }

        public OvernightDistribution OvernightDistribution { get; set; }

        [Required]
        [DisplayName("Код клиента")]
        public string ClientCode { get; set; }
        
        [DisplayName("Тип инструмента")]
        public OvernightDistributionInstrumentType InstrumentType { get; set; }

        [Required]
        [DisplayName("Код инструмента")]
        public string InstrumentCode { get; set; }

        [Required]
        [DisplayName("Валюта")]
        public string Currency { get; set; }

        [DisplayName("Позиция на начало")]
        [Column(TypeName = "decimal(19,2)")]
        public decimal PositionStart { get; set; }

        [DisplayName("Позиция на конец")]
        [Column(TypeName = "decimal(19,2)")]
        public decimal PositionEnd { get; set; }
        
        [DisplayName("Место хранения")]
        public int StorageId { get; set; }
    }
}