﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("MarginInstrumentImport", Schema = "rm")]
    public class MarginInstrumentImport 
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public Guid FileId { get; set; }
        public string Type { get; set; }
        public string Isin { get; set; }
        public string Ticker { get; set; } 
        public long? LongLimit { get; set; }
        public long? ShortLimit { get; set; }
        public int? MarginPriority { get; set; }
        public decimal? Discount { get; set; }
        public int? SecurityTypeRateId { get; set; }
        public decimal? RepoRate { get; set; }
        public bool? IsDiscountLastDealPrice { get; set; }
        
        public string TransferCurrency { get; set; }
    }
}