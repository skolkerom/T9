using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities
{
    public enum IndividualInvestmentAccount
    {
        [Description("Не ИИС")]
        NotIIS = 0,
        [Description("ИИС")]
        IIS = 1,
        [Description("Все")]
        All = 2
    }
}
