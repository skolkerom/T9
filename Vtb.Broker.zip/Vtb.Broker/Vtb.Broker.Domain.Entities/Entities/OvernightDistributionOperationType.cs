﻿using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities
{
    public enum OvernightDistributionOperationType : byte
    {
        [Description("")]
        None = 0,
        [Description("РЕПО")]
        Repo = 1,
        [Description("СВОП")]
        Swap = 2
    }
}