using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities
{
    public enum QualifiedInvestor
    {
        [Description("Не КИ")]
        NotQualified = 0,
        [Description("КИ")]
        Qualified = 1,
        [Description("Все")]
        All = 2
    }
}
