using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Domain.Entities
{
    [Table("RiskCategoryMarketplace", Schema = "rm")]
    [Historable(typeof(RiskCategoryHistoryMarketplace))]
    public class RiskCategoryMarketplace : IHasId
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        private Marketplace _marketplace;
        public Marketplace Marketplace
        {
            get => _marketplace;
            set
            {
                _marketplace = value;
                MarketplaceId = _marketplace?.Id ?? 0;
            } 
        }
        public int MarketplaceId { get; set; }

        private RiskCategory _riskCategory;

        [JsonIgnore] 
        public RiskCategory RiskCategory
        {
            get => _riskCategory;
            set
            {
                _riskCategory = value;
                RiskCategoryId = _riskCategory?.Id ?? 0;
            }
        }

        public long RiskCategoryId { get; set; }

        public override string ToString()
        {
            return $"{nameof(MarketplaceId)} = {MarketplaceId}, {nameof(RiskCategoryId)} = {RiskCategoryId}";
        }
    }
}