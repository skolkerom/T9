﻿namespace Vtb.Broker.Domain.Entities
{
    public class Currency
    {
        public string Iso { get; set; }
        public string Name { get; set; }
    }
}