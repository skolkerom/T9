using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Domain.Entities
{
    [Table("Board", Schema="rm")]
    public class Board
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [DisplayName("Торговый код")]
        public string Code { get; set; }
        [DisplayName("Наименование")]
        public string ShortName { get; set;} 
        public string LatName { get; set; }
    }
}