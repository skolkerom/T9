using System.ComponentModel;

namespace Vtb.Broker.Domain.Entities
{
    public enum FormingPrinciple
    {
        [Description("Автоматический")]
        Auto = 0,
        [Description("Ручной")]
        Manual = 1
    }
}
