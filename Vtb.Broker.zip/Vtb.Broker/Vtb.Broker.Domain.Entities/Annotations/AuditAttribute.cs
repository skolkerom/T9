using System;
using Vtb.Broker.Interfaces.Audit.Entities;

namespace Vtb.Broker.Domain.Entities.Annotations
{
    public class AuditAttribute : Attribute
    {
        public AuditAttribute(AuditActionType actionType)
        {
            ActionType = actionType;
        }
        
        public AuditActionType ActionType { get; set; }
    }
}