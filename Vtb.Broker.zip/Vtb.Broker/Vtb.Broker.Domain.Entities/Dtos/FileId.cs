﻿using System;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class FileId
    {
        public Guid fileId { get; set; }
    }
}