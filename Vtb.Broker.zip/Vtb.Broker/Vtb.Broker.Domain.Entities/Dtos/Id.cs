﻿namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class Id
    {
        public long id { get; set; }
    }
}