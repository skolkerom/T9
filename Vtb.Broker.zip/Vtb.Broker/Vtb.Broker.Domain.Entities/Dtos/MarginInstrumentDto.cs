using System;
using System.Collections.Generic;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class MarginInstrumentDto 
    {
        public long Id { get; set; }
        public string Isin { get; set; }
        public string ShortName { get; set; }
        public string Ticker { get; set; }
        public string Type { get; set; }
        public decimal? RepoRate { get; set; }
        public decimal? LongLimit { get; set; }
        public decimal? ShortLimit { get; set; }
        public decimal Discount { get; set; }
        public int? MarginPriority { get; set; }
        public int? SecurityTypeRateId { get; set; }
        public SecurityTypeRate SecurityTypeRate { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool? IsDiscountLastDealPrice { get; set; }
        public string TransferCurrency { get; set; }
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
        public List<InstrumentInMarginInstrumentListDto> InstrumentInMarginInstrumentLists { get; set; }
    }
}
