using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Vtb.Broker.Domain.Entities.Dtos;

namespace Vtb.Broker.Domain.Entities
{
    public class RiskCategoryDto
    {
        public long Id { get; set; }

        [MaxLength(30)]
        public string Code { get; set; }
        public string Name { get; set; }
        public List<RiskCategoryMarketplaceDto> MarketPlaces { get; set; } = new List<RiskCategoryMarketplaceDto>();
        public string FormingPrincipleName { get; set; }
        public FormingPrinciple FormingPrinciple { get; set; }
        public decimal Rate { get; set; }
        public QualifiedInvestor QualifiedInvestor { get; set; }
        public string QualifiedInvestorName { get; set; }
        public IndividualInvestmentAccount IndividualInvestmentAccount { get; set; }
        public string IndividualInvestmentAccountName { get; set; }
        public long BaseRiskCategoryId { get; set; }
        public string BaseRiskCategoryName { get; set; }
        public string MarginInstrumentListCode { get; set; }
        public string MarginInstrumentListName { get; set; }
        public long? MarginInstrumentListId { get; set; }
        public string QuikTemplate { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
        public string Comment { get; set; }
        public long? QuikLeverageId { get; set; }
    }
}
