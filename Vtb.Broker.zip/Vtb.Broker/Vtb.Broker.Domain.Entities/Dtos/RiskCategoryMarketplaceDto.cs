using System;
using System.Collections.Generic;
using System.Text;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class RiskCategoryMarketplaceDto
    {
        public int MarketplaceId { get; set; }

        public long RiskCategoryId { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public override string ToString()
        {
            return $"{Code} - {Description}";
        }
    }
}
