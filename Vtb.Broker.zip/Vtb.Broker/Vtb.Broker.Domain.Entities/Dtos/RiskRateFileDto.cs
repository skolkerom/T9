﻿namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class RiskRateFileDto
    {
        public string FileType { get; set; }
        public string FileName { get; set; }
        public byte[] Content { get; set; }
    }
}