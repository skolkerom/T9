﻿using System.Collections.Generic;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class InstrumentInMarginInstrumentListSettings
    {
        public bool IsVtbOnly { get; set; }
        public List<MarginInstrumentTransferPlace> TransferPlaces { get; set; } 
        public bool IsMarginal { get; set; }
        public bool IsRestricted { get; set; }
        public bool IsLong { get; set; }
        public bool IsShort { get; set; } 
    }
}