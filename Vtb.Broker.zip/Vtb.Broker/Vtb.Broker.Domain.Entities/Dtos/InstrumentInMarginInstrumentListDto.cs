﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class InstrumentInMarginInstrumentListDto 
    {
        public long Id { get; set; }
        
        public long ListId { get; set; }
        
        [JsonIgnore]
        public MarginInstrumentList List { get; set; }
        
        public long MarginInstrumentId { get; set; }
        
        [JsonIgnore]
        public MarginInstrument MarginInstrument { get; set; }
        
        public bool IsVtbOnly { get; set; }
        public string TransferPlace { get; set; }
        public bool IsMarginal { get; set; }
        public bool IsRestricted { get; set; }
        public bool IsLong { get; set; }
        public bool IsShort { get; set; } 
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        [Timestamp]
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
        public Id[] ListIdsToApply { get; set; }
        
        public List<MarginInstrumentTransferPlaceDto> TransferPlaces { get; set; }
        public bool ApplyToAllInstrumentsInList { get; set; }
    }
}