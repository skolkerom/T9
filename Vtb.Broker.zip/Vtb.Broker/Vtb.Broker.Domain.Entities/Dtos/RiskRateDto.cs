﻿using System;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class RiskRateDto
    {
        public long Id { get; set; }
        
        public RiskRateSource Source { get; set; }

        public string Isin { get; set; }
        
        public long? MarginInstrumentListId { get; set; }

        public DateTime RateDate { get; set; }

        public decimal RateLong { get; set; }

        public decimal RateShort { get; set; }

        public string CreatedUser { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedUser { get; set; }

        public DateTime ModifiedDate { get; set; }

        public byte[] RowVersion { get; set; }

        public bool IsDeleted { get; set; }
        public Id[] ListIdsToApply { get; set; }
    }
}