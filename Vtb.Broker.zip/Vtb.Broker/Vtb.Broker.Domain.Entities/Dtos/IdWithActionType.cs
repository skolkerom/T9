﻿namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class IdWithActionType
    {
        public long id { get; set; }
        public string actionType { get; set; }
    }
}