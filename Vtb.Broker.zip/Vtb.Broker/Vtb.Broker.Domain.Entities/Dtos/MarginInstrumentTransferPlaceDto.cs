﻿namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class MarginInstrumentTransferPlaceDto 
    {
        public long Id { get; set; }
        public long? InstrumentInListId { get; set; }
        public long? TransferPlaceId { get; set; }
    }
}