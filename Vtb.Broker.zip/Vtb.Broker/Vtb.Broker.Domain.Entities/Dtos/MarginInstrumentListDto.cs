﻿using System;

namespace Vtb.Broker.Domain.Entities.Dtos
{
    public class MarginInstrumentListDto
    {
        public long Id { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }
        
        public DateTime CreatedDate { get; set; }
        public string CreatedUser { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool NotifyTradingSystem { get; set; }
        public byte[] RowVersion { get; set; }
    }
}