using Xunit;

namespace Vtb.Broker.Tests.ParserTests
{
    public class ParserTests
    {
        [Fact]
        public void MfbFileParsedCorrectly()
        {

        }
    }
}
