﻿param([string]$source, [string]$destination, [string]$environment, [system.collections.generic.dictionary[string,string]]$envMapping, [string]$serviceName, [string]$project, [string]$location) 


if($serviceName -eq "")
{
    "ServiceName is empty"
    return
} 

Stop-Service -Name $serviceName
Exit-On-Error -location $location

robocopy /E "$($source)" "$($destination)"
Exit-On-Robocopy-Error -location $location

$Env:ASPNETCORE_ENVIRONMENT = $envMapping[$environment]
"ASPNETCORE_ENVIRONMENT: $($Env:ASPNETCORE_ENVIRONMENT)"

#if($Env:ASPNETCORE_ENVIRONMENT -ne $envMapping["Prod"])
#{
    "Start migration"
    iex "$($destination)\$($project).exe --ef-migrate-check --ef-migrate"
    Exit-On-Error -location $location
#}

Start-Service -Name $serviceName
Exit-On-Error -location $location

Set-Location $location

