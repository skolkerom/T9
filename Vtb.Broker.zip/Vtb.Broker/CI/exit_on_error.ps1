﻿function Exit-On-Error
{
    Param ([string]$location)
    if ($LastExitCode -ne "0") 
    {
        $error[0]
        Set-Location $location
        exit
    }
}

function Exit-On-Robocopy-Error
{
    Param([string]$location)
    if($LastExitCode -gt 7)
    {
        $error[0]
        Set-Location $location
        exit
    }
}