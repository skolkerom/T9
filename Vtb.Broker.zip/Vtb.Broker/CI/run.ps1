param([String] $environment, [String] $revision, [String] $project)
. .\exit_on_error.ps1
. .\check_environment.ps1 $environment

$error.clear()

$ErrorActionPreference = "Stop"
$currentLocation = Get-Location
$envMapping = New-Object 'system.collections.generic.dictionary[string,string]'
$envMapping["Test"] = "Test"
$distr_origin = "\\dfs-1.msk.vtb24.ru\dfs\UABB\WIM\Projects\Vtb.Broker\releases"
$root = "D:\Vtb.Broker"
$distr = "$($root)\releases"

if ($revision -eq "")
{
    "Revision is empty"
    return
}

if ($project -eq "")
{
    "Project is empty"
    return
}

$path_origin = [System.IO.Path]::Combine($distr_origin, $revision, $project)
$path = [System.IO.Path]::Combine($distr, $revision, $project)

if([System.IO.Directory]::Exists($path_origin) -eq 0)
{
    $path + " not exists"
    return
}

$msg = 'You are trying to deploy ' + $path + ' to ' + $environment + ' environment. Print ''' + $environment + ''' to continue'

$response = Read-Host -Prompt $msg

if ($response -ne $environment) {
    "Confimation failed"
    return
}

$source = "$($distr)\$($revision)\$($project)"
$destination = "$($root)\$($environment)\$($project)"

$path_origin = $path_origin + "\release.zip"

Remove-Item $source -Recurse -Force -ErrorAction Ignore

Expand-Archive -Path $path_origin -DestinationPath $source


if($project -eq "Vtb.Broker.RiskManagement.UI")
{
    .\run_service.ps1 $source $destination $environment $envMapping "Vtb.Broker.Web" $project $currentLocation 
}
else
{
    .\run_service.ps1 $source $destination $environment $envMapping $project $project $currentLocation
}

Out-File -FilePath ".\Version_$($project)_$($environment).txt" -InputObject $revision

Set-Location $currentLocation