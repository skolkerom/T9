﻿. .\exit_on_error.ps1

$ErrorActionPreference = "Stop"
$currentLocation = Get-Location

$gitRepo = "http://msk-044500.msk.vtb24.ru/UABB/Vtb.Broker.git"

$auth = "Vtb.Broker.Auth.Server"
$web = "Vtb.Broker.RiskManagement.UI"
$optimalRepo = "Vtb.Broker.OptimalRepoCalculator"

$getRevisionCommand = "git rev-parse --short HEAD"
$revision = iex $getRevisionCommand
Exit-On-Error -location $currentLocation

$remotePath="\\fs-n01\dfs\UABB\WIM\Projects\Vtb.Broker\releases\$($revision)"

Remove-Item -LiteralPath "Vtb.Broker" -Force -Recurse
Exit-On-Error -location $currentLocation 

$env:GIT_REDIRECT_STDERR = "2>&1"

iex "git clone $($gitRepo)"
Exit-On-Error -location $currentLocation
iex "git pull"
Exit-On-Error -location $currentLocation

.\publish_service.ps1 $auth $remotePath $currentLocation
.\publish_service.ps1 $web $remotePath $currentLocation
.\publish_service.ps1 $optimalRepo $remotePath $currentLocation