﻿param([string]$service, [string]$deployPath, [string]$currentLocation) 
. .\exit_on_error.ps1

Set-Location "Vtb.Broker\$($service)"   
Exit-On-Error -location $currentLocation 

dotnet publish
Exit-On-Error -location $currentLocation

mkdir ..\$service\bin\Debug\netcoreapp3.1\publish\release
Compress-Archive -Path ..\$service\bin\Debug\netcoreapp3.1\publish -DestinationPath ..\$service\bin\Debug\netcoreapp3.1\publish\release\release.zip

robocopy ..\$service\bin\Debug\netcoreapp3.1\publish\release $deployPath\$service
Exit-On-Error -location $currentLocation

Set-Location $currentLocation