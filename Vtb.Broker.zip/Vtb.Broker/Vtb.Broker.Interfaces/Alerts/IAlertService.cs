﻿using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.Alerts
{
    public interface IAlertService
    {
        Task Send(string alertCode, object main, object[] details = null);
    }
}