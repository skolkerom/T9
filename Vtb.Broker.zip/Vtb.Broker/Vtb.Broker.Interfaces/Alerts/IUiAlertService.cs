﻿using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Alerts.Entities;

namespace Vtb.Broker.Interfaces.Alerts
{
    public interface IUiAlertService
    {
        Task<Alert[]> GetAlerts();
        Task<AlertEmail[]> GetAlertEmails(long alertId);
        Task<AlertEmail> GetAlertEmail(long id);
        Task<AlertEmailTemplate[]> GetAlertEmailTemplates(long alertId);
        Task<AlertEmailTemplate> GetAlertEmailTemplate(long id);
        Task SaveAsync(AlertEmail entity);
        Task SaveAsync(AlertEmailTemplate entity);
    }
}