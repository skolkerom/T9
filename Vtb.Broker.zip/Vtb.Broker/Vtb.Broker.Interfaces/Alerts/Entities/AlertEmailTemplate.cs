﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Interfaces.Alerts.Entities
{
    [Table("AlertEmailTemplate", Schema = "rm")]
    public class AlertEmailTemplate : IEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long AlertId { get; set; }
        [DisplayName("Тема")]
        public string Subject { get; set; }
       
        [DisplayName("Основной шаблон")]
        public string MainTemplate { get; set; }
        [DisplayName("Шаблон заголовка деталей")]
        public string HeaderTemplate { get; set; }
        [DisplayName("Шаблон деталей")]
        public string DetailTemplate { get; set; }
        [DisplayName("Описание")]
        public string Description { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
        public Alert Alert { get; set; }
    }
}