﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Interfaces.Alerts.Entities
{
    [Table("AlertEmail", Schema = "rm")]
    public class AlertEmail : IEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long AlertId { get; set; }
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Некорректный адрес электронной почты")]
        [MaxLength(2048)]
        public string Email { get; set; }
        public Alert Alert { get; set; }
        public string CreatedUser { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedUser { get; set; }
        public DateTime ModifiedDate { get; set; }
        public byte[] RowVersion { get; set; }
        public bool IsDeleted { get; set; }
    }
}