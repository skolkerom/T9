﻿namespace Vtb.Broker.Interfaces.Alerts.Entities
{
    public class AlertDto
    {
        public string Code { get; set; }
        public string[] Recipients { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Detail { get; set; }
        public string Header { get; set; }
    }
}