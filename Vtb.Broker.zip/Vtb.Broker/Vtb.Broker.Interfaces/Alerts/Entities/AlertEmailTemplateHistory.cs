﻿using System;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Interfaces.Alerts.Entities
{
    public class AlertEmailTemplateHistory : IHistory
    {
        public long Id { get; set; }
        public DateTime ModifiedDate { get; set; }
        public long EntityId { get; set; }
    }
}