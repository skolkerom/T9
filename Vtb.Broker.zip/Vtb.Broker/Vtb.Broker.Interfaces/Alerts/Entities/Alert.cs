﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Interfaces.Alerts.Entities
{
    [Table("Alert", Schema = "rm")]
    public class Alert
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        
        [DisplayName("Код")]
        [MaxLength(1024)]
        public string Code { get; set; }
        
        [DisplayName("Описание")]
        public string Description { get; set; }
        [DisplayName("Удален")]
        public bool IsDeleted { get; set; }
    }
}