using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.IO
{
    public interface IFileUploader
    {
        Task UploadFile(byte[] content, string fileName);
    }
}