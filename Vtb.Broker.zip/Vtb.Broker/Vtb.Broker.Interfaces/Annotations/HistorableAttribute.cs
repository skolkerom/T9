using System;

namespace Vtb.Broker.Interfaces.Annotations
{
    public class HistorableAttribute : Attribute
    {
        public Type HistoryEntityType { get; set; }
        public HistorableAttribute(Type historyEntityType)
        {
            HistoryEntityType = historyEntityType;
        }
    }
}