using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Interfaces.Annotations
{
    public class DefaultDecimalColumn : ColumnAttribute
    {
        public DefaultDecimalColumn()
        {
            TypeName = "decimal (19,8)";
        }
    }
}