namespace Vtb.Broker.Interfaces.Mapper
{
    public interface IMapperService
    {
        TTarget Map<TTarget>(object source);
        TTarget Map<TSource, TTarget>(TSource source);

        TTarget Map<TSource, TTarget>(TSource source, TTarget target);
    }
}

