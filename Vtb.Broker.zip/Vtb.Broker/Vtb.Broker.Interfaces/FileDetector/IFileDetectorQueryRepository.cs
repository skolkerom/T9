﻿using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.FileDetector
{
    public interface IFileDetectorQueryRepository
    {
        Task<Interfaces.FileDetector.Entities.FileDetector[]> GetFileDetectorsWithTransformedPaths();
        Task<Interfaces.FileDetector.Entities.FileDetector[]> GetFileDetectorsWithTransformedPaths(string applicationName);
    }
}