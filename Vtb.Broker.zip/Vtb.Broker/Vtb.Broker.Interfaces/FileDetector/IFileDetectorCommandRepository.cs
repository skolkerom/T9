﻿using System.Threading.Tasks;
using Vtb.Broker.Interfaces.FileDetector.Entities;

namespace Vtb.Broker.Interfaces.FileDetector
{
    public interface IFileDetectorCommandRepository
    {
        Task<long> SaveAsync(ProcessedFile processedFile);
    }
}