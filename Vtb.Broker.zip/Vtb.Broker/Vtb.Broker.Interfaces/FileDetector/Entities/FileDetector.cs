﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Interfaces.FileDetector.Entities
{
    [Table("FileDetector", Schema = "rm")]
    public class FileDetector
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public string Description { get; set; }
        public string ApplicationName { get; set; }
        public string Type { get; set; }
        public string Path { get; set; }
        public string Mask { get; set; }
        public bool Enabled { get; set; }
        public ICollection<ProcessedFile> ProcessedFiles { get; set; }
    }
}
