using System.Net.Http;
using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.Transport.Http
{
    public interface IWebRequestService
    {
        Task<byte[]> GetPageContent(string url);

        Task PostAsync<TBody>(string serviceName, string command, TBody body, string jwtToken);

        Task PostAsync<TBody>(string serviceName, string command, TBody body);
    }
}