﻿namespace Vtb.Broker.Interfaces.Integration.MoexRiskRateDownloader
{
    public static class API
    {
        public const string MoexRiskRates = "MoexRiskRates";
    }
}