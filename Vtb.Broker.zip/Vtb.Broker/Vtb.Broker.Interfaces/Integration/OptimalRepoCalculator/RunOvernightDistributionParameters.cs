﻿using System;

namespace Vtb.Broker.Interfaces.Integration.OptimalRepoCalculator
{
    public class RunOvernightDistributionParameters
    {
        public DateTime Date { get; set; }
        public string ClientCode { get; set; }
        public int? RequestId { get; set; }
    }
}