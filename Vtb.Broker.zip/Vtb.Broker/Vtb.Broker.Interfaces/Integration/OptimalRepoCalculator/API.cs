﻿namespace Vtb.Broker.Interfaces.Integration.OptimalRepoCalculator
{
    public static class API
    {
        public const string RunOvernightDistrubutionUrl = "/GenerateOptimalRepo";
    }
}