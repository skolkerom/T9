﻿namespace Vtb.Broker.Interfaces.Integration.AuthServer
{
    public static class API
    {
        public const string GetToken = "/GetToken";
    }
}