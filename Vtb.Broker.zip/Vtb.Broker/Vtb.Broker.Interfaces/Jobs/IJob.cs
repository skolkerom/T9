using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.Jobs
{

    public interface IJob
    {
        Task Execute(JobContext context);
    }
}