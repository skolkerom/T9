namespace Vtb.Broker.Interfaces.Jobs
{
    public class JobContext
    {
        
    }
}