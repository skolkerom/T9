﻿using System.Net;

namespace Vtb.Broker.Interfaces.BankProxy
{
    public interface IBankProxyFactory
    {
        IWebProxy CreateWebProxy();
    }
}