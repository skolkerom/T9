namespace Vtb.Broker.Interfaces.UnitOfWork
{
    public interface IUnitOfWorkFactory
    {
        IUnitOfWork Get();
    }
}