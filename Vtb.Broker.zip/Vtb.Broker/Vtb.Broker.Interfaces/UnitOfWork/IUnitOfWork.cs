using System;
using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        TRepository GetRepository<TRepository>();

        Task BeginTran();
        Task CommitTran();
    }
}