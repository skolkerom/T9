using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Vtb.Broker.Interfaces.Entities
{
    public interface IEntity : IHasId
    {
        [Required]
        [DisplayName("Создал")]
        string CreatedUser { get; set; }

        [Required]
        [DisplayName("Дата создания")]
        DateTime CreatedDate { get; set; }

        [Required]
        [DisplayName("Изменил")]
        string ModifiedUser { get; set; }

        [Required]
        [DisplayName("Дата изменения")]
        DateTime ModifiedDate { get; set; }

        [Timestamp]
        byte[] RowVersion { get; set; }

        [DisplayName("Удалена")]
        bool IsDeleted { get; set; }
    }
}
