using System;

namespace Vtb.Broker.Interfaces.Entities
{
    public interface IHistory : IHasId
    {
        DateTime ModifiedDate { get; set; }

        long EntityId { get; set; }
    }
}
