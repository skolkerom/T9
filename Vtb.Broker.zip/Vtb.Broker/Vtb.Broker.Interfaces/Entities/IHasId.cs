namespace Vtb.Broker.Interfaces.Entities
{
    public interface IHasId
    {        
        long Id { get; set; }
    }
}
