using System;

namespace Vtb.Broker.Interfaces.Caching
{
    public class CachePolicy
    {
        public TimeSpan Lifetime { get; set; }
    }
}