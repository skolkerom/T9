namespace Vtb.Broker.Interfaces.Caching
{
    public interface ICache
    {
        void Add<TData>(string key, TData data, CachePolicy policy);
        TData Get<TData>(string key);
    }
}