using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Interfaces.Audit.Entities
{
    [Table("Audit", Schema = "rm")]
    public class Audit
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [DisplayName("Событие")]
        public AuditActionType ActionType { get; set; }

        [DisplayName("Время")]
        public DateTime EventDateTime { get; set; } = DateTime.Now;

        [DisplayName("Id сущности")]
        public long? EntityId { get; set; }

        [Required]
        [DisplayName("Пользователь")]
        public string User { get; set; }

        [DisplayName("Сообщение")]
        public string Message { get; set; }

        public string DetailsJson { get; set; }
        
        [DisplayName("IP адрес")]
        public string IpAddress { get; set; }

        [NotMapped]
        public AuditDetails Details { get; set; } = new AuditDetails();
    }
}
