using System.ComponentModel;

namespace Vtb.Broker.Interfaces.Audit.Entities
{
    public class AuditDetail
    {
        [DisplayName("Атрибут")]
        public string PropertyName { get; set; }
        
        [DisplayName("Старое значение")]
        public string OldValue { get; set; }

        [DisplayName("Новое значение")]
        public string NewValue { get; set; }
    }
}
