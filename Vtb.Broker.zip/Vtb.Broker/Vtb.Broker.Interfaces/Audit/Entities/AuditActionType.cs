using System.ComponentModel;

namespace Vtb.Broker.Interfaces.Audit.Entities
{
    public enum AuditActionType
    {
        [Description("Редактирование Категории")]
        RiskCategoryEdit = 1,
        [Description("Редактирование Ставки")]
        RiskRateEdit = 2,
        [Description("Редактирование Инструмента")]
        MarginInstrumentEdit = 3,
        [Description("Редактирование Списка инструментов")]
        MarginInstrumentListEdit = 4,
        [Description("Редактирование Инструмента в списке")]
        InstrumentInMarginInstrumentListEdit = 5,
        [Description("Загрузка файла с рисковыми ставками")]
        RiskFileUpload = 6,
        [Description("Генерация перекрытий РЕПО")]
        OvernightRepoGeneration = 7
    }
}
