using System.Collections.Generic;

namespace Vtb.Broker.Interfaces.Audit.Entities
{
    public class AuditDetails
    {
        public List<AuditDetail> Details {get;set;} = new List<AuditDetail>();
    }
}
