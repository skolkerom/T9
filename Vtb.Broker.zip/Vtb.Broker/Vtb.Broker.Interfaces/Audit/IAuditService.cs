﻿using System;
using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.Audit
{
    public interface IAuditService
    {
        Task SaveAsync(Entities.Audit audit);
        Task<Entities.Audit[]> GetAudits(DateTime startDate, DateTime endDate); 
    }
}