using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.MailLoader
{
    public interface IBrokerRiskManagementMailLoader
    {
        Task SaveAttachments(string targetDir);
    }
}