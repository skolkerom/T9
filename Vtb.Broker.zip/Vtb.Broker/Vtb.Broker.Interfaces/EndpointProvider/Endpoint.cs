﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Interfaces.EndpointProvider
{
    [Table("Endpoint", Schema = "rm")]
    public class Endpoint
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        
        [Required]
        public string Code { get; set; }
        
        [Required]
        public string Host { get; set; }

        [Required]
        public string Urls { get; set; }
    }
}