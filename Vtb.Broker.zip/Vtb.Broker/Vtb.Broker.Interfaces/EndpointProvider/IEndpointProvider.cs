﻿using System.Threading.Tasks;

namespace Vtb.Broker.Interfaces.EndpointProvider
{
    public interface IEndpointProvider
    {
        Endpoint GetEndpoint(string code);
    }
}