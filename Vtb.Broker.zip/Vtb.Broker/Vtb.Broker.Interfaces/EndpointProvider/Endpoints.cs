using System.Dynamic;

namespace Vtb.Broker.Interfaces.EndpointProvider
{
    public static class Endpoints
    {
        public const string OptimalRepoCalculator = "OptimalRepoCalculator";
        public const string RiskManagement = "RiskManagement";
        public const string AuthServer = "AuthServer";
        public const string MoexRiskDownloader = "MoexRiskDownloader";
        public const string XlsxConvertor = "XlsxConvertor";
    }
}