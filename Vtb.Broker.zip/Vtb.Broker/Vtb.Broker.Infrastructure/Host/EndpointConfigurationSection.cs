﻿namespace Vtb.Broker.Infrastructure.Host
{
    public class EndpointConfigurationSection
    {
        
        public ServiceConfigurationSection[] Services { get; set; }
    }
}