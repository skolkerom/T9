﻿namespace Vtb.Broker.Infrastructure.Host
{
    public class ServiceConfigurationSection
    {
        public string Name { get; set; }
        public string Host { get; set; }
    }
}