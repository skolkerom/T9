﻿using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using Hosting = Microsoft.Extensions.Hosting;

namespace Vtb.Broker.Infrastructure.Host
{
    public static class HostExtensions
    {
        public static IHostBuilder CreateVtbWebHostBuilder<TStartup>(string[] args, string serviceName) where TStartup : class
        {
            var config = IocConfigurator.AddVtbConfig();
            
            var webHostBuilder = Hosting.Host.CreateDefaultBuilder(args)
                .UseWindowsService()
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseConfiguration(config);
                    webBuilder.UseSetting(WebHostDefaults.DetailedErrorsKey, "true");
                    webBuilder.UseUrls(config.GetValue<string>(serviceName));
                    webBuilder.UseStartup<TStartup>();
                });

            return webHostBuilder;
        }
    } 
}