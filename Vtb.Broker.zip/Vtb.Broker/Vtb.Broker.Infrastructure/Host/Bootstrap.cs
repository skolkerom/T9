﻿using System;
using Microsoft.Extensions.CommandLineUtils;
using Microsoft.Extensions.Hosting;
using Vtb.Broker.Infrastructure.Application;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.Host
{
    public static class Bootstrap
    {
        public static void Run<TStartup, TDbContextBase>(string[] args, string application, ContextDesignTimeFactoryBase<TDbContextBase> contextFactory) 
            where TStartup : class
            where TDbContextBase : DbContextBase
        {
            var commandLineApplication = new CommandLineApplication(false);

            Action migrateAction = contextFactory != null 
                ? MigrateExtensions.GetMigrateAction(commandLineApplication, contextFactory)
                : () => {};

            Action runHostAction = HostExtensions.CreateVtbWebHostBuilder<TStartup>(args, application).Build().Run;

            commandLineApplication.OnExecute(() =>
            {
                migrateAction();
                runHostAction();
                return 0;
            }); 

            commandLineApplication.Execute(args);
        }
    }
}