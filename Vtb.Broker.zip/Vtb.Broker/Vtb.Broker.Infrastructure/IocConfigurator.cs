using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Serilog;
using Serilog.Events;
using Vtb.Broker.Infrastructure.Caching;
using Vtb.Broker.Infrastructure.IO;
using Vtb.Broker.Infrastructure.Mapper;
using Vtb.Broker.Infrastructure.Scheduler;
using Vtb.Broker.Infrastructure.Web;
using Vtb.Broker.Interfaces.IO;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.Interfaces.Caching;
using Vtb.Broker.Interfaces.Transport.Http;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Infrastructure.Alerts;
using Vtb.Broker.Infrastructure.Audit;
using Vtb.Broker.Infrastructure.Auth;
using Vtb.Broker.Infrastructure.EchangeService;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Infrastructure.EndpointProvider;
using Vtb.Broker.Infrastructure.FileDetector;
using Vtb.Broker.Infrastructure.FileDetector.DAL;
using Vtb.Broker.Infrastructure.FileDetector.Services;
using Vtb.Broker.Infrastructure.MailLoader;
using Vtb.Broker.Interfaces.Alerts;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.EndpointProvider;
using Vtb.Broker.Interfaces.MailLoader;

namespace Vtb.Broker.Infrastructure
{
    public static class IocConfigurator
    {
        public static void AddVtbAuthentication(this IServiceCollection services, IConfiguration configuration, Action<AuthenticationOptions> configurator = null)
        {
            services.AddTransient<TokenProvider>();
            services.AddTransient<TokenGenerator>();
            services.AddScoped<ICurrentUserProvider, CurrentUserProvider>();
            services.AddScoped<CurrentUserProvider>();
            
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            var authSection = configuration.GetSection("Jwt");
            var jwtSettings = authSection.Get<JwtSettings>();

            services.AddSingleton(jwtSettings);
            
            services.AddSingleton(x =>
            {
                var conf = x.GetRequiredService<IConfiguration>();
                var logger = x.GetRequiredService<ILogger<ZFrontUserPasswordSignInManager>>();
                
                return new ZFrontUserPasswordSignInManager(conf.GetConnectionString("DefaultConnection"),
                    conf.GetConnectionString("zfrontConnection"), logger);
            });
            
            services.AddSingleton(x =>
            {
                var conf = x.GetService<IConfiguration>();
                return new InternalUserPasswordSignInManager(conf.GetConnectionString("DefaultConnection"));
            });
            
            services.AddSingleton(x =>
            {
                var conf = x.GetService<IConfiguration>();
                return new BackOfficeSignInManager(conf.GetConnectionString("DefaultConnection"));
            });

            services.AddSingleton<SignInManagerFactory>();
            
            services.AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme =
                        CookieAuthenticationDefaults.AuthenticationScheme;
                    options.DefaultSignInScheme =
                        CookieAuthenticationDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme =
                        CookieAuthenticationDefaults.AuthenticationScheme;

                    configurator?.Invoke(options);
                })
                .AddCookie(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
                {
                    var privateKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtSettings.SecurityKey));
                    
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ClockSkew = TimeSpan.Zero,

                        ValidateAudience = true,
                        ValidAudience = jwtSettings.Audience,

                        ValidateIssuer = true,
                        ValidIssuer = jwtSettings.Issuer,

                        IssuerSigningKey = privateKey,
                        ValidateIssuerSigningKey = true,

                        RequireExpirationTime = true,
                        ValidateLifetime = true
                    };
                });
        }
        
        
        public static IConfigurationRoot AddVtbConfig(this IServiceCollection services, Action<IConfigurationRoot> configurator = null, string environment = null)
        {
            return AddVtbConfig(configurator, environment);
        }

        public static IConfigurationRoot AddVtbConfig(Action<IConfigurationRoot> configurator = null, string environment = null, bool loadEndpointSettings = true)
        {
            environment ??= Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            var configLocation = Path.Combine(GetCurrentDirectory(), @"..\conf\appsettings.json");
            
            var envConfigLocation = Path.Combine(GetCurrentDirectory(), $@"..\conf\appsettings.{environment}.json");

            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", false)
                .AddJsonFile($"appsettings.{environment}.json", true)
                .AddJsonFile(configLocation, true)
                .AddJsonFile(envConfigLocation, true);
                    
            if(loadEndpointSettings)   
                builder.AddEndpoint();
     
            var config = builder.Build();

            configurator?.Invoke(config);

            return config;
        }

        public static void AddVtbAlerts(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddExchangeServices();
            services.AddTransient<IAlertService, AlertService>();
            
            var connectionString = GetDefaultConnectionString(configuration);

            services.AddSingleton<IContextFactory<AlertContext>>(container =>
                new ContextFactory<AlertContext>(() => new AlertContext(connectionString),
                    container.GetRequiredService<ILoggerFactory>()));
        }

        public static void AddVtbLogging(this IServiceCollection services)
        {
            var logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .Enrich.FromLogContext()
                .WriteTo.Logger(lc => lc.Filter
                    .ByIncludingOnly(x => x.Level == LogEventLevel.Information)
                    .WriteTo.Console()
                    .WriteTo.File(Path.Combine(GetCurrentDirectory(), @"logs\main.log"),
                        rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true,
                        fileSizeLimitBytes: 1024 * 1024 * 100))
                .WriteTo.Logger(lc => lc.Filter
                    .ByIncludingOnly(x => x.Level == LogEventLevel.Debug)
                    .WriteTo.File(Path.Combine(GetCurrentDirectory(), @"logs\debug.log"),
                        rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true,
                        fileSizeLimitBytes: 1024 * 1024 * 100)
                )
                .CreateLogger();
                
            Log.Logger = logger;

            services?.AddLogging(x => x.AddSerilog(logger));
        }

        private static string GetCurrentDirectory()
        {
            return new FileInfo(Assembly.GetExecutingAssembly().Location).Directory?.FullName;
        }

        public static void AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {            
            services.AddSingleton<IFileUploader, FileUploader>();            
            services.AddSingleton<ICache, Cache>();
            services.AddSingleton<IWebRequestService, WebRequestService>();

            AddEndpointProvider(services, configuration);
            AddAudit(services, configuration);
        }

        public static void AddMapper(this IServiceCollection services, Action<IMapperConfigurationExpression> configurator)
        {
            var config = new MapperConfiguration(cfg => configurator(cfg));

            var mapper = config.CreateMapper();

            var mapperService = new MapperService(mapper);

            services.AddSingleton<IMapperService>(mapperService);
        }

        public static void AddScheduler(this IServiceCollection services, IConfiguration configuration )
        {
            var connectionString = GetDefaultConnectionString(configuration);
            
            services.AddSingleton<IContextFactory<PersisterContext>>(container =>
                new ContextFactory<PersisterContext>(() => new PersisterContext(connectionString),
                    container.GetRequiredService<ILoggerFactory>(), true));
            
            services.AddSingleton<IJobFactory, DefaultJobFactory>();
            services.AddSingleton<InternalJobConfigurator>();
            services.AddSingleton<JobConfigurator>();
            services.AddSingleton<IJobPersister, JobPersister>();
            services.AddSingleton<SchedulerManager>();
            services.AddSingleton<ISchedulerFacade, SchedulerFacade>();
        }

        public static void UseScheduler(this IServiceProvider serviceProvider, string applicationName, Action<JobConfigurator> configureJobs)
        {
            var configurator = serviceProvider.GetRequiredService<JobConfigurator>();

            configureJobs(configurator);

            var manager = serviceProvider.GetRequiredService<SchedulerManager>();

            Task.Run(async () => await manager.Start(applicationName));
        }

        public static void AddFileDetector(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<FileDetectorConfigurator>();
            services.AddFileDetectorRepositories(configuration);
            services.AddSingleton<FileDetectorService>();

            var fileDetectorSection = configuration.GetSection("FileDetector");
            var fileDetectorSettings = fileDetectorSection.Get<FileDetectorServiceSettings>();
            
            services.AddSingleton(new FileDetectorServiceSettings
            {
                StoragePath = fileDetectorSettings.StoragePath
            });
        }

        public static void UseFileDetector(this IServiceProvider serviceProvider, string applicationName, Action<FileDetectorConfigurator> configureFileDetector)
        {
            var configurator = serviceProvider.GetRequiredService<FileDetectorConfigurator>();
            configureFileDetector(configurator);

            var fds = serviceProvider.GetRequiredService<FileDetectorService>();

            Task.Run(() => fds.MonitorFiles(applicationName));
        }

        public static void AddExchangeServices(this IServiceCollection services)
        {
            services.AddTransient<IBrokerRiskManagementMailLoader, BrokerRiskManagementMailLoader>();
            services.AddTransient<IExchangeServiceFactory, ExchangeServiceFactory>();
        }

        private static void AddEndpointProvider(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = GetDefaultConnectionString(configuration);

            services.AddSingleton<IContextFactory<Context>>(container =>
                new ContextFactory<Context>(() => new Context(connectionString),
                    container.GetRequiredService<ILoggerFactory>(), true));

            services.AddTransient<IEndpointProvider, EndpointProvider.EndpointProvider>();
        }

        private static string GetDefaultConnectionString(IConfiguration configuration)
        {
            return configuration.GetConnectionString("DefaultConnection");
        }

        private static void AddAudit(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = GetDefaultConnectionString(configuration);

            services.AddSingleton<IContextFactory<AuditContext>>(container =>
                new ContextFactory<AuditContext>(() => new AuditContext(connectionString),
                    container.GetRequiredService<ILoggerFactory>()));

            services.AddTransient<IAuditService, AuditService>();
        }
    }
}