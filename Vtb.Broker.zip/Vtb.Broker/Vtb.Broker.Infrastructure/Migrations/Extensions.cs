﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.Migrations
{
    public static class Extensions
    {
        public static void DeploySqlFile(this MigrationBuilder builder, string path)
        {
            var script = Path.Combine(MigrationExtensions.GetSqlScriptsDirectory(), path);

            builder.Sql(File.ReadAllText(script));
        }
    }
}