using AutoMapper;
using Vtb.Broker.Interfaces.Mapper;

namespace Vtb.Broker.Infrastructure.Mapper
{
    public class MapperService : IMapperService
    {
        private readonly IMapper _mapper;

        public MapperService(IMapper mapper)
        {
            _mapper = mapper;
        }
        
        public TTarget Map<TTarget>(object source)
        {
            return _mapper.Map<TTarget>(source);
        }
        
        public TTarget Map<TSource, TTarget>(TSource source)
        {
            return _mapper.Map<TSource, TTarget>(source);
        }

        public TTarget Map<TSource, TTarget>(TSource source, TTarget target)
        {            
            return _mapper.Map(source, target);
        }
    }
}