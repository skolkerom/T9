﻿namespace Vtb.Broker.Infrastructure.EchangeService
{
    public class MailSettings
    {
        public string Email { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
    }
}