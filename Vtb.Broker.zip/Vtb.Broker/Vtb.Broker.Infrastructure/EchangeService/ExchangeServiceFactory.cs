﻿using System;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using ExchangeData = Microsoft.Exchange.WebServices.Data;

namespace Vtb.Broker.Infrastructure.EchangeService
{
    public class ExchangeServiceFactory : IExchangeServiceFactory
    {
        private static string _currentServiceUrl;
        private readonly IConfiguration _config;

        public ExchangeServiceFactory(IConfiguration config)
        {
            _config = config;
        }
        
        private async Task<ExchangeData.ExchangeService> Create(MailSettings mailSettings)
        {
            if(string.IsNullOrEmpty(_currentServiceUrl))
                _currentServiceUrl = _config.GetSection("Exchange").GetSection("ServiceUrl").Value;

            var credentials = new NetworkCredential(mailSettings.User, mailSettings.Password);
            
            var service = new ExchangeData.ExchangeService(ExchangeData.ExchangeVersion.Exchange2007_SP1)
            {
                Credentials = credentials,
                Url = new Uri(_currentServiceUrl),
                TraceEnabled = true,
                TraceFlags = ExchangeData.TraceFlags.All
            };

            var successTest = await service.TestConnection(credentials);
            if (successTest) 
                return service;
            
            service.AutodiscoverUrl(mailSettings.Email, x => true);
            _currentServiceUrl = service.Url.AbsoluteUri;

            //service.WebProxy = _proxyFactory.CreateWebProxy();

            return service;
        }

        public async Task<ExchangeData.ExchangeService> Create(string mailSettingSection)
        {
            var mailSettings = GetMailSettings(mailSettingSection);

            return await Create(mailSettings);
        }
        
        private MailSettings GetMailSettings(string mailSection)
        {
            var section = _config.GetSection(mailSection);
            
            return new MailSettings
            {
                Email = section.GetSection("MailBox").Value,
                User = section.GetSection("User").Value,
                Password = section.GetSection("Password").Value
            };
        }
    }
}