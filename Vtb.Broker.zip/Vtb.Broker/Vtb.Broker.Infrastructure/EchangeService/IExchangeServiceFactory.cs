﻿using System.Threading.Tasks;
using ExchangeData = Microsoft.Exchange.WebServices.Data;

namespace Vtb.Broker.Infrastructure.EchangeService
{
    public interface IExchangeServiceFactory
    {
        Task<ExchangeData.ExchangeService> Create(string mailSectionName);
    }
}