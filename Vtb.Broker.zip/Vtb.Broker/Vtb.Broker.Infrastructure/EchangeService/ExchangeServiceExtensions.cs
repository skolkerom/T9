﻿using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ExchangeData = Microsoft.Exchange.WebServices.Data;

namespace Vtb.Broker.Infrastructure.EchangeService
{
    public static class ExchangeServiceExtensions
    {
        public static async Task<ExchangeData.FindItemsResults<ExchangeData.Item>> SaveAttachments(this ExchangeData.ExchangeService service, string mailBox, string[] acceptedSenders, string targetDir) 
        {
            var iView = new ExchangeData.ItemView(100);

            var filter = new ExchangeData.SearchFilter.SearchFilterCollection(ExchangeData.LogicalOperator.Or);
            if (acceptedSenders.Any())
                filter = CreateSenderFilter(filter, acceptedSenders);

            var folderId = new ExchangeData.FolderId(ExchangeData.WellKnownFolderName.Inbox, new ExchangeData.Mailbox(mailBox));
            
            var findResults = await service.FindItems(folderId, filter, iView);

            foreach(var item in findResults)
                await SaveAttachments(service, item.Id, targetDir);

            return findResults;
        }

        private static ExchangeData.SearchFilter.SearchFilterCollection CreateSenderFilter(ExchangeData.SearchFilter.SearchFilterCollection filter, string[] acceptedEmails)
        {
            var riskRateEmails = acceptedEmails.Select(e => new ExchangeData.EmailAddress(e));

            foreach (var email in riskRateEmails)
            {
                var f = new ExchangeData.SearchFilter.IsEqualTo(ExchangeData.EmailMessageSchema.From, email);
                filter.Add(f);
            }
            
            return filter;
        }

        private static async Task SaveAttachments(ExchangeData.ExchangeService service, ExchangeData.ItemId itemId, string targetDir) 
        {
            var message = await ExchangeData.EmailMessage.Bind(service, itemId, new ExchangeData.PropertySet(ExchangeData.ItemSchema.Attachments));
            
            foreach (var attachment in message.Attachments)
            {
                var fileAttachment = (attachment as ExchangeData.FileAttachment);
                var a = (fileAttachment?.Load().Result[0].Attachment  as ExchangeData.FileAttachment);
                var byteContent = a?.Content;
                
                File.WriteAllBytes(Path.Combine(targetDir, a.Name), byteContent);
            }
        }
        
        public static async Task MoveEmails(this ExchangeData.ExchangeService service, ExchangeData.FindItemsResults<ExchangeData.Item> findResults, string email, string targetEmailDir)
        {
            if (findResults.Any())
            {
                var fView = new ExchangeData.FolderView(100);

                var isHiddenProp = new ExchangeData.ExtendedPropertyDefinition(0x10f4, ExchangeData.MapiPropertyType.Boolean);
                fView.PropertySet = new ExchangeData.PropertySet(ExchangeData.BasePropertySet.IdOnly,
                    ExchangeData.FolderSchema.DisplayName, isHiddenProp);
                fView.Traversal = ExchangeData.FolderTraversal.Deep;
                var findFolderResults = await service.FindFolders(
                    new ExchangeData.FolderId(ExchangeData.WellKnownFolderName.MsgFolderRoot, new ExchangeData.Mailbox(email)),
                    fView);
                var processedFolder = findFolderResults.First(f => f.DisplayName == targetEmailDir);

                await service.MoveItems(findResults.Select(i => i.Id), processedFolder.Id);
            }
        }

        public static async Task Send(this ExchangeData.ExchangeService service, string sender, string[] recipients, string subject, string body)
        {
                var message = new ExchangeData.EmailMessage(service)
                {
                    Sender =  new ExchangeData.EmailAddress(sender),
                    Subject = subject, 
                    Body = body
                };
                message.ToRecipients.AddRange(recipients);
                await message.SendAndSaveCopy();
        }
        
        public static async Task<bool> TestConnection(this ExchangeData.ExchangeService service, NetworkCredential credentials)
        {
            try
            {
                var client = new WebClient {Credentials = credentials};
                await client.DownloadDataTaskAsync (service.Url);
                return await Task.FromResult(true);
            }
            catch
            {
                return await Task.FromResult(false);
            }
        }
    }
}