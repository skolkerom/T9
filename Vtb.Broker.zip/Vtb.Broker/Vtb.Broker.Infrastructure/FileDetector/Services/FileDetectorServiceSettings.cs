namespace Vtb.Broker.Infrastructure.FileDetector.Services
{
    public class FileDetectorServiceSettings
    {
        public string StoragePath {get;set;}
    }
}
