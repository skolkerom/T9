﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Interfaces.FileDetector;
using Vtb.Broker.Interfaces.FileDetector.Entities;

namespace Vtb.Broker.Infrastructure.FileDetector.Services
{
    public class FileDetectorService
    {
        private readonly IFileDetectorQueryRepository _queryRepository;
        private readonly IFileDetectorCommandRepository _commandRepository;
        private readonly FileDetectorServiceSettings _settings;
        private readonly FileDetectorConfigurator _configurator;
        private readonly ILogger<FileDetectorService> _logger;

        public FileDetectorService(IFileDetectorQueryRepository queryRepository,
            IFileDetectorCommandRepository commandRepository,
            FileDetectorServiceSettings settings, 
            FileDetectorConfigurator configurator, 
            ILogger<FileDetectorService> logger)
        {
            _queryRepository = queryRepository;
            _commandRepository = commandRepository;
            _settings = settings;
            _configurator = configurator;
            _logger = logger;
        }

        public async Task MonitorFiles(string applicationName)
        {
            var fDetectors = await _queryRepository.GetFileDetectorsWithTransformedPaths(applicationName); 

            var tasks = new List<Task>();

            foreach(var detector in fDetectors)
            {               
                var settings = new FileWatcherSettings
                {
                    FileDetector = detector,
                    ProcessedDirectoryPath = Path.Combine(_settings.StoragePath, "Processed")
                };

                var fw = new FileWatcher(settings, _logger);

                fw.CreatedFiles += async (file) => 
                {
                    var fileName = Path.GetFileName(file.FilePath);

                    var processedFile = new ProcessedFile
                    {
                        FilePath = file.FilePath, 
                        FileDetectorId = file.DetectorId, 
                        FileName = fileName, 
                        Timestamp = DateTime.Now
                    };

                    var fileId = await _commandRepository.SaveAsync(processedFile);

                    var msg = new NewFileMessage
                    {
                        EventTime = DateTime.Now,
                        FileId = fileId,
                        FileName = fileName,
                        FileType = file.FileType,
                        Path = file.FilePath
                    };

                    try
                    {
                        await _configurator.HandleFile(msg);
                    }
                    catch (Exception e)
                    {
                        processedFile.Error = e.Message;
                        await _commandRepository.SaveAsync(processedFile);
                        _logger.LogError(e.Message);
                    }
                };

                tasks.Add(fw.StartWatch());
            }

            await Task.WhenAll(tasks);
        }
    }
}
