﻿namespace Vtb.Broker.Infrastructure.FileDetector
{
    public class NewFileEventArgs
    {
        public NewFileEventArgs(string filePath, string fileType, long detectorId)
        {
            FilePath = filePath;
            FileType = fileType;
            DetectorId = detectorId;
        }

        public string FilePath { get; set; }
        public string FileType { get; set; }
        public long DetectorId { get; set; }
    }
}
