using System.Threading.Tasks;
using Vtb.Broker.Utils;
using Vtb.Broker.Infrastructure.FileDetector.Parsers;

namespace Vtb.Broker.Infrastructure.FileDetector
{
    public class FileDetectorConfigurator
    {
        private readonly FileHandler _fileHandler;

        public FileDetectorConfigurator(FileHandler fileHandler)
        {            
            _fileHandler = fileHandler;
        }

        public FileDetectorConfigurator RegisterParser<TParser>(string fileType)
        {            
            _fileHandler.RegisterParser<TParser>(fileType);
            return this;
        }

        public FileDetectorConfigurator RegisterHandler<THandler>(string fileType) 
        {            
            _fileHandler.RegisterHandler<THandler>(fileType);
            return this;
        }

        public async Task HandleFile(NewFileMessage file) 
        {
            await _fileHandler.ParseAndHandle(file);
        }
    }
}