﻿using System;

namespace Vtb.Broker.Infrastructure.FileDetector.Adapters
{
    public interface IFileDetectorMigrator : IDisposable
    {
        void Migrate();
    }
}
