﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.FileDetector.Parsers.RiskRates
{
    public class MoexParser : IParser<RiskRate>
    {
        public RiskRate[] Parse(NewFileMessage file)
        {
            var rates = new List<RiskRate>();

            using var xmlReader = XmlReader.Create(file.Path);
            
            xmlReader.MoveToContent();

            while (xmlReader.Read())
            {
                if (xmlReader.Name == "data" && xmlReader.GetAttribute("id") != "irr")
                    break;

                if (xmlReader.Name == "row")
                {
                    if (!(XNode.ReadFrom(xmlReader) is XElement row))
                        throw new Exception("MOEX risk file: row cannot be empty");
                    var updateDate = DateTime.TryParseExact(row.GetAttrValue("tradedate"), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime rateDate);
                    var ticker = row.GetAttrValue("instrument");
                    var isin = row.GetAttrValue("isin");
                    var rateLong = decimal.TryParse(row.GetAttrValue("r_l"), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal rl);
                    var rateShort = decimal.TryParse(row.GetAttrValue("r_s"), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal rs);
                    rl = rl.PercentageToRate();
                    rs = rs.PercentageToRate();
                    rates.Add(new RiskRate
                    {
                        Source = RiskRateSource.Nsd,
                        Isin = isin,
                        RateDate = rateDate,
                        RateLong = rl,
                        RateShort = rs,
                        FileName = file.FileName,
                        CreatedDate = DateTime.Now,
                        CreatedUser = User.SystemUser.Name,
                        ModifiedDate = DateTime.Now,
                        ModifiedUser = User.SystemUser.Name
                    });
                }
            }
            return rates.ToArray();
        }
    }
}
