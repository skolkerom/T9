﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Xml;
using System.Xml.Linq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.FileDetector.Parsers.RiskRates
{
    public class MfbParser : IParser<RiskRate>
    {
        public RiskRate[] Parse(NewFileMessage file)
        {
            var rates = new List<RiskRate>();
            var currencyPairs = new Dictionary<string, string>{ {BrokerConstants.EURRUB, BrokerConstants.EUR}, {BrokerConstants.USDRUB, BrokerConstants.USD} }; 

            using var xmlReader = XmlReader.Create(file.Path);
            
            xmlReader.MoveToContent();

            while (xmlReader.Read())
            {
                var (sec, rec) = GetElements(xmlReader);

                if (!Valid(sec, rec))
                    continue;

                var isin = sec.GetAttrValue("ISIN");
                var ticker = sec.GetAttrValue("Ticker");
                
                if(string.IsNullOrEmpty(isin) && !currencyPairs.ContainsKey(ticker))
                    continue;
                
                decimal.TryParse(rec.GetAttrValue("RateUp"), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal rateLong);
                decimal.TryParse(rec.GetAttrValue("RateDown"), NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out decimal rateShort);
                var updateDateString = rec.GetAttrValue("UpdateDate") + rec.GetAttrValue("UpdateTime");
                DateTime.TryParseExact(updateDateString, "yyyy-MM-ddHH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime updateDate);

                rates.Add(new RiskRate
                {
                    Source = RiskRateSource.Mfb,
                    Isin = string.IsNullOrEmpty(isin) ? currencyPairs[ticker] : isin, 
                    RateLong = rateLong,
                    RateShort = rateShort,
                    RateDate = updateDate,
                    FileName = file.FileName,
                    CreatedDate = DateTime.Now,
                    CreatedUser = User.SystemUser.Name,
                    ModifiedDate = DateTime.Now,
                    ModifiedUser = User.SystemUser.Name
                });
            }
            return rates.ToArray();
        }

        private bool Valid(XElement sec, XElement rec)
        {
            if (sec == null && rec == null)
                return false;
            if (sec == null)
                throw new Exception("SECURITY element cannot be empty");
            if (rec == null)
                throw new Exception("RECORDS element cannot be empty");
            return true;
        }

        private (XElement sec, XElement rec) GetElements(XmlReader xmlReader)
        {
            if (xmlReader.Name == "SECURITY")
            {
                var sec = XNode.ReadFrom(xmlReader) as XElement;
                var rec = sec.Element("RECORDS");
                return (sec, rec);
            }

            return (null, null);
        }
    }
}
