﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.FileDetector.Parsers
{
    public class FileHandler
    {
        private readonly Dictionary<string, Type> _consumers = new Dictionary<string, Type>();
        private readonly ILogger<FileHandler> _logger;
        private readonly Dictionary<string, Type> _parsers = new Dictionary<string, Type>();
        private readonly IServiceProvider _serviceProvider;

        public FileHandler(ILogger<FileHandler> logger, IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public void RegisterParser<TParser>(string fileType)
        {
            _parsers.Add(fileType, typeof(TParser));
        }

        public void RegisterHandler<TConsumer>(string fileType)
        {
            if (string.IsNullOrEmpty(fileType))
                throw new Exception("FileType must not be null or empty. Possibly parser was not registered");

            _consumers.Add(fileType, typeof(TConsumer));
        }

        public async Task ParseAndHandle(NewFileMessage file)
        {
            var parserType = _parsers[file.FileType];

            var parser = _serviceProvider.GetService(parserType);

            var parseMethod = parserType.GetMethod("Parse");

            if (parseMethod == null)
                throw new Exception("Parser must have Parse method");

            var result = parseMethod.Invoke(parser, new[] {file});

            _consumers.TryGetValue(file.FileType, out var consumerType);

            using var scope = _serviceProvider.CreateScope();
            var consumer = scope.ServiceProvider.GetRequiredService(consumerType);
            var consumerInterfaceType = consumerType?.GetInterfaces().First(i => i.Name.StartsWith("IConsumer"));

            var messageType = consumerInterfaceType?.GetGenericArguments().FirstOrDefault();

            var messageContextType = typeof(MessageContext<>).MakeGenericType(messageType);
            var messageContext = Activator.CreateInstance(messageContextType);

            var messageProperty = messageContextType.GetProperty("Message");
            messageProperty?.SetValue(messageContext, result);

            var consumeMethod = consumerType?.GetMethod("Consume");

            if (consumeMethod == null)
                throw new Exception("Consumer must have Consume method");

            await Task.Run(() => consumeMethod.Invoke(consumer, new[] {messageContext}));
        }
    }
}