using System;
using Microsoft.Extensions.DependencyInjection;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Infrastructure.Auth;
using Vtb.Broker.Infrastructure.FileDetector.Parsers.RiskRates;

namespace Vtb.Broker.Infrastructure.FileDetector.Parsers
{
    public static class Extensions
    {
        public static void AddAdapters(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<MfbParser>();
            serviceCollection.AddTransient<MoexParser>();
            serviceCollection.AddSingleton<FileHandler>();
        }
    }
}