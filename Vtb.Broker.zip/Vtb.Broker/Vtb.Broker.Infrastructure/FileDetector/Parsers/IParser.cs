﻿using System.Collections.Generic;

namespace Vtb.Broker.Infrastructure.FileDetector.Parsers
{
    public interface IParser<out T>
    {
        T[] Parse(NewFileMessage file);
    }
}
