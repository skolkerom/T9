﻿using System;

namespace Vtb.Broker.Infrastructure.FileDetector
{
    public class NewFileMessage {
        public string Path { get; set; }
        public string FileName { get; set; }
        public DateTime EventTime { get; set; }
        public string FileType { get; set; }
        public long FileId { get; set; }
    }
}
