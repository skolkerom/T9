﻿namespace Vtb.Broker.Infrastructure.FileDetector
{
    public class FileWatcherSettings
    {
        public Interfaces.FileDetector.Entities.FileDetector FileDetector { get; set; }

        public string ProcessedDirectoryPath { get; set; }
    }
}
