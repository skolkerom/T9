﻿using System.Threading.Tasks;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.FileDetector;
using Vtb.Broker.Interfaces.FileDetector.Entities;

namespace Vtb.Broker.Infrastructure.FileDetector.DAL.Repositories
{
    public class FileDetectorCommandRepository : IFileDetectorCommandRepository
    {
        private readonly IContextFactory<FileDetectorContext> _factory;

        public FileDetectorCommandRepository(IContextFactory<FileDetectorContext> factory)
        {
            _factory = factory;
        }
        public async Task<long> SaveAsync(ProcessedFile processedFile)
        {
            await using var context = _factory.Create();

            if (processedFile.Id == 0)
                context.ProcessedFiles.Add(processedFile);
            else context.ProcessedFiles.Update(processedFile);
            
            await context.SaveChangesAsync();
            return processedFile.Id;
        }
    }
}
