using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Infrastructure.FileDetector.Services;
using Vtb.Broker.Interfaces.FileDetector;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.FileDetector.DAL.Repositories
{
    public class FileDetectorQueryRepository : IFileDetectorQueryRepository
    {
        private readonly IContextFactory<FileDetectorContext> _contextFactory;
        private readonly FileDetectorServiceSettings _settings;

        public FileDetectorQueryRepository(IContextFactory<FileDetectorContext> contextFactory, FileDetectorServiceSettings settings)
        {
            _contextFactory = contextFactory;
            _settings = settings;
        }
        
        public async Task<Interfaces.FileDetector.Entities.FileDetector[]> GetFileDetectorsWithTransformedPaths()
        {
            return (await  GetFileDetectors())
                .ForEachEx(d => d.Path = d.Path.Replace($"%{nameof(_settings.StoragePath)}%", _settings.StoragePath))
                .ToArray();
        }
        
        public async Task<Interfaces.FileDetector.Entities.FileDetector[]> GetFileDetectorsWithTransformedPaths(string applicationName)
        {
            return (await  GetFileDetectors(applicationName))
                .ForEachEx(d => d.Path = d.Path.Replace($"%{nameof(_settings.StoragePath)}%", _settings.StoragePath))
                .ToArray();
        }

        private async Task<Interfaces.FileDetector.Entities.FileDetector[]> GetFileDetectors(string applicationName = null)
        {
            await using var context = _contextFactory.Create();

            var query = context.FileDetectors.AsQueryable();

            if (applicationName != null)
            {
                query = query.Where(f => f.ApplicationName == applicationName);
            }

            return await query.Where(c => c.Enabled).ToArrayAsync();
        }
    }
}
