﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.FileDetector.DAL.Migrations
{
    public partial class Init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "rm");

            migrationBuilder.CreateTable(
                name: "FileDetector",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(nullable: true),
                    Path = table.Column<string>(nullable: true),
                    Mask = table.Column<string>(nullable: true),
                    Enabled = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileDetector", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProcessedFile",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FilePath = table.Column<string>(nullable: true),
                    FileDetectorId = table.Column<long>(nullable: false),
                    FileName = table.Column<string>(nullable: true),
                    Timestamp = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcessedFile", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProcessedFile_FileDetector_FileDetectorId",
                        column: x => x.FileDetectorId,
                        principalSchema: "rm",
                        principalTable: "FileDetector",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProcessedFile_FileDetectorId",
                schema: "rm",
                table: "ProcessedFile",
                column: "FileDetectorId");

            migrationBuilder.InsertData("FileDetector",
              new[] { "Type", "Path", "Mask", "Enabled" },
              new object[,]{
                  { "NewMfbRiskFile", @"C:\Vtb\RiskRates\Mfb", "*.*", true },
                  { "NewMoexRiskFile", @"C:\Vtb\RiskRates\Moex",   "*.*", true }}
                  , "rm"
              );                
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProcessedFile",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "FileDetector",
                schema: "rm");
        }
    }
}
