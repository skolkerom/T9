﻿using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.FileDetector.Adapters;

namespace Vtb.Broker.Infrastructure.FileDetector.DAL.Migrations
{
    public class FileDetectorMigrator : IFileDetectorMigrator
    {
        private readonly FileDetectorContext context;

        public FileDetectorMigrator(FileDetectorContext context)
        {
            this.context = context;
        }

        public void Migrate()
        {
            context.Database.Migrate();
        }

        public void Dispose() { }
    }
}
