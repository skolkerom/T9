﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.FileDetector.DAL.Migrations
{
    public partial class AddDescription : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Description",
                schema: "rm",
                table: "FileDetector",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Description",
                schema: "rm",
                table: "FileDetector");
        }
    }
}
