﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.FileDetector.DAL
{
  public class DesignTimeDbContextFactory : ContextDesignTimeFactoryBase<FileDetectorContext>
  {
    public DesignTimeDbContextFactory() 
        : base(ConnectionStringsNames.DefaultConnection)
    {
    }
  }
}
