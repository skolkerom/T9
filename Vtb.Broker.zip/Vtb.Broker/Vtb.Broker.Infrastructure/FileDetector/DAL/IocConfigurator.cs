﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Infrastructure.FileDetector.Adapters;
using Vtb.Broker.Infrastructure.FileDetector.DAL.Migrations;
using Vtb.Broker.Infrastructure.FileDetector.DAL.Repositories;
using Vtb.Broker.Interfaces.FileDetector;

namespace Vtb.Broker.Infrastructure.FileDetector.DAL
{
    public static class IocConfigurator
    {
        public static void AddFileDetectorRepositories(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString(ConnectionStringsNames.DefaultConnection);
            
            services.AddSingleton<IContextFactory<FileDetectorContext>>(container =>
                new ContextFactory<FileDetectorContext>(() => new FileDetectorContext(connectionString),
                    container.GetRequiredService<ILoggerFactory>()));
            
            services.AddSingleton<IFileDetectorQueryRepository, FileDetectorQueryRepository>();
            services.AddSingleton<IFileDetectorCommandRepository, FileDetectorCommandRepository>();
            services.AddDbContext<FileDetectorContext>();
            services.AddScoped<IFileDetectorMigrator, FileDetectorMigrator>();
        }
    }
}
