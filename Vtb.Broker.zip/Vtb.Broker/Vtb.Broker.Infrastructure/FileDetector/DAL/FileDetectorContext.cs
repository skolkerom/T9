﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.FileDetector.Entities;

namespace Vtb.Broker.Infrastructure.FileDetector.DAL
{
    public class FileDetectorContext : DbContextBase
    {
        public virtual DbSet<Interfaces.FileDetector.Entities.FileDetector> FileDetectors { get; set; }

        public virtual DbSet<ProcessedFile> ProcessedFiles { get; set; }

        public FileDetectorContext([NotNull] DbContextOptions options) : base(options)
        {
        }

        public FileDetectorContext(string connectionString)
            :base(connectionString)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ProcessedFile>()
                .HasKey(f => f.Id);
            modelBuilder.Entity<ProcessedFile>()
                .HasOne(f => f.FileDetector)
                .WithMany(d => d.ProcessedFiles)
                .HasForeignKey(f => f.FileDetectorId);
        }
    }
}
