﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Vtb.Broker.Infrastructure.FileDetector
{
    public class FileWatcher
    {
        private readonly FileWatcherSettings _settings;
        private readonly ILogger _logger;

        public delegate Task NewFileDelegate(NewFileEventArgs newFile);

        public event NewFileDelegate CreatedFiles;

        public FileWatcher(FileWatcherSettings fileSystemWatcherSettings, ILogger logger)
        {
            _settings = fileSystemWatcherSettings;
            _logger = logger;
        }

        public async Task<IEnumerable<NewFileEventArgs>> StartWatch()
        {
            const int delay = 5000;

            if (!Directory.Exists(_settings.FileDetector.Path))
                Directory.CreateDirectory(_settings.FileDetector.Path);

            while (true)
            {
                try
                {
                    var newFiles = await Task.Run(() =>
                        Directory.GetFiles(_settings.FileDetector.Path, _settings.FileDetector.Mask, SearchOption.AllDirectories));

                    foreach (var filePath in newFiles)
                    {
                        var fileName = $"{Path.GetFileNameWithoutExtension(filePath)}{DateTime.Now:HHmmss}{Path.GetExtension(filePath)}";

                        var processedFilePath = Path.GetFullPath(Path.Combine(_settings.ProcessedDirectoryPath,
                                $@"{_settings.FileDetector.Type}\{DateTime.Now.Year}\{DateTime.Now.Month}\{DateTime.Now:dd}\{fileName}"));

                        try
                        {
                            _logger.LogInformation($"{_settings.FileDetector.Id}.{_settings.FileDetector.Type}: File {filePath} found");

                            await Task.Run(() =>
                            {
                                Directory.CreateDirectory(Path.GetDirectoryName(processedFilePath));
                                File.Copy(filePath, processedFilePath);
                            });

                            _logger.LogInformation($"File {filePath} was copied to processed directory");

                            var subscriptions = CreatedFiles;
                            if (subscriptions != null)
                            {
                                var nfa = new NewFileEventArgs(processedFilePath, _settings.FileDetector.Type, _settings.FileDetector.Id);
                                await subscriptions.Invoke(nfa);
                            }

                            await Task.Run(() => File.Delete(filePath));
                        }
                        catch (Exception e)
                        {
                            _logger.LogError(e, $"error on processing file {_settings.FileDetector.Id}.{_settings.FileDetector.Type}.{fileName}");
                        }
                    }                    
                }
                catch (Exception e)
                {
                    _logger.LogError(e, $"error on processing files {_settings.FileDetector.Id}.{_settings.FileDetector.Type}");                    
                }
                
                await Task.Delay(delay);
            }
        }
    }
}
