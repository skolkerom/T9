
using Vtb.Broker.Interfaces.Caching;
using Microsoft.Extensions.Caching.Memory;


namespace Vtb.Broker.Infrastructure.Caching
{
    public class Cache : ICache
    {
        private readonly MemoryCache _cache = new MemoryCache(new MemoryCacheOptions());

        public void Add<TData>(string key, TData data, CachePolicy policy)
        {
            _cache.Set(key, data, policy.Lifetime);
        }

        public TData Get<TData>(string key)
        {
            return _cache.Get<TData>(key);
        }
    }
}