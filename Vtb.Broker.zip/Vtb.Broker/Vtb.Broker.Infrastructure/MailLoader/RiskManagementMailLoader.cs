using ExchangeData = Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Interfaces.MailLoader;
using System.Threading.Tasks;
using Vtb.Broker.Infrastructure.EchangeService;

namespace Vtb.Broker.Infrastructure.MailLoader
{
    public class BrokerRiskManagementMailLoader : IBrokerRiskManagementMailLoader
    {
        private readonly IConfiguration _config;
        private readonly IExchangeServiceFactory _exchangeServiceFactory;

        public BrokerRiskManagementMailLoader(IConfiguration config, IExchangeServiceFactory exchangeServiceFactory)
        {
            _config = config;
            _exchangeServiceFactory = exchangeServiceFactory;
        }

        private MailSettings GetBrokerRiskManagementSettings(IConfigurationSection mailSection)
        {
            return new MailSettings
            {
                Email = mailSection.GetSection("MailBox").Value,
                User = mailSection.GetSection("User").Value,
                Password = mailSection.GetSection("Password").Value
            };
        }

        public async Task SaveAttachments(string targetDir)
        {
            var mailSectionName = "BrokerRiskManagementEmail";
            var brokerRiskSection = _config.GetSection(mailSectionName);
            var mailSettings = GetBrokerRiskManagementSettings(brokerRiskSection);
            var riskRateProviderEmails = brokerRiskSection.GetSection("RiskRateProviderEmails").Value.Split(",");
            var service = await _exchangeServiceFactory.Create(mailSectionName);
            var result = await service.SaveAttachments(mailSettings.Email, riskRateProviderEmails, targetDir);
            await service.MoveEmails(result, mailSettings.Email, "Обработанные");
        }
    }
}
