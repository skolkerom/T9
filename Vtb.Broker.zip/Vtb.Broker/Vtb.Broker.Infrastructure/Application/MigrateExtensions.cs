﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.CommandLineUtils;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.Application
{
    public static class MigrateExtensions
    {
        public static Action GetMigrateAction<TContext>(CommandLineApplication commandLineApplication, ContextDesignTimeFactoryBase<TContext> contextFactory) 
            where TContext : DbContextBase
        {
            var doMigrate = commandLineApplication.Option("--ef-migrate", "Apply entity framework migrations and exit", CommandOptionType.NoValue);
            var verifyMigrate = commandLineApplication.Option("--ef-migrate-check", "Check the status of entity framework migrations", CommandOptionType.NoValue);

            commandLineApplication.HelpOption("-? | -h | --help");

            return () => MigrateInner(doMigrate, verifyMigrate, contextFactory);
        }

        private static void MigrateInner<TContext>(CommandOption doMigrate, CommandOption verifyMigrate, ContextDesignTimeFactoryBase<TContext> contextFactory) 
            where TContext : DbContextBase
        {
            try
            {
                Console.WriteLine("Start migrations");
                
                var doExit = MigrateIfNeeded(doMigrate, verifyMigrate, contextFactory);

                if (doExit)
                    Environment.Exit(0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Environment.Exit(-1);
            }
        }

        private static bool MigrateIfNeeded<TContext>(CommandOption doMigrate, CommandOption verifyMigrate,
            ContextDesignTimeFactoryBase<TContext> contextFactory) where TContext : DbContextBase
        {
            var doExit = false;

            if (verifyMigrate.HasValue())
                doExit = VerifyMigrate(contextFactory);
            
            if (doMigrate.HasValue())
                doExit = DoMigrate(contextFactory);

            return doExit;
        }

        private static bool VerifyMigrate<TContext>(ContextDesignTimeFactoryBase<TContext> contextFactory) where TContext : DbContextBase
        {
            Console.WriteLine("Validating status of Entity Framework migrations");

            using var context = contextFactory.CreateDbContext(new string[]{});
            var pendingMigrations = context.Database.GetPendingMigrations();
            var migrations = pendingMigrations as IList<string> ?? pendingMigrations.ToList();
            if (!migrations.Any())
            {
                Console.WriteLine("No pending migrations");
                return true;
            }

            Console.WriteLine("Pending migrations {0}", migrations.Count);
            foreach (var migration in migrations)
                Console.WriteLine($"\t{migration}");

            return true;
        }

        private static bool DoMigrate<TContext>(ContextDesignTimeFactoryBase<TContext> contextFactory) where TContext : DbContextBase 
        {
            Console.WriteLine("Applying Entity Framework migrations");
            
            using var context = contextFactory.CreateDbContext(new string[]{});
            context.Database.Migrate();

            Console.WriteLine("All done, closing app");

            return true;
        }
    }
}