﻿namespace Vtb.Broker.Infrastructure.Auth
{
    public enum SignInType
    {
        InternalUserPassword,
        ZFrontUserPassword,
        BackOfficeUserRequest
    }
}