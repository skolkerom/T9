﻿using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Http;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class JwtAuthStateProvider : AuthenticationStateProvider
    {
        private readonly TokenProvider _tokenProvider;

        public JwtAuthStateProvider(TokenProvider tokenProvider)
        {
            _tokenProvider = tokenProvider;
        }
        
        public override Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var token = _tokenProvider.Get();
            
            if(token == null)
                return Task.FromResult(new AuthenticationState(new ClaimsPrincipal()));

            var identity = new ClaimsIdentity(token.Claims, JwtBearerDefaults.AuthenticationScheme);
            
            var state = new AuthenticationState(new ClaimsPrincipal(identity));

            return Task.FromResult(state);
        }
    }
}