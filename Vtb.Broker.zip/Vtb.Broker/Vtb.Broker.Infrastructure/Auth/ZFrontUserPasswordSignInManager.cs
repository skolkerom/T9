﻿using System;
using Microsoft.Extensions.Logging;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class ZFrontUserPasswordSignInManager : ISignInManager
    {
        private readonly string _analitConnectionString;
        private readonly string _zfrontConnectionStringTemplate;
        private readonly ILogger<ZFrontUserPasswordSignInManager> _logger;

        public ZFrontUserPasswordSignInManager(string analitConnectionString, string zfrontConnectionStringTemplate, ILogger<ZFrontUserPasswordSignInManager> logger)
        {
            _analitConnectionString = analitConnectionString;
            _zfrontConnectionStringTemplate = zfrontConnectionStringTemplate;
            _logger = logger;
        }

        public CheckCredentialsResult CheckCredentials(Credentials credentials)
        {
            var cn = _zfrontConnectionStringTemplate.Replace("{Login}", credentials.Login).Replace("{Password}", credentials.Password);

            using var zfrontSqlConnection = new System.Data.SqlClient.SqlConnection(cn);

            try
            {
                _logger.LogInformation("ZFront Connection opening");
                
                zfrontSqlConnection.Open();

                _logger.LogInformation("ZFront Connection opened ");
                
                zfrontSqlConnection.Close();

                using var analitSqlConnection = new System.Data.SqlClient.SqlConnection(_analitConnectionString);

                analitSqlConnection.Open();

                var cmd = analitSqlConnection.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "select name from dbo.users where login = @login";

                cmd.Parameters.Add(new System.Data.SqlClient.SqlParameter("@login", credentials.Login));

                _logger.LogInformation("Trying to get user from Analit");
                
                using var reader = cmd.ExecuteReader();

                if (!reader.Read())
                {
                    _logger.LogInformation("0 records returned");
                    
                    return new CheckCredentialsResult
                    {
                        Success = false
                    };
                }

                var userName = Convert.ToString(reader["name"]);

                return new CheckCredentialsResult
                {
                    Success = true,
                    UserName = userName
                };
            }
            catch(Exception e)
            {
                _logger.LogError(e, e.Message);
                
                return new CheckCredentialsResult
                {
                    Success = false
                };
            }
        }
    }
}