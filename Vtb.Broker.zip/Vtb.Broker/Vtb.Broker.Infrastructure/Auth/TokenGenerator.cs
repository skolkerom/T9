﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class TokenGenerator
    {
        private readonly JwtSettings _jwtSettings;

        public TokenGenerator(JwtSettings jwtSettings)
        {
            _jwtSettings = jwtSettings;
        }
        
        public JwtSecurityToken GetToken(string login, string userName, string ipAddress, string[] roles)
        {
            var privateKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_jwtSettings.SecurityKey));
            
            var expiration = TimeSpan.FromHours(24);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, login),
                new Claim(ClaimTypes.Name, userName ?? login),
                new Claim(VtbClaimTypes.IpAddress, ipAddress)
            };

            claims.AddRange(roles.Select(x => new Claim(ClaimTypes.Role, x)));
            
            var jwt = new JwtSecurityToken(claims: claims,
                audience:_jwtSettings.Audience,
                issuer:_jwtSettings.Issuer,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.Add(expiration),
                signingCredentials: new SigningCredentials(privateKey, SecurityAlgorithms.HmacSha256));

            return jwt;
        }
    }
}