﻿namespace Vtb.Broker.Infrastructure.Auth
{
    public class VtbClaimTypes
    {
        public const string IpAddress = "ip_address";
        public const string AccessToken = "access_token";
    }
}