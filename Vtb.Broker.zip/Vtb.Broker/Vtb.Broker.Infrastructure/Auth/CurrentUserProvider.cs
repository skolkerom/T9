using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Interfaces;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class CurrentUserProvider : ICurrentUserProvider
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly TokenProvider _tokenProvider;

        public CurrentUserProvider(IHttpContextAccessor httpContextAccessor, TokenProvider tokenProvider)
        {
            _httpContextAccessor = httpContextAccessor;
            _tokenProvider = tokenProvider;
        }

        public User GetCurrentUser()
        {
            if (_httpContextAccessor.HttpContext == null)
                return User.SystemUser;

            var token = _tokenProvider.Get();
            
            var name = token.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Name)?.Value;
            var login = token.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            var ipAddress = token.Claims.FirstOrDefault(x => x.Type == VtbClaimTypes.IpAddress)?.Value;

            return new User
            {
                Name = name,
                Login = login,
                IpAddress = ipAddress
            };
        }
    }
}