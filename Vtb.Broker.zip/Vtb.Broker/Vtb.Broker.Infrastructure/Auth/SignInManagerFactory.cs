﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class SignInManagerFactory
    {
        private readonly IServiceProvider _serviceProvider;


        public SignInManagerFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        
        public ISignInManager GetSignInManager(SignInType signInType)
        {
            switch (signInType)
            {
                case SignInType.InternalUserPassword:
                    return _serviceProvider.GetRequiredService<InternalUserPasswordSignInManager>();
                
                case SignInType.ZFrontUserPassword:
                    return _serviceProvider.GetRequiredService<ZFrontUserPasswordSignInManager>();
                
                case SignInType.BackOfficeUserRequest:
                    return _serviceProvider.GetRequiredService<BackOfficeSignInManager>();
                
                default:
                    throw new Exception($"Unknown auth type {signInType}");
            }
            
        }
    }
}