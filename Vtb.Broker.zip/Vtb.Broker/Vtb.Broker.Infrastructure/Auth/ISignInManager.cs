﻿using System;

namespace Vtb.Broker.Infrastructure.Auth
{
    public interface ISignInManager
    {
        CheckCredentialsResult CheckCredentials(Credentials credentials);
    }
}