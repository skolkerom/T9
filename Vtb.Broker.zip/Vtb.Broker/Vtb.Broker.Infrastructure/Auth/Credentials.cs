﻿namespace Vtb.Broker.Infrastructure.Auth
{
    public class Credentials
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string RequestId { get; set; }
    }
}