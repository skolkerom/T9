﻿namespace Vtb.Broker.Infrastructure.Auth
{
    public class JwtSettings
    {
        public string SecurityKey { get; set; }
        public string Issuer => "Issuer";
        public string Audience => "Audience";
    }
}