﻿using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class TokenProvider
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public TokenProvider(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public string GetAsString()
        {
            var authHeader = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault();

            string accessToken;

            if (authHeader != null && authHeader.StartsWith("Bearer"))
                accessToken = authHeader.Split(" ").Last();
            else
            {
                var claims = _httpContextAccessor.HttpContext.User.Claims.ToArray();

                accessToken = claims.FirstOrDefault(x => x.Type == VtbClaimTypes.AccessToken)?.Value;
            }

            return accessToken;
        }
        
        public JwtSecurityToken Get()
        {
            var accessToken = GetAsString();

            if (accessToken == null)
                return null;
                        
            var handler = new JwtSecurityTokenHandler();
            
            var jsonToken = handler.ReadJwtToken(accessToken);

            return jsonToken;
        }

       
    }
}