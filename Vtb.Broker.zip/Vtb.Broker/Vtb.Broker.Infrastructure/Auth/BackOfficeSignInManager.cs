﻿using System;

namespace Vtb.Broker.Infrastructure.Auth
{
    public class BackOfficeSignInManager : ISignInManager
    {
        private readonly string _analitConnectionString;

        public BackOfficeSignInManager(string analitConnectionString)
        {
            _analitConnectionString = analitConnectionString;
        }
        
        public CheckCredentialsResult CheckCredentials(Credentials credentials)
        {
            using var analitSqlConnection = new System.Data.SqlClient.SqlConnection(_analitConnectionString);
                
            analitSqlConnection.Open();
            
            var cmd = analitSqlConnection.CreateCommand();
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.CommandText = "[BackOffice].[GetAuthRequest]";
            
            cmd.Parameters.Add(new System.Data.SqlClient.SqlParameter("@requestId", credentials.RequestId));
            
            using var reader = cmd.ExecuteReader();

            if (!reader.Read())
            {
                return new CheckCredentialsResult
                {
                    Success = false
                };
            }

            var originalLogin = Convert.ToString(reader["OriginalLogin"]);
            var currentLogin = Convert.ToString(reader["CurrentLogin"]);
            var user = Convert.ToString(reader["User"]);
            var hostName = Convert.ToString(reader["HostName"]);

            if (!string.IsNullOrWhiteSpace(credentials.Login) &&
                (credentials.Login == originalLogin || credentials.Login == currentLogin || credentials.Login == user))
                return new CheckCredentialsResult
                {
                    Success = true,
                    HostName = hostName,
                    UserName = user ?? currentLogin ?? originalLogin
                };
            
            return new CheckCredentialsResult
            {
                Success = false
            }; 
        }
    }
}