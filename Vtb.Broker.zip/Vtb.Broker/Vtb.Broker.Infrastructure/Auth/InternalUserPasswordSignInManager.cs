﻿namespace Vtb.Broker.Infrastructure.Auth
{
    public class InternalUserPasswordSignInManager : ISignInManager
    {
        private readonly string _analitConnectionString;

        public InternalUserPasswordSignInManager(string analitConnectionString)
        {
            _analitConnectionString = analitConnectionString;
        }
        
        public CheckCredentialsResult CheckCredentials(Credentials credentials)
        {
            using var analitSqlConnection = new System.Data.SqlClient.SqlConnection(_analitConnectionString);
                
            analitSqlConnection.Open();
            
            var cmd = analitSqlConnection.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "select * from rm.[User] where Login = @login and PasswordHash = HASHBYTES('SHA2_512', @password)";
            
            cmd.Parameters.Add(new System.Data.SqlClient.SqlParameter("@login", credentials.Login));
            cmd.Parameters.Add(new System.Data.SqlClient.SqlParameter("@password", credentials.Password));
            
            using var reader = cmd.ExecuteReader();

            if (!reader.Read())
            {
                return new CheckCredentialsResult
                {
                    Success = false
                };
            }

            return new CheckCredentialsResult
            {
                Success = true
            };
        }
    }
}