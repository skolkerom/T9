﻿using Microsoft.Extensions.Configuration;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Caching;

namespace Vtb.Broker.Infrastructure.EndpointProvider
{
    public class EndpointProviderConfigSource : IConfigurationSource
    {
        private readonly IContextFactory<Context> _contextFactory;

        public EndpointProviderConfigSource(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        
        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new EndpointConfigurationProvider(_contextFactory);
        }
    }
}