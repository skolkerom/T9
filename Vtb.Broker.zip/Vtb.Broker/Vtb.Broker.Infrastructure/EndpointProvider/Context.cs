﻿using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.EndpointProvider;

namespace Vtb.Broker.Infrastructure.EndpointProvider
{
    public class Context : DbContextBase
    {
        public Context(string connectionString)
            :base(connectionString)
        {
            
        }
        public DbSet<Endpoint> Endpoints { get; set; }
    }
}