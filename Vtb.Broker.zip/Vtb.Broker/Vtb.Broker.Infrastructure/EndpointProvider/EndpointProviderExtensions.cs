﻿using System;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.EndpointProvider
{
    public static class EndpointProviderExtensions
    {
        public static IConfigurationBuilder AddEndpoint(this IConfigurationBuilder builder)
        {
            if (builder == null)
                throw new ArgumentNullException(nameof(builder));

            var connectionString = builder.Build().GetSection("ConnectionStrings")["DefaultConnection"];
            
            if(string.IsNullOrEmpty(connectionString))
                throw new Exception("ConnectionString is null or empty. Check configuration files");
            
            var source = new EndpointProviderConfigSource(new ContextFactory<Context>(() => new Context(connectionString), null));
            builder.Add(source);
            return builder;
        }
    }
}