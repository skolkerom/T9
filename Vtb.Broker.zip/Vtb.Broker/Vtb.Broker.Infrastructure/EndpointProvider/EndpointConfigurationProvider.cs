﻿using System.Linq;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.EndpointProvider
{
    public class EndpointConfigurationProvider : ConfigurationProvider
    {
        private readonly IContextFactory<Context> _contextFactory;

        public EndpointConfigurationProvider(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        
        public override void Load()
        {
            using var context = _contextFactory.Create();
 
            Data = context.Endpoints.ToDictionary(e => e.Code, e => e.Urls);
         }
     }
 }