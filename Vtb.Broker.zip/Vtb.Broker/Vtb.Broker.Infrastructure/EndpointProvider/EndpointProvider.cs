﻿using System;
using System.Linq;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Caching;
using Vtb.Broker.Interfaces.EndpointProvider;

namespace Vtb.Broker.Infrastructure.EndpointProvider
{
    internal class EndpointProvider :  IEndpointProvider
    {
        private readonly IContextFactory<Context> _contextFactory;
        private readonly ICache _cache;

        public EndpointProvider(IContextFactory<Context> contextFactory, ICache cache)
        {
            _contextFactory = contextFactory;
            _cache = cache;
        }

        public Endpoint GetEndpoint(string code)
        {
            var key = $"{nameof(EndpointProvider)}.{nameof(GetEndpoint)}";

            var endpoints = _cache.Get<Endpoint[]>(key);

            if (endpoints != null)
                return endpoints.Single(x => x.Code == code);

            using var context = _contextFactory.Create();

            endpoints = context.Endpoints.ToArray();

            _cache.Add(key, endpoints, new CachePolicy
            {
                Lifetime = new TimeSpan(0, 10, 0)
            });

            return endpoints.Single(x => x.Code == code);
        }
    }
}