using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Vtb.Broker.Infrastructure.EndpointProvider;
using Vtb.Broker.Interfaces.UnitOfWork;

namespace Vtb.Broker.Infrastructure.EF
{
    public class UnitOfWork<TContext> : IUnitOfWork
        where TContext : DbContext
    {
        private readonly IServiceScope _scope;

        public UnitOfWork(IServiceProvider serviceProvider)
        {
            _scope = serviceProvider.CreateScope();
        }
        public async Task BeginTran()
        {
            var context = _scope.ServiceProvider.GetRequiredService<TContext>();
            await context.Database.BeginTransactionAsync();
        }

        public Task CommitTran()
        {
            var context = _scope.ServiceProvider.GetRequiredService<TContext>();
            context.Database.CommitTransaction();
            return Task.CompletedTask;
        }

        public TRepository GetRepository<TRepository>()
        {
            return _scope.ServiceProvider.GetRequiredService<TRepository>();
        }
        public void Dispose()
        {
            _scope?.Dispose();
        }
    }
}
