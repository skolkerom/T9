using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using EFCore.BulkExtensions;
using FastMember;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.EF
{
    public static class DbContextExtensions
    {
        public static string ToSql<TEntity>(this IQueryable<TEntity> query)
        {
            var enumerator = query.Provider.Execute<IEnumerable<TEntity>>(query.Expression).GetEnumerator();
            var enumeratorType = enumerator.GetType();
            var selectFieldInfo = enumeratorType.GetField("_selectExpression", BindingFlags.NonPublic | BindingFlags.Instance) ?? throw new InvalidOperationException($"cannot find field _selectExpression on type {enumeratorType.Name}");
            var sqlGeneratorFieldInfo = enumeratorType.GetField("_querySqlGeneratorFactory", BindingFlags.NonPublic | BindingFlags.Instance) ?? throw new InvalidOperationException($"cannot find field _querySqlGeneratorFactory on type {enumeratorType.Name}");
            var selectExpression = selectFieldInfo.GetValue(enumerator) as SelectExpression ?? throw new InvalidOperationException($"could not get SelectExpression");
            var factory = sqlGeneratorFieldInfo.GetValue(enumerator) as IQuerySqlGeneratorFactory ?? throw new InvalidOperationException($"could not get IQuerySqlGeneratorFactory");
            var sqlGenerator = factory.Create();
            var command = sqlGenerator.GetCommand(selectExpression);
            var sql = command.CommandText;
            return sql;
        }

        /// <summary>
        /// Добавляет в контекст коллекцию объектов из навигационного свойства, используется для связей 1 ко многим
        /// Метод нужно использовать если заранее не известны идентификаторы объектов
        /// </summary>
        public static void AttachNavigationPropertyCollection<TEntity>(this DbContext context, TEntity[] fromDb, TEntity[] newValues, Func<TEntity, TEntity, bool> comparer) 
            where TEntity : class, IHasId
        {
            foreach (var mp in newValues)
            {
                var existed = fromDb.FirstOrDefault(x => comparer(x,mp));

                if (existed != null)
                    mp.Id = existed.Id;
            }

            foreach (var mp in fromDb)
            {
                var existed = newValues.FirstOrDefault(x => comparer(x, mp));

                if (existed == null)
                    context.Set<TEntity>().Attach(mp).State = EntityState.Deleted;
            }
        }
        
        public static void SetTransactionIsolationLevel(this DbContext context, IsolationLevel isolationLevel)
        {
            if (isolationLevel == IsolationLevel.ReadUncommitted)
            {
                context.Database.OpenConnection();
                context.Database.ExecuteSqlRaw("SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED");
                return;
            }
            
            throw new InvalidOperationException($"Unsupported isolation level {isolationLevel}");
        }
        
        /// <summary>
        /// Добавляет сущность в контекст ориентируясь на наличие первичного ключа Id.<br/>
        /// State = Id == 0 ? EntityState.Added : EntityState.Modified<br/>
        /// Связанные сущности с Id == 0 добавляются как EntityState.Added, остальные остаются в EntityState.Detached  
        /// </summary>
        /// <param name="context">контекст</param>
        /// <param name="entity">сущность</param>
        /// <param name="customHandler">обработчик</param>
        /// <typeparam name="TEntity">тип сущности</typeparam>
        public static void AttachRootEntityToContext<TEntity>(this DbContext context, TEntity entity,
            Func<Microsoft.EntityFrameworkCore.ChangeTracking.EntityEntryGraphNode, bool> customHandler = null)
            where TEntity : class, IHasId
        {
            if (context.Entry(entity).State != EntityState.Detached)
                return;

            context.ChangeTracker.TrackGraph(entity, x =>
            {
                if (customHandler != null && customHandler(x))
                    return;

                if (x.Entry.Entity == entity)
                    x.Entry.State = entity.Id == 0 ? EntityState.Added : EntityState.Modified;
                else if (x.Entry.Entity != entity)
                {
                    if (x.Entry.IsKeySet)
                    {
                        x.Entry.State = EntityState.Detached;
                    }
                    else
                        x.Entry.State = EntityState.Added;
                }
            });
        }
        
        public static bool ExistsInContext<TContext, TEntity>(this TContext context, TEntity entity)
            where TContext : DbContext
            where TEntity : class
        {
            return context.Set<TEntity>().Local.Any(e => e == entity);
        }
        public static IQueryable<TEntity> IncludeAll<TEntity>(this DbContext context, IQueryable<TEntity> query)
            where TEntity : class
        {
            foreach (var property in context.Model.FindEntityType(typeof(TEntity)).GetNavigations())
                query = query.Include(property.Name);

            return query;
        }

        public static async Task BulkInsertAsync<TEntity>(this DbContext context, TEntity[] items, string tableName, string[] properties = null, DbTransaction transaction = null)
        {
            var entityModel = context.Model.FindEntityType(typeof(TEntity));

            var allProps = entityModel.GetProperties();

            using var bulk = new SqlBulkCopy((SqlConnection)context.Database.GetDbConnection(), SqlBulkCopyOptions.Default, (SqlTransaction)transaction)
            {
                DestinationTableName = tableName
            };

            foreach (var p in allProps.Where(x => properties == null || properties.Contains(x.Name)))
                bulk.ColumnMappings.Add(p.Name, p.Name);

            await bulk.WriteToServerAsync(ObjectReader.Create(items));
        }
        
        public static async Task<TableQueryInfo<TEntity>> CreateTempTableAndInsertRecords<TEntity>(this DbContext context, TEntity[] records, string[] properties = null)
            where TEntity : class
        {
            var tableInfo = await context.CreateTempTable<TEntity>(properties);

            await context.BulkInsertAsync(records, tableInfo.TableName);

            tableInfo.Query = context.Set<TEntity>().FromSqlRaw($"select * from {tableInfo.TableName}");

            return tableInfo;
        }

        public static async Task<TableQueryInfo<TEntity>> CreateTempTable<TEntity>(this DbContext context, string[] properties = null)
            where TEntity : class
        {
            var entityModel = context.Model.FindEntityType(typeof(TEntity));

            var allProps = entityModel.GetProperties();

            var columns =
                string.Join(", ", allProps
                    .Where(x => properties == null || properties.Contains(x.Name))
                    .Select(x =>
                    {
                        var collate = x.PropertyInfo.PropertyType == typeof(string)
                            ? "collate database_default"
                            : string.Empty;

                        return $"{x.Name} {x.GetColumnType()} {collate}";
                    }));

            var prefix = !entityModel.GetTableName().StartsWith("#")
                ? "#"
                : string.Empty;

            var tableName = prefix + entityModel.GetTableName() + "___Temp" + Guid.NewGuid().ToString().Substring(0, 8);

            await context.Database.ExecuteSqlRawAsync($"create table {tableName} ({columns})");

            return new TableQueryInfo<TEntity>
            {
                TableName = tableName,
                Query = context.Set<TEntity>().FromSqlRaw($"select * from {tableName}")
            };
        }
        
        public static async Task<TEntity[]> BulkReadAsync<TEntity>(this DbContext context, TEntity[] items, string[] searchProperties, string queryTag)
            where TEntity : class
        {
            var entityModel = context.Model.FindEntityType(typeof(TEntity));

            TableQueryInfo<TEntity> tempTable = null;

            try
            {
                if (context.Database.GetDbConnection().State != ConnectionState.Open)
                    await context.Database.OpenConnectionAsync();

                tempTable = await context.CreateTempTable<TEntity>(searchProperties);

                await context.BulkInsertAsync(items, tempTable.TableName, searchProperties, context.Database.CurrentTransaction?.GetUnderlyingTransaction(null));

                var columnEquality = string.Join(" and ", searchProperties.Select(x => $"t.{x} = r.{x}"));

                var result = await context.Set<TEntity>().FromSqlRaw($@"   
                    -- {queryTag}
                    select r.*
                    from {tempTable.TableName} t 
                        join {GetTableNameWithSchema(entityModel)} r on {columnEquality}")
                    .ToArrayAsync();

                return result;
            }
            finally
            {
                if (tempTable != null)
                    context.Database.ExecuteSqlRaw($"drop table {tempTable.TableName}");
            }
        }

        private static string GetTableNameWithSchema(IEntityType entityType)
        {
            return $@"{entityType.GetSchema()}.{entityType.GetTableName()}";
        }
        
        public static async Task SaveEntities<TEntity, THistory>(this DbContext context, TEntity[] entities, IMapperService mapper)
            where THistory : class, IHistory
            where TEntity : class, IEntity, new()
        {
            if (context.Database.CurrentTransaction != null)
                await context.BulkInsertOrUpdateAsync(entities, x => x.UseTempDB = true);
            else
            {
                await using var tran = await context.Database.BeginTransactionAsync();

                await context.BulkInsertOrUpdateAsync(entities, x => x.UseTempDB = true);

                await tran.CommitAsync();
            }
        }

        public static async Task SaveEntityWithHistory<TEntity, THistory>(this DbContext context, IAuditService auditService, TEntity entity, IMapperService mapper)
            where THistory : class, IHistory
            where TEntity : class, IEntity
        {
            context.AttachRootEntityToContext(entity);

            var fromDb = entity.Id > 0
                ? await context.IncludeAll(context.Set<TEntity>()).FirstOrDefaultAsync(x => x.Id == entity.Id)
                : null;

            //сохраняем в бд для получения значения первичного ключа и для удаления из навигационных свойств ненужных записей(они могут помешать аудиту)  
            await context.SaveChangesAsync(); //get identity for primary key            

            if (typeof(TEntity).GetCustomAttribute(typeof(AuditAttribute)) is AuditAttribute auditAttr)
            {
                var comparer = new ObjectComparer();
                
                var changes = comparer.Compare(fromDb, entity);
                
                var audit = new Interfaces.Audit.Entities.Audit
                {
                    ActionType = auditAttr.ActionType,
                    EntityId = entity.Id,
                    User = entity.ModifiedUser,
                    Message = entity.ToString()
                };

                foreach (var diff in changes)
                {
                    audit.Details.Details.Add(new AuditDetail
                    {
                        PropertyName = diff.Property.GetDisplayName(),
                        OldValue = diff.OldValue,
                        NewValue = diff.NewValue
                    });
                }
 
                await context.SaveChangesAsync();
                await auditService.SaveAsync(audit);
            }

            var result = mapper.Map<TEntity, THistory>(entity);

            result.EntityId = entity.Id;

            context.AttachRootEntityToContext(result);

            await context.SaveChangesAsync();
        }        
    }
}