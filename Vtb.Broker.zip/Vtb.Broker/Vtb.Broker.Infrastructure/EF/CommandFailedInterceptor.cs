﻿using System;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.EntityFrameworkCore.Diagnostics;
using SqlException = Microsoft.Data.SqlClient.SqlException;

namespace Vtb.Broker.Infrastructure.EF
{
    public class CommandFailedInterceptor : DbCommandInterceptor
    {
        public override void CommandFailed(DbCommand command, CommandErrorEventData eventData)
        {
            var parameters = string.Join(",",
                command.Parameters.Cast<DbParameter>().Select(x => x.ParameterName + " = " + x.Value));

            var details = string.Empty;

            if (eventData.Exception is SqlException)
            {
                if (eventData.Exception.Message.StartsWith("Execution Timeout Expired"))
                {
                    details = $"Превышение таймаута {eventData.Command.CommandTimeout} секунд";
                }
            }

            var msg = $"Ошибка при выполнении запроса: {command.CommandText} {details}" + (!string.IsNullOrWhiteSpace(parameters)
                ? $". Параметры: {parameters}"
                : string.Empty);
            
            throw new Exception(msg, eventData.Exception);
        }
    }
}