namespace Vtb.Broker.Infrastructure.EF
{
    public interface IContextFactory<T>
    {
        T Create();
    }
}
