using System;
using Microsoft.Extensions.DependencyInjection;
using Vtb.Broker.Interfaces.UnitOfWork;

namespace Vtb.Broker.Infrastructure.EF
{    
    public class UnitOfWorkFactory<TUnitOfWork> : IUnitOfWorkFactory
        where TUnitOfWork : IUnitOfWork
    {
        private readonly IServiceProvider _serviceProvider;

        public UnitOfWorkFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }
        public IUnitOfWork Get()
        {
            return _serviceProvider.GetService<TUnitOfWork>();
        }
    }     
}
