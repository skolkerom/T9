using System;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.EF
{
    public abstract class ContextDesignTimeFactoryBase<TContext> : IDesignTimeDbContextFactory<TContext> 
            where TContext : DbContext
    {
        private readonly string _connectionName;

        protected ContextDesignTimeFactoryBase(string connectionName)
        {
            _connectionName = connectionName;
        }
        
        public TContext CreateDbContext(string[] args)
        {
            var config = IocConfigurator.AddVtbConfig(loadEndpointSettings: false);

            var connectionString = config.GetConnectionString(_connectionName);
            
            var optionsBuilder = new DbContextOptionsBuilder<TContext>();
            optionsBuilder.UseSqlServerConnection(connectionString);
                
            Console.WriteLine((connectionString));

            return (TContext) Activator.CreateInstance(typeof(TContext), optionsBuilder.Options);
        }
    }
    public class ContextFactory<T> : IContextFactory<T> where T : DbContextBase 
    {
        private readonly Func<T> _factory;
        private readonly ILoggerFactory _loggerFactory;
        private readonly bool _useReadCommittedIsolationLevel;


        public ContextFactory(Func<T> factory, ILoggerFactory loggerFactory)
        {
            _factory = factory;
            _loggerFactory = loggerFactory;
        }
        
        public ContextFactory(Func<T> factory, ILoggerFactory loggerFactory, bool useReadCommittedIsolationLevel)
        {
            _factory = factory;
            _loggerFactory = loggerFactory;
            _useReadCommittedIsolationLevel = useReadCommittedIsolationLevel;
        }
        
        public T Create()
        {
            var context = _factory();
            context.LoggerFactory = _loggerFactory;
            
            if(!_useReadCommittedIsolationLevel)
                context.SetTransactionIsolationLevel(IsolationLevel.ReadUncommitted);
            
            return context;
        }
    }
}
