﻿using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.EF
{
    public abstract class DbContextBase : DbContext, ILoggerDbContext
    {
        private readonly string _connectionString;
        public ILoggerFactory LoggerFactory { get; set; }
        
        protected DbContextBase(DbContextOptions options) : base(options)
        {
            
        }

        protected DbContextBase(string connectionString)
        {
            _connectionString = connectionString;
        }
        
        protected DbContextBase()
        {
        }
        
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(_connectionString != null)
                optionsBuilder.UseSqlServerConnection(_connectionString);

            if (LoggerFactory != null)
                optionsBuilder.UseLoggerFactory(LoggerFactory);

            optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
            optionsBuilder.AddInterceptors(new CommandFailedInterceptor());
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var cascadeFKs = modelBuilder.Model.GetEntityTypes()
                .SelectMany(t => t.GetForeignKeys())
                .Where(fk => !fk.IsOwnership && fk.DeleteBehavior == DeleteBehavior.Cascade);

            foreach (var fk in cascadeFKs)
                fk.DeleteBehavior = DeleteBehavior.NoAction;
        }
    }
}