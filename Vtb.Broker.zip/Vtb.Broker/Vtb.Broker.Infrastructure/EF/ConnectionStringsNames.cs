﻿namespace Vtb.Broker.Infrastructure.EF
{
    public static class ConnectionStringsNames
    {
        public const string DefaultConnection = "DefaultConnection";
        public const string OlbConnection = "olbConnection";
    }
}