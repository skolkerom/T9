﻿using System.Linq;

namespace Vtb.Broker.Infrastructure.EF
{
    public class TableQueryInfo<TEntity>
    {
        public string TableName { get; set; }
        public IQueryable<TEntity> Query { get; set; }
    }
}