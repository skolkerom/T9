using Microsoft.Extensions.Logging;

namespace Vtb.Broker.Infrastructure.EF
{
    public interface ILoggerDbContext
    {
        ILoggerFactory LoggerFactory {get;set;}
    }
}