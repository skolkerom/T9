﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Infrastructure.EF
{
    public class ObjectComparer
    {
        private static readonly string[] PropsToIgnore = new[]
        {
            nameof(IEntity.Id),
            nameof(IEntity.ModifiedDate),
            nameof(IEntity.ModifiedUser),
            nameof(IEntity.RowVersion)
        };

        private CompareResult CompareCollections(PropertyInfo pi, object leftObject, object rightObject)
        {
            if (!pi.PropertyType.IsGenericType)
                return null;
            
            var type = pi.PropertyType.GetGenericArguments()[0];
            
            if (type.GetInterface(nameof(IHasId)) == null)
                return null;
            
            var left = leftObject != null ? (IEnumerable)pi.GetValue(leftObject, null) : null;
            var right = rightObject != null ? (IEnumerable)pi.GetValue(rightObject, null) : null;
            
            if (left == null && right == null)
                return null;

            var rightItems = (right ?? new object[0]).Cast<IHasId>().ToArray();
            var leftItems = (left ?? new object[0]).Cast<IHasId>().ToArray();

            var onlyInLeft = leftItems.Where(l => rightItems.All(r => r.Id != l.Id)).ToArray();
            var onlyInRight = rightItems.Where(l => leftItems.All(r => r.Id != l.Id)).ToArray();

            if (onlyInLeft.Length > 0 || onlyInRight.Length > 0)
                return new CompareResult
                {
                    Property = pi,
                    OldValue = string.Join(", ", leftItems.OrderBy(x => x.Id)),
                    NewValue = string.Join(", ", rightItems.OrderBy(x => x.Id))
                };

            return null;
        }
        public CompareResult[] Compare<TEntity>(TEntity object1, TEntity object2)
        {
            var props = typeof(TEntity).GetProperties().Where(x => !PropsToIgnore.Contains(x.Name));

            var result = new List<CompareResult>();

            foreach (var prop in props)
            {
                if(prop.PropertyType.IsArray)
                    continue;

                CompareResult compareResult;

                if (prop.PropertyType != typeof(string) && prop.PropertyType.GetInterface(nameof(IEnumerable)) != null)
                    compareResult = CompareCollections(prop, object1, object2);
                else
                    compareResult = CompareProps(object1, object2, prop);
                
                if (compareResult != null)
                    result.Add(compareResult);
            }

            return result.ToArray();
        }

        public class CompareResult
        {
            public PropertyInfo Property { get; set; }
            public string OldValue { get; set; }
            public string NewValue { get; set; }
        }

        private CompareResult CompareProps<TEntity>(TEntity object1, TEntity object2, PropertyInfo pi)
        {
            var val1 = object1 != null ? pi.GetValue(object1) : null;
            var val2 = object2 != null ? pi.GetValue(object2) : null;

            if (object.Equals(val1, val2))
                return null;

            if (pi.PropertyType.GetInterface(nameof(IHasId)) != null)
            {
                if (val1 != null && val2 != null)
                {
                    if ((val1 as IHasId).Id == ((val2 as IHasId).Id))
                        return null;
                }
            }

            return new CompareResult
            {
                OldValue = Convert.ToString(val1),
                NewValue = Convert.ToString(val2),
                Property = pi
            };
        }
    }
}