﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace Vtb.Broker.Infrastructure.IO
{
    public class FileUploader : Interfaces.IO.IFileUploader
    {
        public async Task UploadFile(byte[] content, string fileName)
        {
            using (FileStream stream = File.OpenWrite(fileName))
            {
                await stream.WriteAsync(content, 0, content.Length);
            }
        }
    }
}
