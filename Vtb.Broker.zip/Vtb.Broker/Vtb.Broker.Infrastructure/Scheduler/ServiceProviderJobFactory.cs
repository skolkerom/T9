using System;
using Quartz;
using Quartz.Simpl;
using Quartz.Spi;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    internal class ServiceProviderJobFactory : SimpleJobFactory
    {
        private readonly IServiceProvider _serviceProvider;

        public ServiceProviderJobFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public override IJob NewJob(TriggerFiredBundle bundle, IScheduler scheduler)
        {
            try
            {                
                return (IJob)_serviceProvider.GetService(bundle.JobDetail.JobType);
            }
            catch (Exception e)
            {
                throw new SchedulerException(string.Format("Problem while instantiating job '{0}' from the ServiceProvider.", bundle.JobDetail.Key), e);
            }
        }
    }
}