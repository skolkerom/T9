using System;
using System.Threading.Tasks;
using Quartz.Spi;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public interface ISchedulerFacade
    {
        Task<JobSchedule[]> GetSchedules(string application);
        Task<JobExecution[]> GetExecutions(string code, DateTime startDate, DateTime endDate);
        Task RunJob(JobSchedule schedule, string user);
    }

    internal class SchedulerFacade : ISchedulerFacade
    {
        private readonly IJobPersister _jobPersister;
        private readonly InternalJobConfigurator _internalJobConfigurator;

        public SchedulerFacade(IJobPersister jobPersister, InternalJobConfigurator internalJobConfigurator)
        {
            _jobPersister = jobPersister;
            _internalJobConfigurator = internalJobConfigurator;
        }

        public async Task<JobExecution[]> GetExecutions(string code, DateTime startDate, DateTime endDate)
        {
            return await _jobPersister.GetExecutions(code, startDate, endDate);
        }

        public async Task<JobSchedule[]> GetSchedules(string application)
        {
            return await _jobPersister.GetSchedules(application);
        }

        public async Task RunJob(JobSchedule schedule, string user)
        {
            await _jobPersister.SaveExecutionRequest(new JobExecutionRequest
            {
                JobScheduleId = schedule.Id,
                CreatedDateTime = DateTime.Now,
                User = user
            });
        }
    }
}