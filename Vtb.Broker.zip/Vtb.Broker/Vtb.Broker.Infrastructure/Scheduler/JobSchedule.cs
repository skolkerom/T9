using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    [Table("JobSchedule", Schema = "rm")]
    public class JobSchedule
    {
        public long Id { get; set; }
        [DisplayName("Код")]
        public string Code { get; set; }

        [DisplayName("Название сервиса")]
        public string ApplicationName { get; set; }

        [DisplayName("Описание")]
        public string Description { get; set; }
        public string Cron { get; set; }

        [Timestamp]
        public byte[] RowVersion { get; set; }

        [DisplayName("Удален")]
        public bool IsDeleted { get; set; }
    }
}