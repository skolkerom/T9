using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public class DefaultJobFactory : IJobFactory
    {
        private readonly IServiceProvider _serviceProvider;

        public DefaultJobFactory(IServiceProvider serviceProvider)
        {            
            _serviceProvider = serviceProvider;
        }

        public async Task RunJob(Type jobType, Interfaces.Jobs.JobContext context)
        {   
            using var scope = _serviceProvider.CreateScope();

            var job = (Interfaces.Jobs.IJob)scope.ServiceProvider.GetService(jobType);

            await job.Execute(context);
        }
    }
}