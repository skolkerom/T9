﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    [Table("JobExecutionRequest", Schema = "rm")]
    public class JobExecutionRequest : IHasId
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        public long JobScheduleId { get; set; }
        public JobSchedule JobSchedule { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string User { get; set; }
        public bool IsProcessed { get; set; }
    }
}