﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Quartz;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    internal class InternalJobConfigurator : Quartz.IJob
    {
        private readonly IJobFactory _jobFactory;
        private readonly IJobPersister _jobPersister;
        private readonly Dictionary<string, Type> _registeredJobs = new Dictionary<string, Type>();

        public void RegisterJob<TJob>(string code)
            where TJob : Vtb.Broker.Interfaces.Jobs.IJob
        {
            _registeredJobs[code] = typeof(TJob);
        }

        public InternalJobConfigurator(IJobFactory jobFactory, IJobPersister jobPersister)
        {
            _jobFactory = jobFactory;
            _jobPersister = jobPersister;
        }

        public async Task Execute(string code, string user)
        {
            var jobType = _registeredJobs[code];

            var execution = new JobExecution
            {
                StartDate = DateTime.Now,
                Code = code,
                User = user
            };

            await _jobPersister.Save(execution);

            try
            {
                await _jobFactory.RunJob(jobType, new Interfaces.Jobs.JobContext());
            }
            catch (Exception e)
            {
                execution.ErrorMessage = e.ToString();
            }
            finally
            {
                execution.EndDate = DateTime.Now;
                await _jobPersister.Save(execution);
            }
        }

        public async Task Execute(IJobExecutionContext context)
        {
            await Execute(context.JobDetail.Key.Name, null);
        }
    }
}