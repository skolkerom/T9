using System;
using Microsoft.Extensions.DependencyInjection;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public class JobConfigurator
    {
        private readonly InternalJobConfigurator _job;

        public JobConfigurator(IServiceProvider serviceProvider)
        {            
            _job = serviceProvider.GetService<InternalJobConfigurator>();
        }

        public void RegisterJob<TJob>(string code)
            where TJob : Interfaces.Jobs.IJob
        {            
            _job.RegisterJob<TJob>(code);
        }
    }
}