using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public class PersisterContext : DbContextBase
    {
        public virtual DbSet<JobSchedule> JobSchedules { get; set; }
        public virtual DbSet<JobExecution> JobExecutions { get; set; }
        public virtual DbSet<JobExecutionRequest> JobExecutionRequests { get; set; }

        public PersisterContext(string connectionString)
            :base(connectionString)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            LoggerFactory = null;
            
            base.OnConfiguring(optionsBuilder);
        }
    }
}