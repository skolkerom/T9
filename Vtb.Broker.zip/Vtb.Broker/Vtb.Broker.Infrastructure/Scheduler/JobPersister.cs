using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public class JobPersister : IJobPersister
    {
        private readonly IContextFactory<PersisterContext> _contextFactory;

        public JobPersister(IContextFactory<PersisterContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public async Task<JobExecution[]> GetExecutions(string code, DateTime startDate, DateTime endDate)
        {
            await using var context = _contextFactory.Create();

            var endDateTplus1 = endDate.Date.AddDays(1);

            return await context.JobExecutions
                .Where(x => x.Code == code && x.StartDate >= startDate && x.StartDate < endDateTplus1)
                .ToArrayAsync();
        }

        public async Task<JobExecutionRequest[]> GetExecutionRequests(string serviceName = null)
        {
            await using var context = _contextFactory.Create();

            var requests = await context.JobExecutionRequests
                .Where(x => !x.IsProcessed && x.JobSchedule.ApplicationName == serviceName)
                .Include(x => x.JobSchedule)
                .ToArrayAsync();

            return requests;
        }

        public async Task SaveExecutionRequest(JobExecutionRequest request)
        {
            await using var context = _contextFactory.Create();
            
            context.AttachRootEntityToContext(request);

            await context.SaveChangesAsync();
        }
 

        public async Task<JobSchedule[]> GetSchedules(string applicationName, byte[] lastRowVersion = null)
        {
            await using var context = _contextFactory.Create();

            var query = context.JobSchedules.AsQueryable();

            if (applicationName != null)
                query = query.Where(x => x.ApplicationName == applicationName);

            var schedules = await query.ToArrayAsync();

            if (lastRowVersion != null)
            {
                return schedules
                    .Where(x => x.ApplicationName == applicationName
                                && BitConverter.ToInt64(x.RowVersion) > BitConverter.ToInt64(lastRowVersion))
                    .ToArray();
            }

            return schedules;
        }

        public async Task Save(JobExecution execution)
        {
            await using var context = _contextFactory.Create();

            context.JobExecutions.Update(execution);

            await context.SaveChangesAsync();
        }
    }
}