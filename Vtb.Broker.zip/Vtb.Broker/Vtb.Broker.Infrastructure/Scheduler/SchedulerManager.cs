using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Quartz;
using Quartz.Impl;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public class SchedulerManager
    {
        private readonly IJobPersister _persister;
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<SchedulerManager> _logger;
        private readonly InternalJobConfigurator _jobConfigurator;
        private IScheduler _scheduler;
        private string _applicationName;


        public SchedulerManager(IJobPersister persister, IServiceProvider serviceProvider, ILogger<SchedulerManager> logger)
        {
            _persister = persister;
            _serviceProvider = serviceProvider;
            _logger = logger;
            _jobConfigurator = _serviceProvider.GetRequiredService<InternalJobConfigurator>();
        }

        public async Task Start(string applicationName)
        {
            _applicationName = applicationName;

            var props = new NameValueCollection
            {
                { "quartz.serializer.type", "binary" }
            };

            var factory = new StdSchedulerFactory(props);

            _scheduler = await factory.GetScheduler();
            _scheduler.JobFactory = new ServiceProviderJobFactory(_serviceProvider);
            await _scheduler.Start();

            var monitorSchedules = Task.Run(async () => await MonitorSchedules());
            var monitorRequests = Task.Run(async () => await MonitorExecutionRequests()); 

            await Task.WhenAll(monitorSchedules, monitorRequests);
        }

        private byte[] _lastRowversion = null;

        private const int DELAY = 1000 * 10;
        private async Task MonitorSchedules()
        {
            while (true)
            {
                try
                {
                    await RefreshSchedules();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, nameof(MonitorSchedules));
                }
                finally
                {
                    await Task.Delay(DELAY);
                }
            }
        }
        
        private async Task MonitorExecutionRequests()
        {
            while (true)
            {
                try
                {
                    await ProcessRequests();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, nameof(MonitorExecutionRequests));
                }
                finally
                {
                    await Task.Delay(DELAY);
                }
            }
        }

        private async Task ProcessRequests()
        {
            var requests = await _persister.GetExecutionRequests(_applicationName);

            foreach (var request in requests)
            {
                request.IsProcessed = true;
                await _persister.SaveExecutionRequest(request);
#pragma warning disable 4014
                Task.Run(() =>
                {
                    try
                    {
                        _jobConfigurator.Execute(request.JobSchedule.Code, request.User);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, nameof(ProcessRequests));
                    }
                });
#pragma warning restore 4014
            }
        }

        private async Task RefreshSchedules()
        {
            foreach (var scheduleGroup in (await _persister.GetSchedules(_applicationName, _lastRowversion)).GroupBy(x => x.Code))
            {
                var job = JobBuilder.Create<InternalJobConfigurator>()
                    .WithIdentity(scheduleGroup.Key, "default")
                    .Build();

                var triggers = new List<ITrigger>();

                foreach (var schedule in scheduleGroup.Where(x => !x.IsDeleted))
                {
                    try
                    {
                        var trigger = TriggerBuilder.Create()
                            .WithIdentity(schedule.Id.ToString(), "default")
                            .StartNow()
                            .WithCronSchedule(schedule.Cron)
                        .Build();

                        triggers.Add(trigger);

                        if (_lastRowversion == null || BitConverter.ToInt64(schedule.RowVersion) > BitConverter.ToInt64(_lastRowversion))
                            _lastRowversion = schedule.RowVersion;
                    }
                    catch(Exception e)
                    {
                        _logger.LogError("Error on schedule update", e);
                    }
                }

                await _scheduler.ScheduleJob(job, triggers.AsReadOnly(), true);
            }
        }
    }
}