using System;
using System.Threading.Tasks;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public interface IJobFactory
    {
        Task RunJob(Type jobType, Interfaces.Jobs.JobContext context);
    }
}