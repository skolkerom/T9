using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    [Table("JobExecution", Schema = "rm")]
    public class JobExecution
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [DisplayName("Код")]
        public string Code { get; set; }

        [DisplayName("Дата запуска")]
        public DateTime StartDate { get; set; }

        [DisplayName("Дата окончания")]
        public DateTime? EndDate { get; set; }
        
        public string User { get; set; }

    
        [DisplayName("Ошибка")]
        public string ErrorMessage { get; set; }
    }
}