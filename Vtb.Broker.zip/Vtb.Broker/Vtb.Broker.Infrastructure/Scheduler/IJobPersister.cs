using System;
using System.Threading.Tasks;

namespace Vtb.Broker.Infrastructure.Scheduler
{
    public interface IJobPersister
    {
        Task<JobExecutionRequest[]> GetExecutionRequests(string serviceName);
        Task SaveExecutionRequest(JobExecutionRequest request);
        Task<JobSchedule[]> GetSchedules(string serviceName = null, byte[] lastRowVersion = null);
        Task<JobExecution[]> GetExecutions(string code, DateTime startDate, DateTime endDate);
        Task Save(JobExecution execution);
    }
}