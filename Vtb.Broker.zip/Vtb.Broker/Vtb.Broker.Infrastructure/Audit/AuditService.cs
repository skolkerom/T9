﻿using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Vtb.Broker.Domain.Entities.Annotations;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.Interfaces.Entities;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.Utils;

namespace Vtb.Broker.Infrastructure.Audit
{
    public class AuditService : IAuditService
    {
        private readonly IContextFactory<AuditContext> _contextFactory;
        private readonly IMapperService _mapperService;
        private readonly ICurrentUserProvider _currentUserProvider;

        public AuditService(IContextFactory<AuditContext> contextFactory, IMapperService mapperService, ICurrentUserProvider currentUserProvider)
        {
            _contextFactory = contextFactory;
            _mapperService = mapperService;
            _currentUserProvider = currentUserProvider;
        }
        
        public async Task SaveAsync(Interfaces.Audit.Entities.Audit audit)
        {
            var user = _currentUserProvider.GetCurrentUser();
            
            await using var context = _contextFactory.Create();
            
            audit.DetailsJson = JsonConvert.SerializeObject(audit.Details);
            
            audit.IpAddress = user.IpAddress;
            audit.User = user.Login;

            context.Add(audit);
            
            await context.SaveChangesAsync();
        }

        public async Task<Interfaces.Audit.Entities.Audit[]> GetAudits(DateTime startDate, DateTime endDate)
        {
            await using var context = _contextFactory.Create();

            endDate = endDate.Date.AddDays(1);
            startDate = startDate.Date;

            var result = await context.Audits
                .Where(x => x.EventDateTime >= startDate && x.EventDateTime < endDate)                
                .ToArrayAsync();

            foreach(var r in result)
                if(!string.IsNullOrWhiteSpace(r.DetailsJson))
                    r.Details = JsonConvert.DeserializeObject<AuditDetails>(r.DetailsJson);

            return result;
        } 
    }
}