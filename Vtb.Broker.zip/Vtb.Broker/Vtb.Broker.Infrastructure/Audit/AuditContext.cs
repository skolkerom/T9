﻿using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.Infrastructure.Audit
{
    public class AuditContext : DbContextBase
    {
        public virtual DbSet<Interfaces.Audit.Entities.Audit> Audits { get; set; }
        
        public AuditContext(string connectionString)
            :base(connectionString)
        {
        }
    }
}