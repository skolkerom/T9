﻿using System.Net;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Interfaces.BankProxy;

namespace Vtb.Broker.Infrastructure.BankProxy
{
    public class BankProxyFactory : IBankProxyFactory
    {
        private readonly IConfiguration _configuration;

        public BankProxyFactory(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        
        public IWebProxy CreateWebProxy()
        {
            var proxySettings = GetProxySettings(_configuration);
            var proxy = new WebProxy(proxySettings.Proxy, proxySettings.Port)
            {
                Credentials = new NetworkCredential(proxySettings.ProxyUser, proxySettings.ProxyPassword, proxySettings.Domain)
            };
            return proxy;
        }
        
        private ProxySettings GetProxySettings(IConfiguration config)
        {
            var proxySection = config.GetSection("Proxy");
            return new ProxySettings
            {
                Domain = proxySection.GetSection("Domain").Value,
                Port = int.Parse(proxySection.GetSection("Port").Value),
                Proxy = proxySection.GetSection("Url").Value,
                ProxyUser = proxySection.GetSection("User").Value,
                ProxyPassword = proxySection.GetSection("Password").Value
            };
        }
    }
}