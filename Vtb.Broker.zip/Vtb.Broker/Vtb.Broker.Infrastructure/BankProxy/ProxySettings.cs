﻿namespace Vtb.Broker.Infrastructure.BankProxy
{
    public class ProxySettings
    {
        public string Domain { get; set; }
        public int Port { get; set; }
        public string Proxy { get; set; }
        public string ProxyUser { get; set; }
        public string ProxyPassword { get; set; }
    }
}