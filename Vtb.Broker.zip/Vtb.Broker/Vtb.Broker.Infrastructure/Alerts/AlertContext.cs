﻿using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Alerts.Entities;

namespace Vtb.Broker.Infrastructure.Alerts
{
    public class AlertContext : DbContextBase
    {
        public virtual DbSet<Alert> Alerts { get; set; }
        public virtual DbSet<AlertEmail> AlertEmails { get; set; }
        public virtual DbSet<AlertEmailTemplate> AlertTemplates { get; set; }

        public AlertContext(string connectionString) : base(connectionString)
        {           
        }
    }
}