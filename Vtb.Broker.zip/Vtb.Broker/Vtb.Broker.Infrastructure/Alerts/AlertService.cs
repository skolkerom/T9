﻿using System;
using Vtb.Broker.Infrastructure.EchangeService;
using Vtb.Broker.Infrastructure.EF;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Interfaces.Alerts;
using Vtb.Broker.Interfaces.Alerts.Entities;

namespace Vtb.Broker.Infrastructure.Alerts
{
    public class AlertService : IAlertService
    {
        private readonly IExchangeServiceFactory _exchangeServiceFactory;
        private readonly IContextFactory<AlertContext> _contextFactory;
        private readonly IConfiguration _configuration;

        private static string HeaderStyle = "\"border: 1px solid black;\"";
        private static string TableStyle = "\"font-size: 80%; border: 1px solid black; padding: 5px; border-collapse:collapse;\"";
        private static string TdStyle = "\"border: 1px solid black;\"";

        public AlertService(IExchangeServiceFactory exchangeServiceFactory, IContextFactory<AlertContext> contextFactory, IConfiguration configuration)
        {
            _exchangeServiceFactory = exchangeServiceFactory;
            _contextFactory = contextFactory;
            _configuration = configuration;
        }

        public async Task Send(string alertCode, object main, object[] details = null)
        {
            var alert = await GetAlert(alertCode);

            if (alert == null)
                return;
            
            var exchangeService = await _exchangeServiceFactory.Create("Alerts");
            var sender = _configuration.GetSection("Alerts").GetSection("MailBox").Value;

            var result = string.Empty;
            result += $"{GetMain(alert.Body, main)}<br/><br/>";
            
            result += $"<table style={TableStyle}>"; 
            
            result += GetHeader(alert.Header);
            result += GetDetails(alert.Detail, details);

            result += "</table>";
            
            await exchangeService.Send(sender, alert.Recipients, alert.Subject, result);
        }

        private string GetHeader(string template)
        {
            if (string.IsNullOrEmpty(template))
                return string.Empty;

            var pattern = "{(.*?)}";
            var matches = Regex.Matches(template, pattern);

            if (!matches.Any())
                return template;
            
            var header = matches.Aggregate("", (acc, m) => $"{acc}<th bgcolor=\"#DCDCDC\" style={HeaderStyle}>{m.Groups[1].Value}</th>");

            return $"<tr>{header}</tr>";
        }

        private string GetMain(string template, object source, string openTag = "", string closeTag = "")
        {
            if (string.IsNullOrEmpty(template))
                return string.Empty;
            
            if (source == null)
                return template;
            
            var pattern = "{(.*?)}";
            var matches = Regex.Matches(template, pattern);

            if (!matches.Any())
                return template;
            
            var result = template;
            
            foreach (Match m in matches)
            {
                var tag = m.Groups[0].Value;
                var property = m.Groups[1].Value;

                result = result.Replace(tag, $"{openTag}{source.GetType().GetProperty(property)?.GetValue(source)}{closeTag}");
            }
            
            return result;
        }

        private string GetDetails(string detailPartTemplate, object[] details)
        {
            if (string.IsNullOrEmpty(detailPartTemplate))
                return string.Empty;
            
            var result = string.Empty;

            if (!details?.Any() ?? true)
                return result;
            
            foreach (var detail in details)
                result += $"<tr>{GetMain(detailPartTemplate, detail, $"<td style={TdStyle}>", "</td>")}</tr>";

            return result;
        }

        private async Task<AlertDto> GetAlert(string alertCode)
        {
            await using var context = _contextFactory.Create();

            var alerts = await (from a in context.Alerts
                    join e in context.AlertEmails on a.Id equals e.AlertId
                    join t in context.AlertTemplates on a.Id equals t.AlertId
                        into tlj
                    from t in tlj.DefaultIfEmpty()
                    where a.Code == alertCode && !a.IsDeleted && !e.IsDeleted
                    select new {a, t, e}).ToArrayAsync();

            var alertDtos = (from a in alerts
                group a by a.a.Code
                into grs
                select new AlertDto
                {
                    Code = grs.Key,
                    Recipients = grs.Select(i => i.e.Email).ToArray(),
                    Detail = grs.Select(i => i.t.DetailTemplate).FirstOrDefault(),
                    Body = grs.Select(i => i.t.MainTemplate).FirstOrDefault(),
                    Subject = grs.Select(i => i.t.Subject).FirstOrDefault(),
                    Header = grs.Select(i => i.t.HeaderTemplate).FirstOrDefault(),
                }).ToArray();
        
            if(alertDtos.Length > 1)
                throw new Exception("Alert must be unique");

            return alertDtos.FirstOrDefault();
        }
    }
}