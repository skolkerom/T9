﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Vtb.Broker.Interfaces.EndpointProvider;
using Vtb.Broker.Interfaces.Transport.Http;

namespace Vtb.Broker.Infrastructure.Web
{
    public class WebRequestService : IWebRequestService
    {
        private readonly ILogger<WebRequestService> _logger;
        private readonly IEndpointProvider _endpointProvider;

        public WebRequestService(ILogger<WebRequestService> logger, IEndpointProvider endpointProvider)
        {
            _logger = logger;
            _endpointProvider = endpointProvider;
        }
        
        public async Task<byte[]> GetPageContent(string url)
        {
            _logger.LogInformation("Вызов " + nameof(GetPageContent) + " " + url);
            
            var request = WebRequest.Create(url);
            
            using var response = await request.GetResponseAsync();
            await using var stream = response.GetResponseStream();

            await using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);

            _logger.LogInformation("Вызов завершен. " + memoryStream.Length + " байт получено");

            return memoryStream.ToArray();
        }

        public async Task PostAsync<TBody>(string serviceName, string command, TBody body, string jwtToken)
        {
            var endpoint = _endpointProvider.GetEndpoint(serviceName);
            
            var baseUri = new Uri(endpoint.Host);

            var uri = new Uri(baseUri, command);

            _logger.LogInformation($"{nameof(PostAsync)} {serviceName} {command} {uri.AbsoluteUri} {body}");

            using var httpClientHandler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };
            
            using var client = new HttpClient(httpClientHandler);
            
            client.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", jwtToken);
            
            await client.PostAsync(uri.AbsoluteUri, new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json"));
            
            _logger.LogInformation($"{nameof(PostAsync)} completed");
        }
        
        public async Task PostAsync<TBody>(string serviceName, string command, TBody body)
        {
            var endpoint = _endpointProvider.GetEndpoint(serviceName);
            
            var baseUri = new Uri(endpoint.Host);

            var uri = new Uri(baseUri, command);

            _logger.LogInformation($"{nameof(PostAsync)} {serviceName} {command} {uri.AbsoluteUri} {body}");

            using var httpClientHandler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };
            
            using var client = new HttpClient(httpClientHandler);
            
            await client.PostAsync(uri.AbsoluteUri, new StringContent(JsonConvert.SerializeObject(body), Encoding.UTF8, "application/json"));
            
            _logger.LogInformation($"{nameof(PostAsync)} completed");
        }
    }
}