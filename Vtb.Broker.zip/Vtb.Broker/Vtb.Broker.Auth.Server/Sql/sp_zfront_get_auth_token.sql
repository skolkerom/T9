﻿-- Процедура получения JWT
-- 2020-01-17 / BR-17440 / Абакумов О.В.

create or alter proc [rm].[sp_zfront_get_auth_token]
    @user varchar(255),
    @password varchar(255),
    @token varchar(max) out    
as

set nocount on

begin try

  declare @header nvarchar(max) = 'Content-Type: application/json'
  declare @response nvarchar(max) = null
  declare @url nvarchar(max) = null
  declare @request nvarchar(max) = 
    (select @user as [user], @password as [password], cast(1 as bit) useInternalAuth  for json path, without_array_wrapper)
  declare @timeout int = 5000
  
  select @url = Host from rm.Endpoint where Code = 'AuthServer'
  if @url is null 
	set @url = 'https://zmom:5011'

  set @url = @url + '/Auth/GetToken'

  exec dbo.sp_http_request
         @url        = @url,
         @method     = 'POST',
         @header     = @header output,
         @timeout    = @timeout,
         @request    = @request,
         @response   = @response output

  set @token = @response

end try
begin catch
    declare @error varchar(max) = error_message()
    set @response = 'Url = ' + isnull(@url, '')
    set @error = @response + @error
    raiserror(@error, 16, 1)
end catch
