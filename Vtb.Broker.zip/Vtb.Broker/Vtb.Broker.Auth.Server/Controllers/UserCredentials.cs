﻿namespace Vtb.Broker.Auth.Server.Controllers
{
    public class UserCredentials
    {
        public string User { get; set; }
        public string Password { get; set; }
        public string RequestId { get; set; }
        public bool UseInternalAuth { get; set; }
    }
}