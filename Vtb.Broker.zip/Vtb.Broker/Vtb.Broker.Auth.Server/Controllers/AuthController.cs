﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Vtb.Broker.Infrastructure.Auth;

namespace Vtb.Broker.Auth.Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly SignInManagerFactory _signInManagerFactory;
        private readonly ILogger<AuthController> _logger;
        private readonly TokenGenerator _tokenGenerator;

        public AuthController(SignInManagerFactory signInManagerFactory, ILogger<AuthController> logger, TokenGenerator tokenGenerator)
        {
            _signInManagerFactory = signInManagerFactory;
            _logger = logger;
            _tokenGenerator = tokenGenerator;
        }
        
        [HttpPost]
        [Route("GetToken")]
        public Task<IActionResult> GetToken([FromBody]UserCredentials credentials)
        {
            _logger.LogInformation(nameof(GetToken) + " " + credentials.User);
            
            var signInType = credentials.UseInternalAuth ? SignInType.InternalUserPassword :
                !string.IsNullOrWhiteSpace(credentials.RequestId) ? SignInType.BackOfficeUserRequest :
                SignInType.ZFrontUserPassword;
            
            _logger.LogInformation($"SignInType = {signInType}");

            var signInManager = _signInManagerFactory.GetSignInManager(signInType);

            var result = signInManager.CheckCredentials(new Credentials
            {
                Login = credentials.User,
                Password = credentials.Password,
                RequestId = credentials.RequestId
            });
            
            _logger.LogInformation($"Auth result: {result.Success}");
                
            if (result.Success)
            {
                var ipAddress = HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();

                var jwt = _tokenGenerator.GetToken(credentials.User, result.UserName, result.HostName ?? ipAddress,
                    new[] {"None"});
                
                var accessToken = new JwtSecurityTokenHandler().WriteToken(jwt); 

                return Task.FromResult<IActionResult>(Ok(accessToken));
            }

            return Task.FromResult<IActionResult>(Unauthorized());
        }
    }
}