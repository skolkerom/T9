﻿using Vtb.Broker.Infrastructure.Host;
using Vtb.Broker.Interfaces.EndpointProvider;
using Vtb.Broker.MoexRiskDownloader.DAL;

namespace Vtb.Broker.MoexRiskDownloader
{
    class Program
    {
        static void Main(string[] args)
        {
            Bootstrap.Run<Startup, MoexDownloaderContext>(args, Endpoints.MoexRiskDownloader, new ContextFactoryDesignTime());
        }
    }
}