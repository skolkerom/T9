﻿using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.MoexRiskDownloader.DAL
{
    public class ContextFactoryDesignTime : ContextDesignTimeFactoryBase<MoexDownloaderContext>
    {
        public ContextFactoryDesignTime() 
            : base(ConnectionStringsNames.DefaultConnection)
        {
        }
    }
}