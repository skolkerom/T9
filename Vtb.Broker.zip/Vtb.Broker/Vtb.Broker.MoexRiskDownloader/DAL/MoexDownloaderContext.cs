﻿using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.MoexRiskDownloader.DAL
{
    public class MoexDownloaderContext : DbContextBase
    {
        public virtual DbSet<MoexRiskRateFile> MoexRiskRates { get; set; }
        
        public MoexDownloaderContext(DbContextOptions options) : base(options)
        {
        }

        public MoexDownloaderContext(string connectionString) : base(connectionString)
        {
        }
    }
}