﻿using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.MoexRiskDownloader.DAL.Repositories
{
    public interface IMoexRiskRatesCommandRepository
    {
        Task Save(DateTime date, byte[] content);
    }

    public class MoexRiskRatesCommandRepository : IMoexRiskRatesCommandRepository
    {
        private readonly IContextFactory<MoexDownloaderContext> _factory;

        public MoexRiskRatesCommandRepository(IContextFactory<MoexDownloaderContext> factory)
        {
            _factory = factory;
        }

        public async Task Save(DateTime date, byte[] content)
        {
            await using var context = _factory.Create();

            context.MoexRiskRates.Add(new MoexRiskRateFile
            {
                Date = date,
                Content = content
            });

            await context.SaveChangesAsync();
        }
    }
}