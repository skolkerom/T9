﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.MoexRiskDownloader.DAL.Repositories
{
    public interface IMoexRiskRatesQueryRepository
    {
        Task<byte[]> GetMoexRiskFileAsBytes(DateTime date);
    }

    public class MoexRiskRatesQueryRepository : IMoexRiskRatesQueryRepository
    {
        private readonly IContextFactory<MoexDownloaderContext> _contextFactory;

        public MoexRiskRatesQueryRepository(IContextFactory<MoexDownloaderContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        
        public async Task<byte[]> GetMoexRiskFileAsBytes(DateTime date)
        {
            await using var context = _contextFactory.Create();
            return await context.MoexRiskRates
                .Where(r => r.Date == date)
                .Select(r => r.Content)
                .FirstOrDefaultAsync();
        }
    }
}