﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Interfaces.Transport.Http;
using Vtb.Broker.MoexRiskDownloader.DAL.Repositories;

namespace Vtb.Broker.MoexRiskDownloader.Api
{
    [Route("MoexRiskRates")]
    [ApiController]
    public class MoexRiskDownloaderService : ControllerBase
    {
        private readonly IWebRequestService _webRequestService;
        private readonly IMoexRiskRatesCommandRepository _repository;
        private readonly IConfiguration _configuration;

        public MoexRiskDownloaderService(IWebRequestService webRequestService,
            IMoexRiskRatesCommandRepository repository,
            IConfiguration configuration)
        {
            _webRequestService = webRequestService;
            _repository = repository;
            _configuration = configuration;
        }
        
        [HttpPost]
        public async Task SaveMoexRiskRatesAsBytesAsync(DateTimeParameter date)
        {
            var url = _configuration.GetSection("MoexRiskRates").GetSection("Url").Value;
            var bytes = await _webRequestService.GetPageContent(url);

            await _repository.Save(date.Date, bytes);
        }
    }

    public class DateTimeParameter
    {
        public DateTime Date { get; set; }
    }
}