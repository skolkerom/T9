﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.MoexRiskDownloader.DAL;
using Vtb.Broker.MoexRiskDownloader.DAL.Repositories;

namespace Vtb.Broker.MoexRiskDownloader
{
    public static class IocConfigurator
    {
        public static void RegisterServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IMoexRiskRatesCommandRepository, MoexRiskRatesCommandRepository>();
            services.AddScoped<IMoexRiskRatesQueryRepository, MoexRiskRatesQueryRepository>();
            
            var connectionString = configuration.GetConnectionString(ConnectionStringsNames.DefaultConnection);
            
            services.AddSingleton<IContextFactory<MoexDownloaderContext>>(container =>
                new ContextFactory<MoexDownloaderContext>(() => new MoexDownloaderContext(connectionString),
                    container.GetRequiredService<ILoggerFactory>()));
        }
    }
}