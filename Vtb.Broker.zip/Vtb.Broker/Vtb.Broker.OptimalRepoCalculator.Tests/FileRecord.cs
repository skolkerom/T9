﻿using System;
using Vtb.Broker.OptimalRepoCalculator.DAL;

namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    public class FileRecord
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string CurrencyCode { get; set; }
        public decimal Quantity { get; set; }
        public decimal FxRate { get; set; }
        
        public DateTime Repo1Date { get; set; }
        public DateTime Repo2Date { get; set; }
        
        public TypeInstrument TypeInstrument { get; set; }
        public decimal Rate { get; set; }
        public bool IsIndividualInvestmentAccount { get; set; }
        public bool ExcludeIndividualInvestmentAccount { get; set; }
        public decimal Rate2 { get; set; }
    }
}