﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Infrastructure;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries;
using Vtb.Broker.OptimalRepoCalculator.Services;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    [TestClass]
    public class ScriptRunner
    {
        [TestMethod] 
        //[Ignore]
        public async Task Test()
        {
            var services = new ServiceCollection();
            
            services.AddVtbLogging();
            var configuration = services.AddVtbConfig(environment:"Production");
            services.AddInfrastructure(configuration);
            services.AddMapper(x => { x.CreateMap<InstrumentPosition, InstrumentPosition>(); });
            services.AddScheduler(configuration);
            services.RegisterServices(configuration);
            
            var userProvider = new Mock<ICurrentUserProvider>();
            userProvider.Setup(p => p.GetCurrentUser()).Returns(new User() {Login = "x", Name = "x"});
            services.AddSingleton(userProvider.Object);

            var sp = services.BuildServiceProvider();

            var orchestrator = sp.GetRequiredService<Orchestrator>();

            var result = await orchestrator.GenerateRepoOperationsAndSaveResults(DateTime.Now.Date, "74475270");
        }
    }
}