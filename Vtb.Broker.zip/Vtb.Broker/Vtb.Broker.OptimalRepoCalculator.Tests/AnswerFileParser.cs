﻿using System.Globalization;
using System.IO;
using System.Linq;

namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    class AnswerFileParser
    {
        public Result[] Parse(string fileName)
        {
            var lines = File.ReadAllLines(fileName).Skip(1).Select(x => x.Split(";")).ToArray();

            var result = lines.Select(x => new Result
            {
                Name = x[0],
                Quantity = decimal.Parse(x[1], CultureInfo.InvariantCulture)
            }).ToArray();

            return result;
        }
    }
}