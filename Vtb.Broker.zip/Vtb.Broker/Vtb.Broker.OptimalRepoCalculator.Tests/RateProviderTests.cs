﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    [TestClass]
    public class RateProviderTests
    {
        private static readonly string ClientCode1 = "clientCode1";
        private static readonly string ClientCode2 = "clientCode2";
        private static readonly string ClientCode3 = "clientCode3";
        private static readonly string ClientCode4 = "clientCode4";
        private static readonly string ClientCode5 = "clientCode5";
        private static readonly string ClientCode6 = "clientCode6";
        private static readonly string ClientCode7 = "clientCode7";
        private static readonly string ClientCode8 = "clientCode8";
        
        private static readonly Rate R1 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            ClientCode = ClientCode1,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 10000000
        };
        
        private static readonly Rate R2 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            ClientCode = ClientCode1,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 10000000,
            PaymentCurrency = "USD"
        };
        
        private static Rate _r3 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            ClientCode = ClientCode2,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 10000000,
            PaymentCurrency = "USD"
        };
        
        private static readonly Rate R4 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            ClientCode = ClientCode2,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 10000000,
            PaymentCurrency = "USD"
        };
        
        private static readonly Rate R5 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 10000000
        };
        
        private static readonly Rate R6 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 10,
            ClientCode = ClientCode4
        };
        
        private static readonly Rate R7 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            InstrumentType = OvernightDistributionInstrumentType.Currency,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode5
        };
        
        private static readonly Rate R8 = new Rate
        {
            Rate1 = 0.01M,
            Rate2 = 0.02M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode5
        };       
        
        private static readonly Rate R9 = new Rate
        {
            Rate1 = 0.02M,
            Rate2 = 0.03M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode6
        };   
        
        private static readonly Rate R10 = new Rate
        {
            Rate1 = 0.03M,
            Rate2 = 0.04M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode6
        };   
        
        private static readonly Rate R11 = new Rate
        {
            Rate1 = 0.03M,
            Rate2 = 0.04M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode7,
            TariffId = 1
        };   
        
        private static readonly Rate R12 = new Rate
        {
            Rate1 = 0.03M,
            Rate2 = 0.04M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode7
        };   
        
        private static readonly Rate R13 = new Rate
        {
            Rate1 = 0.03M,
            Rate2 = 0.04M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode8,
            TariffId = 2
        };
        
        private static readonly Rate R14 = new Rate
        {
            Rate1 = 0.03M,
            Rate2 = 0.04M,
            InstrumentType = OvernightDistributionInstrumentType.Security,
            VolumeFrom = 0,
            VolumeTo = 1000000,
            ClientCode = ClientCode8,
            TariffId = 1
        };   
        
        private static readonly Rate[] Rates = {
            R1, R2, _r3, R4, R5, R6, R7, R8, R9, R10, R11, R12, R13, R14
        };
        
        
        [TestMethod]
        public void PaymentCurrencyTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode1,
                InstrumentType = OvernightDistributionInstrumentType.Currency,
                Currency = "USD"
            });

            Assert.AreEqual(R2, rate);
        }
        
        [TestMethod]
        public void DefaultCurrencyRateTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode3,
                InstrumentType = OvernightDistributionInstrumentType.Currency,
                Currency = "USD"
            });

            Assert.AreEqual(R5, rate);
        }
        
        [TestMethod]
        public void VolumeOutOfRangeIgnoredTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode4,
                InstrumentType = OvernightDistributionInstrumentType.Currency,
                Currency = "USD",
                Volume = 100
            });

            Assert.AreEqual(R5, rate);
        }
        
        [TestMethod]
        public void InstrumentTypeTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode5,
                InstrumentType = OvernightDistributionInstrumentType.Security,
                Currency = "USD"
            });

            Assert.AreEqual(R8, rate);
        }

        [TestMethod]
        public void MaxRateTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode6,
                InstrumentType = OvernightDistributionInstrumentType.Security,
                Currency = "USD"
            });

            Assert.AreEqual(R10, rate);
        }
        
        [TestMethod]
        public void NoTariffUseDefaultTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode7,
                InstrumentType = OvernightDistributionInstrumentType.Security,
                Currency = "USD",
                TariffId = 2
            });

            Assert.AreEqual(R12, rate);
        }
        
        [TestMethod]
        public void TariffTest()
        {
            var rateProvider = new RateProvider(Rates);

            var rate = rateProvider.GetRate(new RateKey
            {
                ClientCode = ClientCode8,
                InstrumentType = OvernightDistributionInstrumentType.Security,
                Currency = "USD",
                TariffId = 1
            });

            Assert.AreEqual(R14, rate);
        }
        
    }
}