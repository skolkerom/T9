﻿namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    struct Result
    {
        public string Name { get; set; }

        public decimal Quantity { get; set; }
    }
}