﻿using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Vtb.Broker.OptimalRepoCalculator;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using Vtb.Broker.Infrastructure;
using System.Collections.Generic;
using System;
using Microsoft.Extensions.Configuration;
using Moq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.OptimalRepoCalculator.DAL;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    [TestClass]
    public class InstrumentSelectorTests
    {
        private InstrumentSelector _calculator;

        
        [TestMethod]
        [Ignore]
        public void Test4Debug()
        {
            RunTestCase("test_13");
        }

        [TestInitialize]
        public void InitializeTest()
        {
            var services = new ServiceCollection();
            var config = services.AddVtbConfig();
            services.AddInfrastructure(config);
            services.AddMapper(x=>{});
            services.AddTransient<InstrumentSelector>();            

            var sp = services.BuildServiceProvider();

            _calculator = sp.GetService<InstrumentSelector>();
        }

        [TestMethod]
        public void TestAll()
        {
            var files = Directory
                .GetFiles("TestFiles")
                .Select(Path.GetFileNameWithoutExtension)
                .Where(x => !x.EndsWith("result"))
                .ToArray();

            var exceptions = new List<Exception>();

            foreach (var testName in files)
            {
                try
                {
                    RunTestCase(testName);
                }
                catch(Exception e)
                {
                    exceptions.Add(new Exception(testName, e));
                }
            }

            if(exceptions.Count > 0)
                throw new AggregateException(exceptions);
        }

        private void RunTestCase(string testName)
        {
            var parser = new FileParser();
            var testData = parser.Parse($@"TestFiles\{testName}.csv");
            var answer = new AnswerFileParser().Parse($@"TestFiles\{testName}_result.csv");
            var rates = testData.Select(x => new Rate
            {
                Rate2 = x.Rate,
                Rate1 = 0,
                VolumeFrom = 0,
                VolumeTo = decimal.MaxValue,
                InstrumentType = x.TypeInstrument == TypeInstrument.Security
                    ? OvernightDistributionInstrumentType.Security
                    : OvernightDistributionInstrumentType.Currency
            }).ToArray();

            var instruments = testData.Select(x => new InstrumentPosition
            {
                Instrument = new Instrument
                {
                    InstrumentCode = x.Name,
                    Price = x.Price,
                    CurrencyCode = x.CurrencyCode,
                    FxRate = x.FxRate,
                    Repo1Date = x.Repo1Date,
                    Repo2Date = x.Repo2Date,
                    InstrumentType = x.TypeInstrument == TypeInstrument.Security
                        ? OvernightDistributionInstrumentType.Security
                        : OvernightDistributionInstrumentType.Currency,
                    ExcludeForIndividualInvestmentAccount = x.ExcludeIndividualInvestmentAccount
                },
                Quantity = x.Quantity,
                IsIndividualInvestmentAccount = x.IsIndividualInvestmentAccount
            }).ToArray();

            var result = _calculator.SelectInstruments("test", instruments, new RateProvider(rates), "USD")
                .Select(x => new Result
                {
                    Name = x.InstrumentPosition.Instrument.InstrumentCode,
                    Quantity = x.Quantity
                }).ToArray();

            CollectionAssert.AreEquivalent(answer, result);
        }
    }
}
