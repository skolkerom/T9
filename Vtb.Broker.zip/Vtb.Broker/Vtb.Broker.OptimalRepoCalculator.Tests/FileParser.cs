using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Vtb.Broker.OptimalRepoCalculator.DAL;

namespace Vtb.Broker.OptimalRepoCalculator.Tests
{
    public class FileParser
    {
        
        
        public FileRecord[] Parse(string fileName)
        {
            var lines = File.ReadAllLines(fileName).Skip((1)).ToList();

            var instruments = new List<FileRecord>();

            foreach (string line in lines)
            {
                string[] temp = line.Split(';');

                string GetValue(int index) => temp.Length > index ? temp[index] : null;
        
                if (temp.Length >= 2)
                {
                    var instrument = new FileRecord()
                    {
                        Name = temp[0].Trim(),
                        CurrencyCode = temp[1].Trim(),
                        Price = decimal.Parse(temp[2].Trim(), CultureInfo.InvariantCulture),
                        Quantity = decimal.Parse(temp[4].Trim(), CultureInfo.InvariantCulture),
                        FxRate = decimal.Parse(temp[5].Trim(), CultureInfo.InvariantCulture),
                        Repo1Date = new DateTime(2019, 1, 2),
                        Repo2Date = new DateTime(2019, 1, 3),
                        TypeInstrument =
                            temp[3].Trim() != "FX" ? TypeInstrument.Security : TypeInstrument.CurrencyOther,
                        Rate = temp[3].Trim() == "FX"
                            ? decimal.Parse(temp[7].Trim(), CultureInfo.InvariantCulture)
                            : decimal.Parse(temp[6].Trim(), CultureInfo.InvariantCulture),
                        //Rate2 = decimal.Parse(temp[7].Trim(), CultureInfo.InvariantCulture),
                        IsIndividualInvestmentAccount = GetValue(8) == "1",
                        ExcludeIndividualInvestmentAccount = GetValue(9) == "1"
                    };

                    instruments.Add(instrument);
                }
            }

            return instruments.ToArray();
        }

        
    }
}
