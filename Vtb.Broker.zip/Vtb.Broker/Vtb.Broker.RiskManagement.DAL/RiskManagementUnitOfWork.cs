using System;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.UnitOfWork;
using Vtb.Broker.RiskManagement.DAL.Contexts;

namespace Vtb.Broker.RiskManagement.DAL
{
    public class RiskManagementUnitOfWork : UnitOfWork<RiskManagementContext>, IUnitOfWork
    {
        public RiskManagementUnitOfWork(IServiceProvider serviceProvider) 
            : base(serviceProvider)
        {
        }
    }
}
