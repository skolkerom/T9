﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class DummyMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("delete from rm.RiskRateHistory");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
