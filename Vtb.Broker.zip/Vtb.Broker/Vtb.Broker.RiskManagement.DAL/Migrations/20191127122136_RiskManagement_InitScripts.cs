﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class RiskManagement_InitScripts : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var dir = MigrationExtensions.GetSqlScriptsDirectory();

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Procedures", "sp_http_request.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Types", "RiskRateInstrumentTable.sql")));
            
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Views", "v_active_risk_rate.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Views", "v_zfront_risk_category_marketplace.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Views", "v_zfront_risk_category.sql")));    
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Views", "v_zfront_user.sql")));          

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Functions", "Inline", "fn_get_margin_instrument_rates.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Functions", "MultiStatement", "fn_get_active_risk_rates.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Functions", "MultiStatement", "fn_get_history_risk_rates.sql")));
            

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Procedures", "sp_zfront_get_margin_instrument_rates.sql")));
            
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Triggers", "InstrumentInMarginInstrumentList_Period_Check_IUD.sql")));

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_board_table.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_date_table.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_baseriskcategory_table.sql")));            
            
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_scheduler.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_file_detector.sql")));
            
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_opt_repo_endpoint.sql")));
            
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_margininstrumentlist_table.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_margininstrument_table.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_instrumentinmarginlist_table.sql")));
            
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            var dir = MigrationExtensions.GetSqlScriptsDirectory();

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "delete_scheduler.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "delete_file_detector.sql")));
            
            migrationBuilder.Sql("drop function rm.fn_get_margin_instrument_rates");
            migrationBuilder.Sql("drop function rm.fn_get_active_risk_rates");
            migrationBuilder.Sql("drop function rm.fn_get_history_risk_rates");

            migrationBuilder.Sql("drop type RiskRateInstrumentTable");
            migrationBuilder.Sql("drop table rm.Endpoint");
        }
    }
}
