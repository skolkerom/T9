﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class RiskManagement_InternalAuth : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var dir = MigrationExtensions.GetSqlScriptsDirectory();

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "init_user_table.sql")));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            var dir = MigrationExtensions.GetSqlScriptsDirectory();

            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Scripts", "delete_user_table.sql")));
        }
    }
}
