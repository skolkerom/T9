﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class AddedUrlsToEndpoint : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"alter table rm.Endpoint add Urls varchar(max) null");

            migrationBuilder.Sql(@"merge rm.Endpoint as target  
    using (select Code from rm.Endpoint where Code = 'RiskManagement') AS source(Code)
    on (target.Code = source.Code)  
    when matched then
        update
            set Host = 'http://zmom:5002', Urls = 'http://zmom:5002'
    when not matched then
        insert (Code, Host, Urls)
        values ('RiskManagement', 'http://zmom:5002', 'http://zmom:5002');
");

            migrationBuilder.Sql(@"merge rm.Endpoint as target  
    using (select Code from rm.Endpoint where Code = 'OptimalRepoCalculator') AS source(Code)
    on (target.Code = source.Code)  
    when matched then
        update
            set Host = 'http://zmom:5006', Urls = 'http://zmom:5006'
    when not matched then
        insert (Code, Host, Urls)
        values ('OptimalRepoCalculator', 'http://zmom:5006', 'http://zmom:5006');");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"alter table rm.Endpoint drop column Urls");
        }
    }
}