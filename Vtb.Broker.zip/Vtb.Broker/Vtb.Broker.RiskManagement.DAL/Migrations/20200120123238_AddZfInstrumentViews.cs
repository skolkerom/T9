﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Infrastructure.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class AddZfInstrumentViews : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeploySqlFile(@"Views\v_zfront_instrument.sql");
            migrationBuilder.DeploySqlFile(@"Views\v_zfront_instrument_type.sql");
            migrationBuilder.DeploySqlFile(@"Views\v_api_margin_instruments_transfer_places.sql");
            
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_margin_instrument_market_data.sql");
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_margin_instruments.sql");
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_risk_categories.sql");
            
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_changed_margin_instrument_rates.sql");
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_margin_instrument_rates.sql");
            migrationBuilder.DeploySqlFile(@"Procedures\sp_set_changed_margin_instrument_rates.sql");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
