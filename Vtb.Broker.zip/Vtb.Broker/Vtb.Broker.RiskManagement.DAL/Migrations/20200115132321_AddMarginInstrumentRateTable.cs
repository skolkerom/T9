﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class AddMarginInstrumentRateTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MarginInstrumentRate",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InstrumentInMarginInstrumentListId = table.Column<long>(nullable: false),
                    Isin = table.Column<string>(nullable: true),
                    ListId = table.Column<long>(nullable: false),
                    RateLong = table.Column<decimal>(type: "decimal (19,8)", nullable: true),
                    RateShort = table.Column<decimal>(type: "decimal (19,8)", nullable: true),
                    RateLongStandart = table.Column<decimal>(type: "decimal (19,8)", nullable: true),
                    RateShortStandart = table.Column<decimal>(type: "decimal (19,8)", nullable: true),
                    CreatedUser = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    RateDate = table.Column<DateTime>(nullable: true),
                    RateDateTime = table.Column<DateTime>(nullable: false),
                    IsVtbOnly = table.Column<bool>(nullable: false),
                    IsMarginal = table.Column<bool>(nullable: false),
                    IsRestricted = table.Column<bool>(nullable: false),
                    IsLong = table.Column<bool>(nullable: false),
                    IsShort = table.Column<bool>(nullable: false),
                    IsSentToOlb = table.Column<bool>(nullable: false, defaultValue: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrumentRate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MarginInstrumentRate_InstrumentInMarginInstrumentList_InstrumentInMarginInstrumentListId",
                        column: x => x.InstrumentInMarginInstrumentListId,
                        principalSchema: "rm",
                        principalTable: "InstrumentInMarginInstrumentList",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentRate_InstrumentInMarginInstrumentListId",
                schema: "rm",
                table: "MarginInstrumentRate",
                column: "InstrumentInMarginInstrumentListId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentRate_RateDateTime",
                schema: "rm",
                table: "MarginInstrumentRate",
                column: "RateDateTime");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MarginInstrumentRate",
                schema: "rm");
        }
    }
}
