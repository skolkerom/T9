﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class ProceduresForSendingMarginInstrumentRateToOlb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var script = Path.Combine(MigrationExtensions.GetSqlScriptsDirectory(), "Procedures",
                "sp_zfront_get_changed_margin_instrument_rates.sql");
            migrationBuilder.Sql(File.ReadAllText(script));
            
            var script1 = Path.Combine(MigrationExtensions.GetSqlScriptsDirectory(), "Procedures",
                "sp_zfront_set_changed_margin_instrument_rates.sql");
            migrationBuilder.Sql(File.ReadAllText(script1));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            
        }
    }
}
