﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class RiskManagement_Init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "rm");

            migrationBuilder.CreateTable(
                name: "Audit",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActionType = table.Column<int>(nullable: false),
                    EventDateTime = table.Column<DateTime>(nullable: false),
                    EntityId = table.Column<long>(nullable: true),
                    User = table.Column<string>(nullable: false),
                    Message = table.Column<string>(nullable: true),
                    DetailsJson = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Audit", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BaseRiskCategory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Code = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BaseRiskCategory", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Board",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(nullable: true),
                    ShortName = table.Column<string>(nullable: true),
                    LatName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Board", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Date",
                schema: "rm",
                columns: table => new
                {
                    Value = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Date", x => x.Value);
                });

            migrationBuilder.CreateTable(
                name: "MarginInstrument",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Isin = table.Column<string>(nullable: false),
                    ShortName = table.Column<string>(nullable: true),
                    Ticker = table.Column<string>(nullable: true),
                    Type = table.Column<string>(nullable: true),
                    CreatedUser = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrument", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MarginInstrumentList",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: false),
                    Code = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    CreatedUser = table.Column<string>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrumentList", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MarginInstrumentHistory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Isin = table.Column<string>(nullable: true),
                    ShortName = table.Column<string>(nullable: true),
                    Ticker = table.Column<string>(nullable: true),
                    Type = table.Column<string>(nullable: true),
                    CreatedUser = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    EntityId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrumentHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MarginInstrumentHistory_MarginInstrument_EntityId",
                        column: x => x.EntityId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrument",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "MarginInstrumentTransferPlace",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MarginInstrumentId = table.Column<long>(nullable: false),
                    TransferPlaceId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrumentTransferPlace", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MarginInstrumentTransferPlace_MarginInstrument_MarginInstrumentId",
                        column: x => x.MarginInstrumentId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrument",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_MarginInstrumentTransferPlace_Board_TransferPlaceId",
                        column: x => x.TransferPlaceId,
                        principalSchema: "rm",
                        principalTable: "Board",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "InstrumentInMarginInstrumentList",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ListId = table.Column<long>(nullable: false),
                    MarginInstrumentId = table.Column<long>(nullable: false),
                    IsVtbOnly = table.Column<bool>(nullable: false),
                    TransferRate = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    TransferPlace = table.Column<string>(nullable: true),
                    IsMarginal = table.Column<bool>(nullable: false),
                    IsRestricted = table.Column<bool>(nullable: false),
                    IsLong = table.Column<bool>(nullable: false),
                    IsShort = table.Column<bool>(nullable: false),
                    StartDate = table.Column<DateTime>(type: "Date", nullable: false),
                    EndDate = table.Column<DateTime>(type: "Date", nullable: true),
                    CreatedUser = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InstrumentInMarginInstrumentList", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InstrumentInMarginInstrumentList_MarginInstrumentList_ListId",
                        column: x => x.ListId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentList",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_InstrumentInMarginInstrumentList_MarginInstrument_MarginInstrumentId",
                        column: x => x.MarginInstrumentId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrument",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "MarginInstrumentListHistory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EntityId = table.Column<long>(nullable: false),
                    Name = table.Column<string>(nullable: false),
                    CreatedUser = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrumentListHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MarginInstrumentListHistory_MarginInstrumentList_EntityId",
                        column: x => x.EntityId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentList",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "RiskCategory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(maxLength: 30, nullable: false),
                    Name = table.Column<string>(nullable: false),
                    FormingPrinciple = table.Column<int>(nullable: false),
                    Rate = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    QualifiedInvestor = table.Column<int>(nullable: false),
                    IndividualInvestmentAccount = table.Column<int>(nullable: false),
                    BaseRiskCategoryId = table.Column<long>(nullable: false),
                    QuikTemplate = table.Column<string>(nullable: false),
                    CreatedUser = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    MarginInstrumentListId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiskCategory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RiskCategory_BaseRiskCategory_BaseRiskCategoryId",
                        column: x => x.BaseRiskCategoryId,
                        principalSchema: "rm",
                        principalTable: "BaseRiskCategory",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_RiskCategory_MarginInstrumentList_MarginInstrumentListId",
                        column: x => x.MarginInstrumentListId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentList",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RiskRate",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Source = table.Column<int>(nullable: false),
                    Isin = table.Column<string>(nullable: false),
                    RateDate = table.Column<DateTime>(type: "date", nullable: false),
                    RateLong = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    RateShort = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    RateLongStandart = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    RateShortStandart = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    FileName = table.Column<string>(nullable: true),
                    CreatedUser = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    MarginInstrumentListId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiskRate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RiskRate_MarginInstrumentList_MarginInstrumentListId",
                        column: x => x.MarginInstrumentListId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentList",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "MarginInstrumentHistoryTransferPlace",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MarginInstrumentId = table.Column<long>(nullable: false),
                    TransferPlaceId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MarginInstrumentHistoryTransferPlace", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MarginInstrumentHistoryTransferPlace_MarginInstrumentHistory_MarginInstrumentId",
                        column: x => x.MarginInstrumentId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentHistory",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_MarginInstrumentHistoryTransferPlace_Board_TransferPlaceId",
                        column: x => x.TransferPlaceId,
                        principalSchema: "rm",
                        principalTable: "Board",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "InstrumentInMarginInstrumentListHistory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ListId = table.Column<long>(nullable: false),
                    MarginInstrumentId = table.Column<long>(nullable: false),
                    IsVtbOnly = table.Column<bool>(nullable: false),
                    TransferRate = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    TransferPlace = table.Column<string>(nullable: true),
                    IsMarginal = table.Column<bool>(nullable: false),
                    IsRestricted = table.Column<bool>(nullable: false),
                    IsLong = table.Column<bool>(nullable: false),
                    IsShort = table.Column<bool>(nullable: false),
                    CreatedUser = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    EntityId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InstrumentInMarginInstrumentListHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InstrumentInMarginInstrumentListHistory_InstrumentInMarginInstrumentList_EntityId",
                        column: x => x.EntityId,
                        principalSchema: "rm",
                        principalTable: "InstrumentInMarginInstrumentList",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_InstrumentInMarginInstrumentListHistory_MarginInstrumentList_ListId",
                        column: x => x.ListId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentList",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_InstrumentInMarginInstrumentListHistory_MarginInstrument_MarginInstrumentId",
                        column: x => x.MarginInstrumentId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrument",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "RiskCategoryHistory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Rate = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    IsQualified = table.Column<bool>(nullable: false),
                    IsIndividualInvestmentAccount = table.Column<bool>(nullable: false),
                    BaseRiskCategoryId = table.Column<long>(nullable: false),
                    CreatedUser = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    QuikTemplate = table.Column<string>(nullable: true),
                    EntityId = table.Column<long>(nullable: false),
                    MarginInstrumentListId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiskCategoryHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RiskCategoryHistory_BaseRiskCategory_BaseRiskCategoryId",
                        column: x => x.BaseRiskCategoryId,
                        principalSchema: "rm",
                        principalTable: "BaseRiskCategory",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_RiskCategoryHistory_RiskCategory_EntityId",
                        column: x => x.EntityId,
                        principalSchema: "rm",
                        principalTable: "RiskCategory",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_RiskCategoryHistory_MarginInstrumentList_MarginInstrumentListId",
                        column: x => x.MarginInstrumentListId,
                        principalSchema: "rm",
                        principalTable: "MarginInstrumentList",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RiskCategoryMarketplace",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MarketplaceId = table.Column<int>(nullable: false),
                    RiskCategoryId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiskCategoryMarketplace", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RiskCategoryMarketplace_Market_MarketplaceId",
                        column: x => x.MarketplaceId,
                        principalSchema: "lgst",
                        principalTable: "Market",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RiskCategoryMarketplace_RiskCategory_RiskCategoryId",
                        column: x => x.RiskCategoryId,
                        principalSchema: "rm",
                        principalTable: "RiskCategory",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RiskRateHistory",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Source = table.Column<int>(nullable: false),
                    Isin = table.Column<string>(maxLength: 12, nullable: false),
                    RateDate = table.Column<DateTime>(nullable: false),
                    RateLong = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    RateShort = table.Column<decimal>(type: "decimal (19,8)", nullable: false),
                    FileId = table.Column<long>(nullable: false),
                    CreatedUser = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(rowVersion: true, nullable: true),
                    EntityId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiskRateHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RiskRateHistory_RiskRate_EntityId",
                        column: x => x.EntityId,
                        principalSchema: "rm",
                        principalTable: "RiskRate",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "RiskCategoryHistoryMarketplace",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MarketplaceId = table.Column<int>(nullable: false),
                    RiskCategoryId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RiskCategoryHistoryMarketplace", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RiskCategoryHistoryMarketplace_Market_MarketplaceId",
                        column: x => x.MarketplaceId,
                        principalSchema: "lgst",
                        principalTable: "Market",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_RiskCategoryHistoryMarketplace_RiskCategoryHistory_RiskCategoryId",
                        column: x => x.RiskCategoryId,
                        principalSchema: "rm",
                        principalTable: "RiskCategoryHistory",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Board_Code",
                schema: "rm",
                table: "Board",
                column: "Code",
                unique: true,
                filter: "[Code] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_InstrumentInMarginInstrumentList_ListId",
                schema: "rm",
                table: "InstrumentInMarginInstrumentList",
                column: "ListId");

            migrationBuilder.CreateIndex(
                name: "IX_InstrumentInMarginInstrumentList_MarginInstrumentId_ListId",
                schema: "rm",
                table: "InstrumentInMarginInstrumentList",
                columns: new[] { "MarginInstrumentId", "ListId" },
                unique: true,
                filter: "IsDeleted = 0");

            migrationBuilder.CreateIndex(
                name: "IX_InstrumentInMarginInstrumentListHistory_EntityId",
                schema: "rm",
                table: "InstrumentInMarginInstrumentListHistory",
                column: "EntityId");

            migrationBuilder.CreateIndex(
                name: "IX_InstrumentInMarginInstrumentListHistory_ListId",
                schema: "rm",
                table: "InstrumentInMarginInstrumentListHistory",
                column: "ListId");

            migrationBuilder.CreateIndex(
                name: "IX_InstrumentInMarginInstrumentListHistory_MarginInstrumentId",
                schema: "rm",
                table: "InstrumentInMarginInstrumentListHistory",
                column: "MarginInstrumentId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrument_Isin",
                schema: "rm",
                table: "MarginInstrument",
                column: "Isin",
                unique: true,
                filter: "IsDeleted = 0");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentHistory_EntityId",
                schema: "rm",
                table: "MarginInstrumentHistory",
                column: "EntityId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentHistoryTransferPlace_MarginInstrumentId",
                schema: "rm",
                table: "MarginInstrumentHistoryTransferPlace",
                column: "MarginInstrumentId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentHistoryTransferPlace_TransferPlaceId",
                schema: "rm",
                table: "MarginInstrumentHistoryTransferPlace",
                column: "TransferPlaceId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentListHistory_EntityId",
                schema: "rm",
                table: "MarginInstrumentListHistory",
                column: "EntityId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentTransferPlace_MarginInstrumentId",
                schema: "rm",
                table: "MarginInstrumentTransferPlace",
                column: "MarginInstrumentId");

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrumentTransferPlace_TransferPlaceId",
                schema: "rm",
                table: "MarginInstrumentTransferPlace",
                column: "TransferPlaceId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategory_BaseRiskCategoryId",
                schema: "rm",
                table: "RiskCategory",
                column: "BaseRiskCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategory_Code",
                schema: "rm",
                table: "RiskCategory",
                column: "Code",
                unique: true,
                filter: "IsDeleted = 0");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategory_MarginInstrumentListId",
                schema: "rm",
                table: "RiskCategory",
                column: "MarginInstrumentListId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategory_Name",
                schema: "rm",
                table: "RiskCategory",
                column: "Name",
                unique: true,
                filter: "IsDeleted = 0");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryHistory_BaseRiskCategoryId",
                schema: "rm",
                table: "RiskCategoryHistory",
                column: "BaseRiskCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryHistory_EntityId",
                schema: "rm",
                table: "RiskCategoryHistory",
                column: "EntityId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryHistory_MarginInstrumentListId",
                schema: "rm",
                table: "RiskCategoryHistory",
                column: "MarginInstrumentListId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryHistoryMarketplace_MarketplaceId",
                schema: "rm",
                table: "RiskCategoryHistoryMarketplace",
                column: "MarketplaceId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryHistoryMarketplace_RiskCategoryId",
                schema: "rm",
                table: "RiskCategoryHistoryMarketplace",
                column: "RiskCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryMarketplace_MarketplaceId",
                schema: "rm",
                table: "RiskCategoryMarketplace",
                column: "MarketplaceId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskCategoryMarketplace_RiskCategoryId",
                schema: "rm",
                table: "RiskCategoryMarketplace",
                column: "RiskCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskRate_Isin",
                schema: "rm",
                table: "RiskRate",
                column: "Isin");

            migrationBuilder.CreateIndex(
                name: "IX_RiskRate_MarginInstrumentListId",
                schema: "rm",
                table: "RiskRate",
                column: "MarginInstrumentListId");

            migrationBuilder.CreateIndex(
                name: "IX_RiskRate_RateDate_Isin_Source_MarginInstrumentListId",
                schema: "rm",
                table: "RiskRate",
                columns: new[] { "RateDate", "Isin", "Source", "MarginInstrumentListId" },
                unique: true,
                filter: "IsDeleted = 0");

            migrationBuilder.CreateIndex(
                name: "IX_RiskRateHistory_EntityId",
                schema: "rm",
                table: "RiskRateHistory",
                column: "EntityId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Audit",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "Date",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "InstrumentInMarginInstrumentListHistory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "MarginInstrumentHistoryTransferPlace",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "MarginInstrumentListHistory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "MarginInstrumentTransferPlace",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RiskCategoryHistoryMarketplace",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RiskCategoryMarketplace",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RiskRateHistory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "InstrumentInMarginInstrumentList",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "MarginInstrumentHistory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "Board",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RiskCategoryHistory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RiskRate",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "MarginInstrument",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RiskCategory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "BaseRiskCategory",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "MarginInstrumentList",
                schema: "rm");
        }
    }
}
