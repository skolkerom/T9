﻿using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public class RiskRateMigrator : IRiskRateMigrator
    {
        private readonly IContextFactory<RiskManagementContext> _contextFactory;

        public RiskRateMigrator(IContextFactory<RiskManagementContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public void Migrate()
        {
            using var context = _contextFactory.Create();

            context.Database.Migrate();
        }
    }
}
