﻿using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Infrastructure.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class RiskManagement_IsExchangeREPO : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "TransferPlace",
                schema: "rm",
                table: "InstrumentInMarginInstrumentList");

            migrationBuilder.AddColumn<string>(
                name: "Comment",
                schema: "rm",
                table: "RiskCategory",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsExchangeRepo",
                schema: "rm",
                table: "InstrumentInMarginInstrumentList",
                nullable: false,
                defaultValue: false);
            
            migrationBuilder.AddColumn<bool>(
                name: "IsExchangeRepo",
                schema: "rm",
                table: "MarginInstrumentRate",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsExchangeRepo",
                schema: "rm",
                table: "InstrumentInMarginInstrumentListHistory",
                nullable: false,
                defaultValue: false);            
            
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_changed_margin_instrument_rates.sql");
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_margin_instrument_rates.sql");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsExchangeRepo",
                schema: "rm",
                table: "MarginInstrumentRate");

            migrationBuilder.DropColumn(
                name: "IsExchangeRepo",
                schema: "rm",
                table: "InstrumentInMarginInstrumentListHistory");
            
            migrationBuilder.DropColumn(
                name: "Comment",
                schema: "rm",
                table: "RiskCategory");

            migrationBuilder.DropColumn(
                name: "IsExchangeRepo",
                schema: "rm",
                table: "InstrumentInMarginInstrumentList");

            migrationBuilder.AddColumn<string>(
                name: "TransferPlace",
                schema: "rm",
                table: "InstrumentInMarginInstrumentList",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
