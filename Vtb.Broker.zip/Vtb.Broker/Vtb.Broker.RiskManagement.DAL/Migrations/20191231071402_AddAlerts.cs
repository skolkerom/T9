﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class AddAlerts : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Alert",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(maxLength: 1024, nullable: true),
                    Description = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Alert", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AlertEmail",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AlertId = table.Column<long>(nullable: false),
                    Email = table.Column<string>(maxLength: 2048, nullable: true),
                    CreatedUser = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AlertEmail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AlertEmail_Alert_AlertId",
                        column: x => x.AlertId,
                        principalSchema: "rm",
                        principalTable: "Alert",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "AlertEmailTemplate",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AlertId = table.Column<long>(nullable: false),
                    Subject = table.Column<string>(nullable: true),
                    MainTemplate = table.Column<string>(nullable: true),
                    HeaderTemplate = table.Column<string>(nullable: true),
                    DetailTemplate = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    CreatedUser = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedUser = table.Column<string>(nullable: true),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    RowVersion = table.Column<byte[]>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AlertEmailTemplate", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AlertEmailTemplate_Alert_AlertId",
                        column: x => x.AlertId,
                        principalSchema: "rm",
                        principalTable: "Alert",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_AlertEmail_AlertId",
                schema: "rm",
                table: "AlertEmail",
                column: "AlertId");

            migrationBuilder.CreateIndex(
                name: "IX_AlertEmailTemplate_AlertId",
                schema: "rm",
                table: "AlertEmailTemplate",
                column: "AlertId");
            
            migrationBuilder.Sql($@"insert into rm.Alert select 'RiskRatesChanged_Success', 'Успешное изменение рисковых ставок', 0");
            migrationBuilder.Sql($@"insert into rm.Alert select 'RiskRatesChanged_Failure', 'Ошибки при изменении рисковых ставок', 0");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AlertEmail",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "AlertEmailTemplate",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "Alert",
                schema: "rm");
        }
    }
}
