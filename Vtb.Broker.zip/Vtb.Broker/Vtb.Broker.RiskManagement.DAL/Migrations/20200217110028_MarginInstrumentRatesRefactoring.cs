﻿using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Infrastructure.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class MarginInstrumentRatesRefactoring : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeploySqlFile(@"Procedures\sp_get_margin_instrument_rates.sql");
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_margin_instrument_rates.sql");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
