﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class RiskManagement_MarginInstrument_New_Columns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "LongLimit",
                schema: "rm",
                table: "MarginInstrumentHistory",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MarginPriority",
                schema: "rm",
                table: "MarginInstrumentHistory",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "RepoRate",
                schema: "rm",
                table: "MarginInstrumentHistory",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SecurityTypeRateId",
                schema: "rm",
                table: "MarginInstrumentHistory",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "ShortLimit",
                schema: "rm",
                table: "MarginInstrumentHistory",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "LongLimit",
                schema: "rm",
                table: "MarginInstrument",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MarginPriority",
                schema: "rm",
                table: "MarginInstrument",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "RepoRate",
                schema: "rm",
                table: "MarginInstrument",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SecurityTypeRateId",
                schema: "rm",
                table: "MarginInstrument",
                nullable: true);

            migrationBuilder.AddColumn<decimal>(
                name: "ShortLimit",
                schema: "rm",
                table: "MarginInstrument",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_MarginInstrument_SecurityTypeRateId",
                schema: "rm",
                table: "MarginInstrument",
                column: "SecurityTypeRateId");
            
            migrationBuilder.AddColumn<decimal>(
                name: "Discount",
                schema: "rm",
                table: "MarginInstrument",
                nullable: false,
                defaultValue: 0.1m);            
            
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(MigrationExtensions.GetSqlScriptsDirectory(), "Views", "v_zfront_security_type_rate.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(MigrationExtensions.GetSqlScriptsDirectory(), "Views", "v_zfront_market_data.sql")));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Discount",
                schema: "rm",
                table: "MarginInstrument");
            
            migrationBuilder.DropIndex(
                name: "IX_MarginInstrument_SecurityTypeRateId",
                schema: "rm",
                table: "MarginInstrument");

            migrationBuilder.DropColumn(
                name: "LongLimit",
                schema: "rm",
                table: "MarginInstrumentHistory");

            migrationBuilder.DropColumn(
                name: "MarginPriority",
                schema: "rm",
                table: "MarginInstrumentHistory");

            migrationBuilder.DropColumn(
                name: "RepoRate",
                schema: "rm",
                table: "MarginInstrumentHistory");

            migrationBuilder.DropColumn(
                name: "SecurityTypeRateId",
                schema: "rm",
                table: "MarginInstrumentHistory");

            migrationBuilder.DropColumn(
                name: "ShortLimit",
                schema: "rm",
                table: "MarginInstrumentHistory");

            migrationBuilder.DropColumn(
                name: "LongLimit",
                schema: "rm",
                table: "MarginInstrument");

            migrationBuilder.DropColumn(
                name: "MarginPriority",
                schema: "rm",
                table: "MarginInstrument");

            migrationBuilder.DropColumn(
                name: "RepoRate",
                schema: "rm",
                table: "MarginInstrument");

            migrationBuilder.DropColumn(
                name: "SecurityTypeRateId",
                schema: "rm",
                table: "MarginInstrument");

            migrationBuilder.DropColumn(
                name: "ShortLimit",
                schema: "rm",
                table: "MarginInstrument");
        }
    }
}
