﻿using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Infrastructure.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class FixApiGetRiskCategoriesWithBankChecking : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeploySqlFile(@"Procedures\sp_api_get_risk_categories.sql");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
