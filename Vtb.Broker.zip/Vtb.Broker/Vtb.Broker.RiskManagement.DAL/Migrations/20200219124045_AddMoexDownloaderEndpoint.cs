﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.RiskManagement.DAL.Migrations
{
    public partial class AddMoexDownloaderEndpoint : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MoexRiskRateFile",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<DateTime>(nullable: true),
                    Content = table.Column<byte[]>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MoexRiskRateFile", x => x.Id);
                });
            
            
            if(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Production")
                migrationBuilder.Sql($@"insert into rm.Endpoint(Code, Host, Urls) 
                                        select 'MoexRiskDownloader', 'https://zmom:5007', 'https://zmom:5007'
                                        where 'MoexRiskDownloader' not in (select Code from rm.Endpoint)");
            else
                migrationBuilder.Sql($@"insert into rm.Endpoint(Code, Host, Urls) 
                                        select 'MoexRiskDownloader', 'https://k3-olb-app:5013', 'https://k3-olb-app:5013'
                                        where 'MoexRiskDownloader' not in (select Code from rm.Endpoint)");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MoexRiskRateFile",
                schema: "rm");
        }
    }
}
