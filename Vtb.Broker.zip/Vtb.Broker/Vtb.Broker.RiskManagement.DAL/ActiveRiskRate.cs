using System;

namespace Vtb.Broker.RiskManagement.DAL
{
    public class ActiveRiskRate 
    {
        public DateTime OnDate {get;set;}
        public long Id {get;set;}

        public string Isin{get;set;}
    }
}
