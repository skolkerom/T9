using System;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Services;

namespace Vtb.Broker.RiskManagement.DAL
{
    public class RiskManagementUnitOfWorkFactory : UnitOfWorkFactory<RiskManagementUnitOfWork>, IRiskManagementUnitOfWorkFactory
    {
        public RiskManagementUnitOfWorkFactory(IServiceProvider serviceProvider) 
            : base(serviceProvider)
        {
        }
    }
}
