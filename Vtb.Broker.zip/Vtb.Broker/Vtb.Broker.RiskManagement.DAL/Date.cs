using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.RiskManagement.DAL
{
    [Table("Date" , Schema = "rm")]
    public class Date 
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public DateTime Value {get;set;}
    }
}
