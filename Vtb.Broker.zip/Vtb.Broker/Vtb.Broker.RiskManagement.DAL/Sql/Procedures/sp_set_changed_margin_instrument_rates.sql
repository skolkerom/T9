﻿-- Процедура установки флага IsSentToOlb для маржинальных ставок
-- 2020-01-15 / Вишняков Р.Н.

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go

create or alter procedure [rm].[sp_set_changed_margin_instrument_rates]
  @maxId bigint,
  @list_code varchar(128) = null,
  @for_all_lists bit = 0
as 
begin
    --exec [rm].[sp_zfront_set_changed_margin_instrument_rates] @maxId = 20003, @for_all_lists = 1
    
    set nocount on;
    set transaction isolation level read uncommitted;

    declare @list_ids table(Id bigint)
    
    if(@for_all_lists = 0)
        insert into @list_ids
          select Id from rm.MarginInstrumentList 
          where Code = @list_code and IsDeleted = 0
    
    if(@for_all_lists = 1)
        insert into @list_ids
          select Id from rm.MarginInstrumentList
          where IsDeleted = 0
    
    update rm.MarginInstrumentRate
    set IsSentToOlb = 1
    where IsSentToOlb = 0 and ListId in (select Id from @list_ids) and Id <= @maxId

end