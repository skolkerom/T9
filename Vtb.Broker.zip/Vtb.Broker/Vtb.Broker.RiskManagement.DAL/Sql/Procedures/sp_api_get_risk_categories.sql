-- Отбор данных из справочника рисковых категорий для OLB
-- 2020-01-20 / Абакумов

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go
 
create or alter procedure rm.sp_api_get_risk_categories	
as 	
	set transaction isolation level read uncommitted
	set nocount on

  select rc.Id
      , rc.Code
      , rc.Name
      , rc.Rate
      , rc.QuikTemplate
      , rc.MarginInstrumentListId
      , rc.BaseRiskCategoryId
      , mil.Code MarginInstrumentListCode
      , cast((case 
            when exists (
               select c.Code, m.Id, m.Description from rm.RiskCategory c
               join rm.RiskCategoryMarketplace cm on c.Id = cm.RiskCategoryId
               join lgst.v_Markets m on m.Id = cm.MarketplaceId 
               where m.Description <> 'Банк' and rc.Id = c.Id) 
            then 1 
            else 0
         end) 
         as bit) as IsPartnerQuik
      , rc.QuikLeverageId
    from rm.RiskCategory rc
    left join rm.MarginInstrumentList mil on mil.Id = rc.MarginInstrumentListId
  where rc.IsDeleted = 0
	