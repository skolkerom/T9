﻿-- Отбор данных из справочника маржинальных инструментов для OLB
-- 2020-01-20 / Абакумов

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go
 
create or alter procedure rm.sp_api_get_margin_instruments
	@date datetime
as 	
	set transaction isolation level read uncommitted
	set nocount on

	if object_id('tempdb..#market_data') is not null
		drop table #market_data
	
	if object_id('tempdb..#currency_rate') is not null
		drop table #currency_rate

	select i.code 
		, md.close_price
	into #market_data
	from v_instruments i
		left join 		
		(
			select id, max(recid) recid
			from interday md
			where md.value_date < @date and md.close_price != 0
			group by id
		)sq on sq.id = i.id
		left join interday md on md.recid = sq.recid 
			and md.id = sq.id
	where i.place_id = 2
		and i.code in (select Ticker from rm.MarginInstrument)

	select *
	into #currency_rate
	from
	(
		select c.ISO currency
			, case when c.ISO = 'RUR' then 1 else cr.rate end rate
			, row_number() over (partition by cr.currency_code order by cr.day_id desc) rn		
		from dbo.currency_rates cr
			join dbo.currency c on c.currency_code = cr.currency_code
		where cr.day_id <= (select top 1 c.day_id from dbo.calendar c where c.date <= @date order by c.day_id desc)
	)sq
	where sq.rn = 1
	 					 
    select mi.Id
		, mi.Isin
		, mi.ShortName
		, mi.Ticker
		, mi.Type
		, mi.LongLimit
		, mi.MarginPriority
		, mi.RepoRate
		, mi.SecurityTypeRateId
		, mi.ShortLimit
		, cast(mi.ShortLimit / md.close_price * (1 - mi.Discount) as int) as ShortLimitInLots
		, mi.Discount
		, isnull(md.close_price, cr.rate) ClosePrice
		, il.IsMarginal
		, il.IsLong
		, il.IsShort
	from rm.MarginInstrument mi 
		left join #currency_rate cr on cr.currency = mi.Ticker
		left join #market_data md on md.code = mi.Ticker
		left join
		(
			select il.MarginInstrumentId
				, max(case when il.IsMarginal = 1 then 1 else 0 end) IsMarginal
				, max(case when il.IsLong = 1 then 1 else 0 end) IsLong
				, max(case when il.IsShort = 1 then 1 else 0 end) IsShort
			from rm.InstrumentInMarginInstrumentList il
			where @date >= il.StartDate and (@date <= il.EndDate or il.EndDate is null)
			group by il.MarginInstrumentId
		) il on il.MarginInstrumentId = mi.Id
	where mi.IsDeleted = 0	