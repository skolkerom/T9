﻿-- Процедура отбора рыночных котировок по инструментам из rm.MarginInstrument
-- 2020-01-20 / Абакумов

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go

create or alter procedure rm.sp_api_get_margin_instrument_market_data     
as 
begin
    set nocount on;
    set transaction isolation level read uncommitted;

	select mi.Ticker, md.close_price ClosePrice
	from
	(
		select id, max(recid) recid
		from interday md
		where md.close_price != 0
		group by id
	)sq
		join interday md on md.recid = sq.recid and md.id = sq.id
		join v_instruments i on i.id = md.id
		    and i.place_id = 2	
		join rm.MarginInstrument mi on mi.Ticker = i.code
 end