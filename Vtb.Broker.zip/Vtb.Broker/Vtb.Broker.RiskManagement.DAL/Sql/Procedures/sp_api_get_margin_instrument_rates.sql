-- Процедура выбора активных маржинальных ставок
-- 2020-01-17 / Вишняков Р.Н.

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go

create or alter procedure [rm].[sp_api_get_margin_instrument_rates]
  @date date, 
  @list_code varchar(128) = null,
  @for_all_lists bit = 0
as 
begin
    set nocount on;
    set transaction isolation level read uncommitted;

    exec [rm].[sp_get_margin_instrument_rates] 0, @date, @list_code, @for_all_lists
end