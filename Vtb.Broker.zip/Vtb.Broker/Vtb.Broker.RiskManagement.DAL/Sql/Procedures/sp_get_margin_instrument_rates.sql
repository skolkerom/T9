﻿-- Процедура выбора действующих и исторических маржинальных ставок
-- 2020-02-17 / Вишняков Р.Н.

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go

CREATE OR ALTER
 PROCEDURE [rm].[sp_get_margin_instrument_rates] @activeOrHistory BIT = 0, /*  0 - действующие ставки, 1 - исторические ставки */
  @date DATETIME NULL,
  @list_code VARCHAR(128) NULL,
  @for_all_lists BIT = 0
AS
BEGIN
  SET NOCOUNT ON;
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

  BEGIN TRY
    DECLARE @instruments_in_list TABLE (
      Isin NVARCHAR(450) NOT NULL,
      Id BIGINT NOT NULL,
      ListId BIGINT NULL,
      MarginInstrumentId BIGINT NOT NULL,
      StartDate DATETIME NOT NULL,
      EndDate DATETIME NULL,
      IsLong BIT NULL,
      IsShort BIT NULL,
      IsMarginal BIT NULL,
      IsRestricted BIT NULL,
      IsVtbOnly BIT NULL,
      IsDeleted BIT NULL
      )

    IF (@activeOrHistory = 0)
    BEGIN
      INSERT INTO @instruments_in_list
      SELECT i.Isin,
        il.Id,
        il.ListId,
        il.MarginInstrumentId,
        il.StartDate,
        il.EndDate,
        il.IsLong,
        il.IsShort,
        il.IsMarginal,
        il.IsRestricted,
        il.IsVtbOnly,
        il.IsDeleted
      FROM rm.InstrumentInMarginInstrumentList il
      INNER JOIN rm.MarginInstrumentList l ON il.ListId = l.Id
        AND (
          l.Code = @list_code
          OR @for_all_lists = 1
          )
      INNER JOIN rm.MarginInstrument i ON il.MarginInstrumentId = i.Id
      WHERE l.IsDeleted = 0
        AND il.IsDeleted = 0
        AND i.IsDeleted = 0
    END
    ELSE
    BEGIN
      INSERT INTO @instruments_in_list
      SELECT i.Isin,
        il.Id,
        il.ListId,
        il.MarginInstrumentId,
        @date AS StartDate,
        NULL AS EndDate,
        il.IsLong,
        il.IsShort,
        il.IsMarginal,
        il.IsRestricted,
        il.IsVtbOnly,
        il.IsDeleted
      FROM rm.InstrumentInMarginInstrumentListHistory il
      INNER JOIN rm.MarginInstrumentList l ON il.ListId = l.Id
        AND (
          l.Code = @list_code
          OR @for_all_lists = 1
          )
      INNER JOIN rm.MarginInstrument i ON il.MarginInstrumentId = i.Id
    END;

    WITH RiskRates
    AS (
      SELECT il.Isin,
        il.IsLong,
        il.IsShort,
        il.IsMarginal,
        il.IsRestricted,
        il.IsVtbOnly,
        il.ListId AS InstrumentListId,
        r.OnDate,
        r.Id,
        r.Source,
        r.RateDate,
        r.RateLong,
        r.RateShort,
        r.RateLongStandart,
        r.RateShortStandart,
        r.CreatedUser,
        r.CreatedDate,
        r.ModifiedUser,
        r.ModifiedDate,
        r.IsDeleted,
        r.MarginInstrumentListId
      FROM @instruments_in_list il
      LEFT JOIN rm.v_active_risk_rate r ON il.Isin = r.Isin
        AND (
          r.MarginInstrumentListId = il.ListId
          OR r.MarginInstrumentListId IS NULL
          )
        AND r.OnDate = @date
      WHERE il.StartDate <= @date
        AND (
          il.EndDate > @date
          OR il.EndDate IS NULL
          )
      ),
      
    MarginInstrumentRates
    AS (
      SELECT r.Isin,
        r.InstrumentListId,
        CASE 
          WHEN r.IsShort = 1
            THEN max(r.RateShort)
          ELSE 1
          END RateShort,
        CASE 
          WHEN r.IsLong = 1
            THEN max(r.RateLong)
          ELSE 1
          END RateLong,
        CASE 
          WHEN r.IsShort = 1
            THEN max(r.RateShortStandart)
          ELSE 1
          END RateShortStandart,
        CASE 
          WHEN r.IsLong = 1
            THEN max(r.RateLongStandart)
          ELSE 1
          END RateLongStandart,
        r.IsLong,
        r.IsShort,
        r.IsMarginal,
        r.IsRestricted
      FROM (
        SELECT r.InstrumentListId,
          r.Isin,
          r.IsLong,
          r.IsShort,
          r.IsMarginal,
          r.IsRestricted,
          min(r.RateShort) RateShort,
          min(r.RateLong) RateLong,
          min(r.RateShortStandart) RateShortStandart,
          min(r.RateLongStandart) RateLongStandart
        FROM RiskRates r
        GROUP BY (
            CASE 
              WHEN r.Source = 2
                THEN 'VTB'
              ELSE 'NonVTB'
              END
            ),
          r.Isin,
          r.IsVtbOnly,
          r.InstrumentListId,
          r.IsLong,
          r.IsShort,
          r.IsMarginal,
          r.IsRestricted
        ) r
      GROUP BY r.Isin,
        r.InstrumentListId,
        r.IsLong,
        r.IsShort,
        r.IsMarginal,
        r.IsRestricted
      ) 
      
    SELECT 
      il.Id,
      il.Id as InstrumentInMarginInstrumentListId,
      il.IsVtbOnly,
      il.IsExchangeRepo,
      il.IsDeleted,
      il.CreatedDate,
      il.CreatedUser,
      il.ModifiedDate,
      il.ModifiedUser,
      i.Ticker,
      i.ShortName,
      r.Isin,
      r.InstrumentListId as ListId,
      r.RateShort,
      r.RateLong,
      r.RateShortStandart,
      r.RateLongStandart,
      r.IsLong,
      r.IsShort,
      r.IsMarginal,
      r.IsRestricted,
      @date AS [RateDate],
      @date AS [RateDateTime],
      0x0 as [RowVersion],
      l.Code AS ListCode,
      cast (0 as bit) as IsSentToOlb
    FROM MarginInstrumentRates r
    LEFT JOIN rm.MarginInstrumentList l ON l.Id = r.InstrumentListId
    LEFT JOIN rm.MarginInstrument i ON i.Isin = r.Isin
      AND i.IsDeleted = 0
    LEFT JOIN rm.InstrumentInMarginInstrumentList il ON i.Id = il.MarginInstrumentId
      AND il.ListId = r.InstrumentListId
  END TRY

  BEGIN CATCH
    DECLARE @msg NVARCHAR(2048) = error_message()

    RAISERROR (
        @msg,
        16,
        1
        )

    RETURN - 1
  END CATCH
END
