DECLARE @context_info VARBINARY(128) = CAST('ZF-2354' AS VARBINARY(128))
SET CONTEXT_INFO @context_info
GO

IF EXISTS
(
  SELECT *
  FROM sys.procedures p
  WHERE p.object_id = OBJECT_ID(N'clr.sp_http_request')
)
DROP PROCEDURE clr.sp_http_request;
GO

-- ==============================================================
-- Author: Володин А.Е.
-- Create date: 09.12.2019
-- Description: ZF-2354, Http запрос
-- Change history:
-- ==============================================================
CREATE PROCEDURE clr.sp_http_request
  @url        NVARCHAR(4000),
  @method     NVARCHAR(4000),
  @header     NVARCHAR(4000) OUTPUT,
  @timeout    INT,
  @request    NVARCHAR(4000),
  @response   NVARCHAR(MAX) OUTPUT
AS
EXTERNAL NAME [Vtb.SqlClr.Net].[Web].[HttpRequest];
GO

IF EXISTS
(
  SELECT *
  FROM sys.database_principals
  WHERE name = 'ViewDef'
)
EXEC('GRANT VIEW DEFINITION ON clr.sp_http_request TO ViewDef');
GO

-- ==============================================================
-- Author: Володин А.Е.
-- Create date: 09.12.2019
-- Description: ZF-2354, Http запрос
-- Change history:
-- ==============================================================
CREATE OR ALTER PROCEDURE dbo.sp_http_request
  @url        NVARCHAR(4000),
  @method     NVARCHAR(4000)  = NULL,
  @header     NVARCHAR(4000)  = NULL OUTPUT,
  @timeout    INT             = -1,
  @request    NVARCHAR(4000)  = NULL,
  @response   NVARCHAR(MAX)   = NULL OUTPUT
AS
SET NOCOUNT ON
BEGIN TRY

  DECLARE @statusCode INT

  EXEC @statusCode = clr.sp_http_request
    @url        = @url,
    @method     = @method,
    @header     = @header OUTPUT,
    @timeout    = @timeout,
    @request    = @request,
    @response   = @response OUTPUT

  IF @statusCode <> 200
  BEGIN
    RAISERROR('Ошибка отправки SMS (%d): %s', 16, 1, @statusCode, @response)
  END

END TRY
BEGIN CATCH
  THROW;
END CATCH
GO

IF EXISTS
(
  SELECT *
  FROM sys.database_principals
  WHERE name = 'ViewDef'
)
EXEC('GRANT VIEW DEFINITION ON dbo.sp_http_request TO ViewDef');
GO

IF EXISTS
(
  SELECT *
  FROM sys.database_principals
  WHERE name = 'zfront_clients'
)
EXEC('GRANT EXECUTE ON dbo.sp_http_request TO [zfront_clients]')
GO

IF EXISTS
(
  SELECT *
  FROM sys.database_principals
  WHERE name = 'zfront_clients'
)
EXEC('GRANT EXECUTE ON dbo.sp_soap_ws_request TO [zfront_clients]')
GO

IF EXISTS
(
  SELECT *
  FROM sys.database_principals
  WHERE name = 'zfront_clients'
)
EXEC('GRANT EXECUTE ON dbo.sp_soap_basic_request TO [zfront_clients]')
GO
