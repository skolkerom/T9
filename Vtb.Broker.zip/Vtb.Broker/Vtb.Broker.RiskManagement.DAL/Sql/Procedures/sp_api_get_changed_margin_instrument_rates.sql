create or alter procedure [rm].[sp_api_get_changed_margin_instrument_rates]
      @date datetime,
      @list_code varchar(128) = null,
      @for_all_lists bit = 0
    as 
begin
        --exec [rm].[sp_zfront_get_changed_margin_instrument_rates] @date = '2020-01-17 00:00:00', @for_all_lists = 1
        --exec [rm].[sp_zfront_get_changed_margin_instrument_rates] @date = '2020-01-18 23:28:33', @list_code = 'SPB_MARGIN_TEMP', @for_all_lists = 0
        
        set nocount on;
        set transaction isolation level read uncommitted;

        set @date = (select convert(date, dateadd(day, 1, @date)))

        declare @list_ids table(Id bigint)

        if(@for_all_lists = 0)
            insert into @list_ids
                select Id from rm.MarginInstrumentList 
                where Code = @list_code and IsDeleted = 0

        if(@for_all_lists = 1)
            insert into @list_ids
                select Id from rm.MarginInstrumentList
                where IsDeleted = 0
      
        select 
            r.Id
            , r.Isin
            , i.Ticker
            , i.ShortName
            , r.RateLong
            , r.RateShort
            , r.RateLongStandart
            , r.RateShortStandart
            , r.IsLong
            , r.IsShort
            , r.IsMarginal
            , r.IsRestricted
            , l.Code as ListCode
            , r.RateDate
            , r.IsExchangeRepo              
        from 
            (select r.Isin, max(r.RateDateTime) as RateDateTime
            from rm.MarginInstrumentRate r
            where r.RateDate < @date
            group by r.Isin) x
                        
            join rm.MarginInstrumentRate r on r.Isin = x.Isin and r.RateDateTime = x.RateDateTime
            join rm.MarginInstrument i on i.Isin = r.Isin and i.IsDeleted = 0
            join rm.MarginInstrumentList l on l.Id = r.ListId
            where r.IsSentToOlb = 0 and l.Id  in (select Id from @list_ids)

end