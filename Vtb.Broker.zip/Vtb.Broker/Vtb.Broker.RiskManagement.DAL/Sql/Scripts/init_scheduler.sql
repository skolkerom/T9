create table rm.JobSchedule
	(
		Id bigint primary key identity,
		Code varchar(255) not null,
		Description varchar(255) not null,
		Cron varchar(255) not null,
        IsDeleted bit not null,
		RowVersion timestamp,
		ApplicationName varchar(255) not null
	)

create table rm.JobExecution
	(
		Id bigint primary key identity,
		Code varchar(255) not null,		
        StartDate datetime not null,
        EndDate datetime null,
        [User] varchar(255) null,
        ErrorMessage varchar(max) null
	)
	
create table rm.JobExecutionRequest
(
    Id bigint primary key identity,
    JobScheduleId bigint not null references rm.JobSchedule(Id),
    [User] varchar(255) not null,
    CreatedDateTime datetime not null,
    IsProcessed bit not null   
)

insert into rm.JobSchedule(Code, Description, Cron, IsDeleted, ApplicationName )
select 'RiskRateFromOlbUploaderJob', 'Загрузка ставок из БД OLB', '0 59 16 * * ?', 0, 'RiskManagement'

insert into rm.JobSchedule(Code, Description, Cron, IsDeleted, ApplicationName )
select 'RiskRateFromMoexUploaderJob', 'Загрузка ставок с сайта MOEX', '0 59 16 * * ?', 0, 'RiskManagement'

insert into rm.JobSchedule(Code, Description, Cron, IsDeleted, ApplicationName )
select 'RiskRateFromMfbUploaderJob', 'Загрузка ставок MFB из электронной почты', '0 59 16 * * ?', 0, 'RiskManagement'

insert into rm.JobSchedule(Code, Description, Cron, IsDeleted, ApplicationName )
select 'NewMarginRatesNotifyJob', 'Обновление маржинальных ставок в OLB', '0 59 16 * * ?', 0, 'RiskManagement'