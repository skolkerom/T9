﻿if not exists (select * from sys.tables where name='Endpoint' and schema_id = schema_id('rm'))
    create table rm.Endpoint(Id bigint primary key identity, Code varchar(1024), Host varchar(1024))
go 

if(not exists(select * from rm.Endpoint where Code='OptimalRepoCalculator'))
    insert rm.Endpoint(Code, Host)
    select 'OptimalRepoCalculator', '<host>:<port>'
go