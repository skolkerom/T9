create table rm.[User]
(
    Id bigint primary key identity,
    Login varchar(100) not null,
    PasswordHash varbinary(512) not null		
)

insert into rm.[User](Login, PasswordHash)
select 'zfront_optimal_repo', HASHBYTES('SHA2_512', N'password')