insert into [rm].[Marketplace]([Code]
	,[Name]
    ,[CreatedUser]
    ,[CreatedDate]
    ,[ModifiedUser]
    ,[ModifiedDate]    
    ,[IsDeleted])
select 'VTB',	'Банк',	'system', getdate(), 'system', getdate(), 0 union all
select 'POCHTA_BANK',	'Почта Банк',	'system', getdate(), 'system', getdate(), 0 union all
select 'XYA',	'Яндекс',	'system', getdate(), 'system', getdate(), 0 union all
select 'RBC',	'РБК',	'system', getdate(), 'system', getdate(), 0