
insert rm.BaseRiskCategory(Name)
select 'КСУР' union all
select 'КПУР' union all
select 'КОУР'
