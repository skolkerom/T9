select 'drop table rm.' + name,* from sys.objects where schema_id = schema_id('rm') and type = 'U'

select 'alter table rm.' + t.name + ' drop constraint ' + f.name
from sys.objects f
	join sys.objects t on t.object_id = f.parent_object_id
where f.schema_id = schema_id('rm') and f.type = 'F'
