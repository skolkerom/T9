﻿set identity_insert [rm].[MarginInstrumentList] on
go

INSERT INTO [rm].[MarginInstrumentList]
           ([Id]
		   ,[Name]
           ,[Code]
           ,[CreatedDate]
           ,[CreatedUser]
		   ,[ModifiedDate]
           ,[ModifiedUser]
           ,[IsDeleted])

select 13,	'СПб-Залоговые',	'SPB_MARGIN_TEMP',	getdate(), 'system', getdate(), 'system' ,	0
go

set identity_insert [rm].[MarginInstrumentList] off
go