drop table rm.ProcessedFile;
drop table rm.FileDetector;
