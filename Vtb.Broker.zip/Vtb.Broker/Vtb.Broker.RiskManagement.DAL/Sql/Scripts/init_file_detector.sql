﻿create table [rm].[FileDetector](
	[Id] [bigint] identity(1,1) not null primary key,
	[Type] [nvarchar](max) null,
	[Path] [nvarchar](max) null,
	[Mask] [nvarchar](max) null,
	[Enabled] [bit] not null,
	[Description] [nvarchar](max) null,
	[ApplicationName] [nvarchar](255) null);	 

create table [rm].[ProcessedFile](
	[Id] [bigint] identity(1,1) not null primary key,
	[FilePath] [nvarchar](max) null,
	[FileDetectorId] [bigint] not null references rm.FileDetector(Id),
	[FileName] [nvarchar](max) null,
	[Timestamp] [datetime2](7) not null,
	[Error] [nvarchar](max) NULL);

insert into rm.FileDetector(Type, Path, Mask, Enabled, Description, ApplicationName)
select 'NewMfbRiskFile',	'C:\Vtb\RiskRates\Mfb',	'*.*',	1,	'MFB',	'RiskManagement' union all
select 'NewMoexRiskFile',	'C:\Vtb\RiskRates\Moex',	'*.*',	1,	'NCC-IND',	'RiskManagement'
