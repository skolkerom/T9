insert into rm.Date
select top 20000 dateadd(dd, row_number() over(order by t1.name desc), '20100101')
from sys.objects t1
    cross join sys.objects t2