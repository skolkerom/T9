﻿set identity_insert [rm].[InstrumentInMarginInstrumentList] on
go

INSERT INTO [rm].[InstrumentInMarginInstrumentList]
           ([Id]
		   ,[ListId]
           ,[MarginInstrumentId]
           ,[IsVtbOnly]
           ,[TransferRate]
           ,[TransferPlace]
           ,[IsMarginal]
           ,[IsRestricted]
           ,[IsLong]
           ,[IsShort]
           ,[StartDate]
           ,[EndDate]
           ,[CreatedUser]
           ,[CreatedDate]
           ,[ModifiedUser]
           ,[ModifiedDate]
           ,[IsDeleted])

select 
'69', '13', '30', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'70', '13', '31', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'71', '13', '28', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'72', '13', '29', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'73', '13', '32', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'74', '13', '33', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'76', '13', '35', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'77', '13', '36', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'79', '13', '38', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'80', '13', '39', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'84', '13', '41', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'91', '13', '66', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'92', '13', '65', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'93', '13', '64', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'94', '13', '63', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'95', '13', '62', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'96', '13', '61', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'97', '13', '60', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'98', '13', '59', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'99', '13', '58', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'100', '13', '57', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'101', '13', '56', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'102', '13', '55', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'103', '13', '54', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'104', '13', '53', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'105', '13', '52', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'106', '13', '51', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'107', '13', '50', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'108', '13', '49', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'109', '13', '48', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0' union select 
'110', '13', '47', '0', '1', NULL, '1', '0', '1', '0', getdate(), NULL, 'system', getdate(), 'system', getdate(), '0'


set identity_insert [rm].[InstrumentInMarginInstrumentList] off
go


