set identity_insert [rm].MarginInstrument  on

INSERT INTO [rm].[MarginInstrument]
           ([Id]
		   ,[Isin]
           ,[ShortName]
           ,[Ticker]
           ,[Type]
           ,[CreatedUser]
           ,[CreatedDate]
           ,[ModifiedUser]
           ,[ModifiedDate]
           ,[RowVersion]
           ,[IsDeleted])

select '8', 'RU0009029540', 'Сбербанк', 'SBER', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '9', 'XS0088543193', 'RUS-28', 'XS0088543193', 'Облигация', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '20', 'USD', 'USD', 'USD', 'Валюта', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '21', 'EUR', 'EUR', 'EUR', 'Валюта', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '22', 'RU0007661625', 'ГАЗПРОМ ао', 'GAZP', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '23', 'RU000A0JXQF2', 'ОФЗ 26222', 'SU26222RMFS8', 'Облигация', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '27', 'US5949181045', 'Microsoft Corporation', 'MSFT_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '28', 'US0378331005', 'Apple Inc.', 'AAPL_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '29', 'US0231351067', 'Amazon.com, Inc.', 'AMZN_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '30', 'US02079K3059', 'Alphabet Inc. Class A', 'GOOGL_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '31', 'US02079K1079', 'Alphabet Inc. Class C', 'GOOG_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '32', 'US0846707026', 'Berkshire Hathaway Inc.', 'BRK B_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '33', 'US30303M1027', 'Facebook, Inc.', 'FB_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '34', 'US01609W1027', 'Alibaba Group Holding Limited', 'BABA_SPB', 'ADR', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '35', 'US92826C8394', 'Visa Inc.', 'V_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '36', 'US46625H1005', 'JPMorgan Chase & Co.', 'JPM_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '37', 'US71646E1001', 'PetroChina Company Limited', 'PTR_SPB', 'ADR', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '38', 'US67066G1040', 'NVIDIA Corporation', 'NVDA_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '39', 'US4781601046', 'Johnson & Johnson', 'JNJ_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '40', 'US3696041033', 'General Electric Company', 'GE_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '41', 'US0605051046', 'Bank of America Corporation', 'BAC_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '42', 'US88160R1014', 'Tesla, Inc.', 'TSLA_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '43', 'RU0007252813', 'АЛРОСА ао', 'ALRS', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '45', 'US1912161007', 'THE COCA-COLA COMPANY', 'KO_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '46', 'US00724F1012', 'Adobe Inc.', 'ADBE_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '47', 'US0970231058', 'THE BOEING COMPANY', 'BA_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '48', 'US1729674242', 'Citigroup Inc.', 'C_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '49', 'US17275R1023', 'Cisco Systems, Inc.', 'CSCO_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '50', 'US1667641005', 'Chevron Corporation', 'CVX_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '51', 'US2546871060', 'The Walt Disney Company', 'DIS_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '52', 'US4370761029', 'The Home Depot, Inc.', 'HD_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '53', 'US4581401001', 'Intel Corporation', 'INTC_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '54', 'US57636Q1040', 'Mastercard Incorporated class A', 'MA_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '55', 'US58933Y1055', 'Merck & Co., Inc.', 'MRK_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '56', 'US64110L1061', 'Netflix, Inc.', 'NFLX_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '57', 'US68389X1054', 'Oracle Corporation', 'ORCL_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '58', 'US7134481081', 'PepsiCo, Inc.', 'PEP_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '59', 'US7170811035', 'Pfizer Inc.', 'PFE_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '60', 'US7475251036', 'QUALCOMM Incorporated', 'QCOM_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '61', 'US00206R1023', 'AT&T INC.', 'T_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '62', 'US91324P1021', 'UnitedHealth Group Incorporated', 'UNH_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '63', 'US92343V1044', 'Verizon Communications Inc.', 'VZ_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '64', 'US9497461015', 'Wells Fargo & Company', 'WFC_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '65', 'US9311421039', 'Walmart Inc.', 'WMT_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0' 
 union select '66', 'US30231G1022', 'Exxon Mobil Corporation', 'XOM_SPB', 'Ао', 'system', getdate(), 'system', getdate(), NULL, '0'

GO

set identity_insert [rm].MarginInstrument  off
