drop table rm.JobExecutionRequest
drop table rm.JobExecution
drop table rm.JobSchedule
