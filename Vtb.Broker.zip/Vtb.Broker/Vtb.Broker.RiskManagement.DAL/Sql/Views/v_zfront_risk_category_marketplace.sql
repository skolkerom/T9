if object_id('rm.v_zfront_risk_category_marketplace') is null
    exec('create view rm.v_zfront_risk_category_marketplace as select 1 as c')
go 
alter view rm.v_zfront_risk_category_marketplace
as 
    select Id
        , MarketplaceId
        , RiskCategoryId 
    from rm.RiskCategoryMarketplace