if object_id('rm.v_zfront_user') is null
    exec('create view rm.v_zfront_user as select 1 as c')
go 
alter view rm.v_zfront_user
as 
    select [login] as [Login]
        , [name] as [Name]
    from dbo.users