if object_id('rm.v_zfront_security_type_rate') is null
    exec('create view rm.v_zfront_security_type_rate as select 1 as c')
go 
alter view rm.v_zfront_security_type_rate
as 
    select Id
        , Name
        , DateCreate
        , UserCreate
        , ElTrfName
    from rate.SecurityTypeRate