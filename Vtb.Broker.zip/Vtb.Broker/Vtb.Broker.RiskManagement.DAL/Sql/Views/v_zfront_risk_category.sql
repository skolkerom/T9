if object_id('rm.v_zfront_risk_category') is null
    exec('create view rm.v_zfront_risk_category as select 1 as c')
go 
alter view rm.v_zfront_risk_category
as 
    select Id
        ,Name
        ,Rate 
        ,BaseRiskCategoryId
        ,CreatedDate
        ,CreatedUser
        ,IsDeleted
        ,ModifiedDate
        ,ModifiedUser
        ,RowVersion
        ,MarginInstrumentListId
        ,IndividualInvestmentAccount
        ,QualifiedInvestor
        ,FormingPrinciple
        ,Code 
    from rm.RiskCategory