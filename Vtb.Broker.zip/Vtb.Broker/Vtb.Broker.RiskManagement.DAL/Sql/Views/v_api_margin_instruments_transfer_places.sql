﻿-- Отбор данных из справочника маржинальных инструментов для OLB
-- 2020-01-20 / Абакумов

declare @context_info varbinary(128) = CAST('BR-17440' AS VARBINARY(128))
set context_info @context_info
go
 
create or alter view rm.v_api_margin_instruments_transfer_places
as	
	select mi.Id MarginInstrumentId
		, b.Code as TransferPlaceCode		
	from rm.MarginInstrument mi 		    
		 join rm.MarginInstrumentTransferPlace tp on tp.MarginInstrumentId = mi.Id
		 join rm.Board b on b.Id = tp.TransferPlaceId		    
	where mi.IsDeleted = 0	