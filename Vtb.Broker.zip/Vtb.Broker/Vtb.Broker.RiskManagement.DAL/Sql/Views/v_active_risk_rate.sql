if object_id('rm.v_active_risk_rate') is null
    exec('create view rm.v_active_risk_rate as select 1 as c')
go 
alter view rm.v_active_risk_rate
as 
    select sq.OnDate,        
        mir.*
    from rm.RiskRate mir
        join
        (
            select d.Value OnDate
				, mir.Isin
                , mir.MarginInstrumentListId
				, max(mir.RateDate) RateDate
            from rm.Date d 
                join rm.RiskRate mir on mir.RateDate <= d.Value
					and mir.IsDeleted = 0
            group by d.Value
                , mir.Isin
                , mir.MarginInstrumentListId
                , mir.Source
        )sq on mir.RateDate = sq.RateDate
			and mir.Isin = sq.Isin
            and isnull(mir.MarginInstrumentListId,-1) = isnull(sq.MarginInstrumentListId, -1)
	where mir.IsDeleted = 0