if object_id('rm.v_zfront_market_data') is null
    exec('create view rm.v_zfront_market_data as select 1 as c')
go 
alter view rm.v_zfront_market_data
as 
    select row_number() over (partition by md.id order by md.value_date desc) RecordOrder
        , md.id as InstrumentId
        , i.code as InstrumentCode  
        , md.value_date as ValueDate
        , md.close_price as ClosePrice
        , md.avg_price as AvgPrice
        , md.open_price as OpenPrice
        , md.last_price as LastPrice
        , md.max_price as MaxPrice
        , md.min_price as MinPrice
    from interday md  
        join v_instruments i on i.id = md.id