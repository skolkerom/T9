create or alter function [rm].[fn_get_history_risk_rates](@date datetime, @list_id bigint)
returns @result table (Isin varchar(max) not null,
		InstrumentListId bigint not null,
        RateShort decimal(19,8) null,
        RateLong decimal(19,8) null,
        RateShortStandart decimal(19,8) null,
        RateLongStandart decimal(19,8) null,
		IsLong bit,
		IsShort bit,
		IsMarginal bit,
		IsRestricted bit,
		RateDate datetime)
begin
	declare @t RiskRateInstrumentTable

	insert into @t
	select	  
				  r.OnDate
				, r.Id
				, r.Source
				, i.Isin
				, r.RateDate
				, r.RateLong
				, r.RateShort
				, r.RateLongStandart
				, r.RateShortStandart
				, r.CreatedUser
				, r.CreatedDate
				, r.ModifiedUser
				, r.ModifiedDate
				, r.IsDeleted
				, r.MarginInstrumentListId
				, il.IsLong
				, il.IsShort
				, il.IsMarginal
				, il.IsRestricted
				, il.IsVtbOnly
				, il.Id as InstrumentListId
		from rm.InstrumentInMarginInstrumentListHistory il
			left join rm.MarginInstrument i  on il.MarginInstrumentId = i.Id
			left join rm.v_active_risk_rate r on i.Isin = r.Isin and (r.MarginInstrumentListId = il.ListId or r.MarginInstrumentListId is null) and r.OnDate = @date
		where il.EntityId = @list_id
	
	insert into @result 
	select *, @date from [rm].[fn_get_margin_instrument_rates](@t)

	return
end