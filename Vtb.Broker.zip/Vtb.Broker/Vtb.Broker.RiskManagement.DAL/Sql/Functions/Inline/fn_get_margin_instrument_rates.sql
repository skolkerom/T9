create or alter function [rm].[fn_get_margin_instrument_rates](@rates RiskRateInstrumentTable readonly)
returns table
as
return 

select r.Isin, r.InstrumentListId, 
		case when r.IsShort = 1 then max(r.RateShort) else 1 end RateShort, 
		case when r.IsLong = 1 then max(r.RateLong) else 1 end RateLong,
		case when r.IsShort = 1 then max(r.RateShortStandart) else 1 end RateShortStandart,
		case when r.IsLong = 1 then max(r.RateLongStandart) else 1 end RateLongStandart,
		r.IsLong,
		r.IsShort,
		r.IsMarginal,
		r.IsRestricted
	from
	(
		select 
			r.InstrumentListId,
			r.Isin, 
			r.IsLong,
			r.IsShort,
			r.IsMarginal,
			r.IsRestricted,
			min(r.RateShort) RateShort, 
			min(r.RateLong) RateLong,
			min(r.RateShortStandart) RateShortStandart,
			min(r.RateLongStandart) RateLongStandart
		from @rates r
		where r.Source = 2 --VTB own rates
		group by r.Isin, r.InstrumentListId, r.IsLong, r.IsShort, r.IsMarginal, r.IsRestricted
		
		union all
		
		select
			r.InstrumentListId,
			r.Isin, 
			r.IsLong,
			r.IsShort,
			r.IsMarginal,
			r.IsRestricted,
			min(r.RateShort) RateShort, 
			min(r.RateLong) RateLong,
			min(r.RateShortStandart) RateShortStandart,
			min(r.RateLongStandart) RateLongStandart
		from @rates r
		where r.IsVtbOnly != 1 and (r.Source != 2 or r.Source is null) --not VTB rates
		group by r.Isin, r.IsVtbOnly, r.InstrumentListId, r.IsLong, r.IsShort, r.IsMarginal, r.IsRestricted
	)r
		group by r.Isin, r.InstrumentListId, r.IsLong, r.IsShort, r.IsMarginal, r.IsRestricted