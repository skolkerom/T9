if object_id('rm.InstrumentInMarginInstrumentList_Period_Check_IUD') is null
    exec('create trigger rm.InstrumentInMarginInstrumentList_Period_Check_IUD on rm.InstrumentInMarginInstrumentList after insert as print ''x'' ')
go
alter trigger rm.InstrumentInMarginInstrumentList_Period_Check_IUD
	on rm.InstrumentInMarginInstrumentList
after insert, update, delete
as
   if exists
   (
		select *
		from
		(
			select i.MarginInstrumentId, i.ListId 
			from inserted i 
			union 
			select d.MarginInstrumentId, d.ListId
			from deleted d
		)i
			join rm.InstrumentInMarginInstrumentList instr on instr.ListId = i.ListId
				and instr.MarginInstrumentId = i.MarginInstrumentId
				and instr.IsDeleted = 0
			join rm.InstrumentInMarginInstrumentList instr2 on instr2.ListId = instr.ListId
				and instr2.MarginInstrumentId = instr.MarginInstrumentId
				and instr2.StartDate >= instr.StartDate 
				and (instr2.StartDate < instr.EndDate or instr.EndDate is null)
				and instr2.IsDeleted = 0
                and instr.Id != instr2.Id
	)
		raiserror('Period intersection detected', 16, 1);

GO  