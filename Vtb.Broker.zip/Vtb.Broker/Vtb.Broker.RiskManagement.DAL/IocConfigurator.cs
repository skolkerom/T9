﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Infrastructure;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Infrastructure.FileDetector.DAL.Repositories;
using Vtb.Broker.Interfaces.FileDetector;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.DAL.Migrations;
using Vtb.Broker.RiskManagement.DAL.Repositories.Commands;
using Vtb.Broker.RiskManagement.DAL.Repositories.Queries;
using Vtb.Broker.RiskManagement.Domain.Interfaces;
using Vtb.Broker.RiskManagement.Domain.Interfaces.MoexRiskRateDownloader;
using Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Services;

namespace Vtb.Broker.RiskManagement.DAL
{
    public static class IocConfigurator
    {
        public static void AddRiskManagementRepositories(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IRiskManagementUnitOfWorkFactory, RiskManagementUnitOfWorkFactory>();
            services.AddTransient<RiskManagementUnitOfWork>();
            services.AddScoped<IRiskRateCommandRepository, RiskRateCommandRepository>();
            services.AddScoped<IRiskCategoryCommandRepository, RiskCategoryCommandRepository>();
            services.AddScoped<IMarginInstrumentCommandRepository, MarginInstrumentCommandRepository>();
            services.AddScoped<IMarginInstrumentListCommandRepository, MarginInstrumentListCommandRepository>();
            services.AddScoped<IInstrumentInMarginInstrumentListCommandRepository, InstrumentInMarginInstrumentListCommandRepository>();
            services.AddScoped<IOvernightDistributionCommandRepository, OvernightDistributionCommandRepository>();
            services.AddScoped<IMarginInstrumentRateCommandRepository, MarginInstrumentRateCommandRepository>();

            services.AddScoped<IOlbQueryRepository, OlbQueryRepository>();
            services.AddScoped<IOlbCommandRepository, OlbCommandRepository>();
            services.AddScoped<IOlbMarketRiskParameterQueryRepository, OlbMarketRiskParameterQueryRepository>();


            services.AddScoped<IZFrontQueryRepository, ZFrontInstrumentQueryRepository>();
            services.AddScoped<IBoardQueryRepository, BoardQueryRepository>();
            services.AddScoped<IFileDetectorQueryRepository, FileDetectorQueryRepository>();
            services.AddScoped<IBaseRiskCategoryQueryRepository, BaseRiskCategoryQueryRepository>();
            services.AddScoped<IMarketplaceQueryRepository, MarketplaceQueryRepository>();
            services.AddScoped<IRiskCategoryQueryRepository, RiskCategoryQueryRepository>();
            services.AddScoped<IMarginInstrumentRateQueryRepository, MarginInstrumentRateQueryRepository>();
            services.AddScoped<IInstrumentInMarginInstrumentListQueryRepository, InstrumentInMarginInstrumentListQueryRepository>();
            services.AddScoped<IMarginInstrumentQueryRepository, MarginInstrumentQueryRepository>();
            services.AddScoped<IRiskRateQueryRepository, RiskRateQueryRepository>();
            services.AddScoped<IMarginInstrumentListQueryRepository, MarginInstrumentListQueryRepository>();
            services.AddScoped<IHistoryQueryRepository, HistoryQueryRepository>();
            services.AddScoped<IUserQueryRepository, ZFrontUserQueryRepository>();
            services.AddScoped<IOvernightDistributionOperationQueryRepository, OvernightDistributionOperationQueryRepository>();
            services.AddScoped<IOvernightDistributionPositionQueryRepository, OvernightDistributionPositionQueryRepository>();
            services.AddScoped<IOvernightDistributionQueryRepository, OvernightDistributionQueryRepository>();
            services.AddScoped<IRepoOnlineQueryRepository, RepoOnlineQueryRepository>();
            services.AddScoped<IAlertQueryRepository, AlertQueryRepository>();
            services.AddScoped<IAlertCommandRepository, AlertCommandRepository>();
            services.AddScoped<ISecurityTypeRateQueryRepository, SecurityTypeRateQueryRepository>();
            services.AddScoped<IMoexRiskRateCommandRepository, MoexRiskRateCommandRepository>();
            services.AddScoped<IMoexRiskRateQueryRepository, MoexRiskRateQueryRepository>(); 
            services.AddScoped<ICurrencyQueryRepository, CurrencyQueryRepository>();
            
            var defaultConnectionString = configuration.GetConnectionString(ConnectionStringsNames.DefaultConnection);
            var olbConnectionString = configuration.GetConnectionString(ConnectionStringsNames.OlbConnection);

            services.AddSingleton<IContextFactory<RiskManagementContext>>(container =>
                new ContextFactory<RiskManagementContext>(() =>
                        new RiskManagementContext(defaultConnectionString),
                    container.GetRequiredService<ILoggerFactory>()));
            
            services.AddSingleton<IContextFactory<RiskManagementReadOnlyContext>>(container => new ContextFactory<RiskManagementReadOnlyContext>(
                () =>new RiskManagementReadOnlyContext(defaultConnectionString)
                , container.GetRequiredService<ILoggerFactory>()));

            services.AddSingleton<IContextFactory<OlbReadOnlyContext>>(container =>
                new ContextFactory<OlbReadOnlyContext>(() =>
                        new OlbReadOnlyContext(olbConnectionString)
                    , container.GetRequiredService<ILoggerFactory>()));
            
            services.AddTransient<IRiskRateMigrator, RiskRateMigrator>();
            services.AddScoped(x => x.GetRequiredService<IContextFactory<RiskManagementContext>>().Create());
        }
    }
}
