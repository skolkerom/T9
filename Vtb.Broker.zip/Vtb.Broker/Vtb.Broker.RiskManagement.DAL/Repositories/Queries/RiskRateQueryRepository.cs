using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class RiskRateQueryRepository : IRiskRateQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public RiskRateQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public async Task<RiskRate> GetRiskRate(long id)
        {
            await using var context = _contextFactory.Create();

            return await context.RiskRates.TagWith(nameof(GetRiskRate)).ApplyIncludes().FirstAsync(x => x.Id == id);
        }

        public async Task<RiskRate[]> GetActiveRiskRates(string isin, long listId, DateTime rateDate)
        {
            await using var context = _contextFactory.Create();

            var result = await (from r in context.GetActiveRiskRatesQuery(rateDate)
                        .TagWith(nameof(GetActiveRiskRates))
                                where r.Isin == isin && (r.MarginInstrumentListId == listId || r.MarginInstrumentListId == null)
                                select r)
                                .ApplyIncludes()
                                .ToArrayAsync();

            return result;
        }

        public async Task<RiskRate[]> GetActiveRiskRates((string isin, DateTime rateDate)[] isinsAndRates)
        {
            await using var context = _contextFactory.Create();

            await context.Database.OpenConnectionAsync();

            var isinDates = isinsAndRates.Select(x => new TempTableIsinDate
            {
                Isin = x.isin,
                Date = x.rateDate.Date
            }).ToArray();

            var isinDatesTable = await context.CreateTempTableAndInsertRecords(isinDates);

            var result = await (from rr in context.ActiveRiskRates
                                join t in isinDatesTable.Query on new { rr.Isin, Date = rr.OnDate } equals new { t.Isin, t.Date }
                                join r in context.RiskRates on rr.Id equals r.Id
                                select r)
                                .ApplyIncludes()
                                .ToArrayAsync();

            return result.ToArray();
        }

        public async Task<RiskRate[]> GetRiskRates((string isin, DateTime rateDate)[] datesAndIsins)
        {
            await using var context = _contextFactory.Create();

            var result = new List<RiskRate>();

            foreach (var (isin, rateDate) in datesAndIsins)
            {
                result.AddRange(await context.RiskRates.TagWith(nameof(GetRiskRate))
                    .Where(x => x.RateDate == rateDate &&
                        x.Isin == isin &&
                        !x.IsDeleted)
                    .ApplyIncludes()
                    .ToArrayAsync());
            }

            return result.ToArray();
        }

        public async Task<RiskRate[]> GetRiskRates(string isin)
        {
            await using var context = _contextFactory.Create();

            return await context.RiskRates.TagWith(nameof(GetRiskRates))
                    .Where(x => x.Isin == isin)
                    .ToArrayAsync();
        }

        public async Task<RiskRate[]> GetRiskRatesWithIdsAsync(RiskRate[] rates)
        {
            await using var context = _contextFactory.Create();

            var result = await context.BulkReadAsync(rates, new[]
            {
                nameof(RiskRate.Isin),
                nameof(RiskRate.Source),
                nameof(RiskRate.RateDate),
                nameof(RiskRate.MarginInstrumentListId),
                nameof(RiskRate.IsDeleted),
            }, nameof(GetRiskRatesWithIdsAsync));

            return result;
        }
    }
}
