using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class InstrumentInMarginInstrumentListQueryRepository : IInstrumentInMarginInstrumentListQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public InstrumentInMarginInstrumentListQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public async Task<InstrumentInMarginInstrumentList> GetInstrumentInMarginInstrumentListAsync(long id)
        {
            await using var context = _contextFactory.Create();

            return await context.InstrumentsInMarginInstrumentList.TagWith(nameof(GetInstrumentInMarginInstrumentListAsync))
                .Include(x => x.MarginInstrument)
                .Include(x => x.List)
                .Include(i => i.TransferPlaces)
                .ThenInclude(p => p.TransferPlace)
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<InstrumentInMarginInstrumentListHistory[]> GetInstrumentInMarginInstrumentListHistoryAsync(long entityId)
        {
            await using var context = _contextFactory.Create();

            return await context.InstrumentsInMarginInstrumentListHistory.TagWith(nameof(GetInstrumentInMarginInstrumentListHistoryAsync))
                .Include(x => x.MarginInstrument)
                .Include(x => x.List)
                .Where(x => x.EntityId == entityId)
                .ToArrayAsync();
        }

        public async Task<InstrumentInMarginInstrumentList[]> GetInstrumentsInListByInstrumentIdAsync(long marginInstrumentId, long[] listIds)
        {
            await using var context = _contextFactory.Create();

            return context.InstrumentsInMarginInstrumentList.TagWith(nameof(GetInstrumentsInListByInstrumentIdAsync))
                .Include(x => x.MarginInstrument)
                .Include(x => x.List)
                .Include(i => i.TransferPlaces)
                .ThenInclude(p => p.TransferPlace)
                .Where(i => i.MarginInstrumentId == marginInstrumentId
                            && listIds.Contains(i.ListId)
                            && !i.IsDeleted)
                .ToArray();
        }
        
        public async Task<InstrumentInMarginInstrumentList[]> GetInstrumentsInListByListIdAsync(long listId)
        {
            await using var context = _contextFactory.Create();

            return context.InstrumentsInMarginInstrumentList.TagWith(nameof(GetInstrumentsInListByListIdAsync))
                .Where(i => listId == i.ListId && !i.IsDeleted)
                .ToArray();
        }

        public async Task<InstrumentInMarginInstrumentListImport[]> GetInstrumentInListImportsAsync(Guid fileId)
        {
            await using var context = _contextFactory.Create();

            return (from i in context.InstrumentInMarginInstrumentImports
                    join l in context.MarginInstrumentLists on i.ListCode equals l.Code
                    join m in context.MarginInstrument on i.InstrumentCode equals m.Ticker
                    join il in context.InstrumentsInMarginInstrumentList on new {ListId = l.Id, MarginInstrumentId = m.Id} equals new {il.ListId, il.MarginInstrumentId} 
                    into illjs
                    from illj in illjs.DefaultIfEmpty()
                    where i.FileId == fileId
                          && ((i.IsLong ?? false) || (i.IsShort ?? false))
                    select new {i, l, m, illj})
                .TagWith(nameof(GetInstrumentInListImportsAsync))
                .ToArray()
                .Select(x =>
                {
                    var i = x.i;
                    i.Id = 0;
                    i.InstrumentListId = x.illj?.Id;
                    i.List = x.l;
                    i.MarginInstrument = x.m;
                    return i;
                })
                .ToArray();
        }
    }
}
