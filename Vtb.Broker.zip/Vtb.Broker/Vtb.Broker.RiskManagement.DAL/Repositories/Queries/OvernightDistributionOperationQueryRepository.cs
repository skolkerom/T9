﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{

    public class OvernightDistributionOperationQueryRepository : IOvernightDistributionOperationQueryRepository
    {
        private readonly IContextFactory<RiskManagementContext> _riskManagementContext;

        public OvernightDistributionOperationQueryRepository(IContextFactory<RiskManagementContext> riskManagementContext)
        {
            _riskManagementContext = riskManagementContext;
        }
        
        public async Task<OvernightDistributionOperation[]> Get(string clientCode, long distributionId)
        {
            await using var context = _riskManagementContext.Create();

            var query = context.OvernightDistributionOperations
                .Where(x => x.OvernightDistributionId == distributionId);

            query = !string.IsNullOrWhiteSpace(clientCode) 
                ? query.Where(x => x.ClientCode == clientCode) 
                : query.Take(1000);
            
            return await query.ToArrayAsync();
        }

        public async Task<OvernightDistributionOperationAggregate[]> GetAggregated(long overnightDistributionId)
        {
            await using var context = _riskManagementContext.Create();

            var query = from o in context.OvernightDistributionOperations.TagWith(
                    nameof(OvernightDistributionOperationQueryRepository) + "." + nameof(GetAggregated))
                where o.OvernightDistributionId == overnightDistributionId
                group o by new {o.BaseInstrumentCode, o.InstrumentCode, o.Currency, o.FX, o.BaseInstrumentFX, o.InstrumentType, o.OperationType}
                into grp
                select new OvernightDistributionOperationAggregate
                {
                    BaseInstrumentCode = grp.Key.BaseInstrumentCode,
                    InstrumentCode = grp.Key.InstrumentCode,
                    Currency = grp.Key.Currency,
                    FX = grp.Key.FX,
                    BaseInstrumentFX = grp.Key.BaseInstrumentFX,
                    InstrumentType = grp.Key.InstrumentType,
                    OperationType = grp.Key.OperationType,
                    Quantity = grp.Sum(x => x.Quantity),
                    CommissionRepo1 = grp.Sum(x => x.CommissionRepo1),
                    CommissionRepo2 = grp.Sum(x => x.CommissionRepo2)
                };

            return await query.ToArrayAsync();
        }
    }
}