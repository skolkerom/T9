﻿using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class CurrencyQueryRepository : ICurrencyQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public CurrencyQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        
        public async Task<Currency[]> GetCurrencies()
        {
            await using var context = _contextFactory.Create();

            var currencies = await context.Currencies
                .FromSqlRaw("[MarginTrading].[Currency_GetAll]")
                .ToArrayAsync();

            return currencies;
        }
    }
}