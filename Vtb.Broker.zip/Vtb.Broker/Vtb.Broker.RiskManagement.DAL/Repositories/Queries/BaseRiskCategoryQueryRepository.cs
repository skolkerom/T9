using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{

    public class BaseRiskCategoryQueryRepository : IBaseRiskCategoryQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public BaseRiskCategoryQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<BaseRiskCategory[]> GetBaseRiskCategoriesAsync()
        {
            using var context = _contextFactory.Create();

            return await context.BaseRiskCategories.TagWith(nameof(GetBaseRiskCategoriesAsync))
                .ToArrayAsync();
        }
    }
}
