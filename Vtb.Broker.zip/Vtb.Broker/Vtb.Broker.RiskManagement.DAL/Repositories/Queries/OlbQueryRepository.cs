using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{

    public class OlbQueryRepository : IOlbQueryRepository
    {
        private readonly IContextFactory<OlbReadOnlyContext> _contextFactory;
        private readonly IContextFactory<RiskManagementContext> _rmContextFactory;

        public OlbQueryRepository(IContextFactory<OlbReadOnlyContext> contextFactory,
            IContextFactory<RiskManagementContext> rmContextFactory)
        {
            _contextFactory = contextFactory;
            _rmContextFactory = rmContextFactory;
        }

        public async Task<OlbSecurity[]> GetOlbSecuritiesDistinctByShortName()
        {
            var q = GetOlbSecurities();

            return (await q)
                .GroupBy(i => i.ShortName)
                .Select(i => i.First())
                .ToArray();
        }

        public async Task<OlbSecurity[]> GetOlbSecurities()
        {
            await using var context = _contextFactory.Create();

            var q = await context.Set<OlbSecurity>().FromSqlRaw($"[rm].[GetInstruments]")
                .ToArrayAsync();
            return q;
        }

        public async Task<OlbParameter[]> GetOlbParameters()
        {
            await using var context = _rmContextFactory.Create();
            return await context.OlbParameters.ToArrayAsync();            
        }
    }
}
