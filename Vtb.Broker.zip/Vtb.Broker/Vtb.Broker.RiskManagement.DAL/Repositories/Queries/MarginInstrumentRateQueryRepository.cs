using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class MarginInstrumentRateQueryRepository : IMarginInstrumentRateQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;
        private readonly IInstrumentInMarginInstrumentListQueryRepository _instrumentInListQueryRepository;
        private readonly IMarginInstrumentListQueryRepository _marginInstrumentListQueryRepository;
        private readonly IRiskRateQueryRepository _riskRateQueryRepository;
        private readonly IMapperService _mapper;

        public MarginInstrumentRateQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory,
            IInstrumentInMarginInstrumentListQueryRepository instrumentInListQueryRepository,
            IMarginInstrumentListQueryRepository marginInstrumentListQueryRepository,
            IRiskRateQueryRepository riskRateQueryRepository,
            IMapperService mapper)
        {
            _contextFactory = contextFactory;
            _instrumentInListQueryRepository = instrumentInListQueryRepository;
            _marginInstrumentListQueryRepository = marginInstrumentListQueryRepository;
            _riskRateQueryRepository = riskRateQueryRepository;
            _mapper = mapper;
        }

        public async Task<MarginInstrumentRate[]> GetMarginInstrumentRates(DateTime date, long listId, long? instrumentInListId)
        {
            await using var context = _contextFactory.Create();

            var list = await context.MarginInstrumentLists.FirstOrDefaultAsync(x => x.Id == listId);

            if (list == null)
                return await Task.FromResult(new MarginInstrumentRate[0]);

            return GetMarginInstrumentRatesInner(context, date, list, instrumentInListId);
        }

        private static MarginInstrumentRate[] GetMarginInstrumentRatesInner(RiskManagementReadOnlyContext context, DateTime dt, 
            MarginInstrumentList list, long? instrumentInListId = null)
        {
            var activeOrHistoryParam = new SqlParameter("@activeOrHistory", false);
            var dateParam = new SqlParameter("@date", $"{dt:yyyyMMdd}");
            var listCodeParam = new SqlParameter("@list_code", $"{list.Code}");
            var forAllLists = new SqlParameter("@for_all_lists", false);

            var resultQuery = context.MarginInstrumentRate.FromSqlRaw(
                    $@"EXEC [rm].[sp_get_margin_instrument_rates] @activeOrHistory, @date, @list_code, @for_all_lists",
                    activeOrHistoryParam,
                    dateParam,
                    listCodeParam,
                    forAllLists)
                .ToArray();

            if (instrumentInListId != null)
                resultQuery = resultQuery.Where(x => x.InstrumentInMarginInstrumentList.Id == instrumentInListId).ToArray();

            var resultList = resultQuery.ToArray();

            var instrumentInListIds = resultList.Select(r => r.InstrumentInMarginInstrumentListId).ToArray();
            var instrumentInLists = context.InstrumentsInMarginInstrumentList
                .Include(x => x.MarginInstrument)
                .Include(x => x.List) 
                .Where(il => instrumentInListIds.Contains(il.Id)).ToDictionary(il => il.Id);

            resultList.ForEachEx(i => i.InstrumentInMarginInstrumentList = instrumentInLists[i.InstrumentInMarginInstrumentListId]);

            return resultList;
        }

        public async Task<MarginInstrumentRate[]> GetMarginInstrumentRatesHistory(long instrumentInListId)
        {
            await using var context = _contextFactory.Create();

            var instrumentInListHistory = (await _instrumentInListQueryRepository.GetInstrumentInMarginInstrumentListHistoryAsync(instrumentInListId));

            if (!instrumentInListHistory.Any())
                return new MarginInstrumentRate[0];

            var isin = instrumentInListHistory.First().MarginInstrument.Isin;
            var listCode = instrumentInListHistory.First().List.Code;

            var riskDates = new List<DateTime>((await GetRiskRateDates(isin)));
            var instrumentInListDates = instrumentInListHistory.Select(h => h.ModifiedDate.Date).Distinct().ToList();
            
            var marginRates = new List<MarginInstrumentRateDto>();
            
            foreach (var date in riskDates.Concat(instrumentInListDates))
            {
                FormattableString sql = $"execute rm.sp_get_margin_instrument_rates @activeOrHistory = {1}, @date = '{date.ToString("yyyyMMdd")}', @list_code = '{listCode}', @for_all_lists = {0}";
                
                marginRates.AddRange(await context.MarginInstrumentRateDtos
                    .FromSqlInterpolated(sql)
                    .ToListAsync());
            }

            var joined = (from mr in marginRates
                join h in instrumentInListHistory on mr.InstrumentListId equals h.Id
                let a = _mapper.Map<InstrumentInMarginInstrumentList>(h)
                select new MarginInstrumentRate
                {
                    RateDate = mr.RateDate,
                    InstrumentInMarginInstrumentList = a,
                    InstrumentInMarginInstrumentListId = h.Id,
                    RateLong = mr.RateLong,
                    RateShort = mr.RateShort,
                    RateLongStandart = mr?.RateLongStandart,
                    RateShortStandart = mr?.RateShortStandart,
                    IsVtbOnly = h.IsVtbOnly,
                    IsRestricted = h.IsRestricted,
                    IsLong = h.IsLong,
                    IsShort = h.IsShort,
                    IsMarginal = h.IsMarginal,
                    IsDeleted = h.IsDeleted,
                    ModifiedDate = h.ModifiedDate,
                    ModifiedUser = h.ModifiedUser,
                    IsExchangeRepo = h.IsExchangeRepo
                }).ToList();

            var rResult = joined
                .Where(r => riskDates.Contains(r.RateDate ?? DateTime.MinValue))
                .ForEachEx(r =>
                {
                    r.ModifiedUser = "system";
                    r.ModifiedDate = r.RateDate ?? DateTime.MinValue;
                })
                .GroupBy(r => new
                {
                    r.RateLong, 
                    r.RateShort
                })
                .Select(r => r.LastOrDefault())
                .ToArray();
            
            var iResult = joined
                .Where(r => instrumentInListDates.Contains(r.ModifiedDate.Date))
                .GroupBy(r => new
                {
                    r.InstrumentInMarginInstrumentListId, 
                    r.IsVtbOnly,
                    r.IsLong,
                    r.IsShort,
                    r.IsRestricted,
                    r.IsMarginal,
                    r.InstrumentInMarginInstrumentList.IsExchangeRepo
                })
                .Select(r => r.LastOrDefault())
                .ToArray();

            return rResult.Concat(iResult).Distinct().ToArray();
        }

        public async Task<MarginInstrumentRate[]> GetMarginInstrumentRates(DateTime date, MarginInstrumentList[] mLists)
        {
            var lists = (mLists?.Any() ?? false) ? mLists : await _marginInstrumentListQueryRepository.GetActiveMarginInstrumentLists();
            
            await using var context = _contextFactory.Create();

            var result = new List<MarginInstrumentRate>();
            
            foreach (var list in lists)
            {
                 result.AddRange(GetMarginInstrumentRatesInner(context, date, list));
            }

            return result.ToArray();
        }

        private async Task<DateTime[]> GetRiskRateDates(string isin)
        {
            return (await _riskRateQueryRepository.GetRiskRates(isin)).Select(r => r.RateDate).Distinct().ToArray();
        }
    }
}