using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class OvernightDistributionQueryRepository : IOvernightDistributionQueryRepository
    {
        private readonly IContextFactory<RiskManagementContext> _context;

        public OvernightDistributionQueryRepository(IContextFactory<RiskManagementContext> context)
        {
            _context = context;
        }
        public async Task<OvernightDistribution[]> Get(DateTime date)
        {
            await using var context = _context.Create();
            
            return await context.OvernightDistributions
                .Where(x => x.Date == date).ToArrayAsync();
        }
    }
}
