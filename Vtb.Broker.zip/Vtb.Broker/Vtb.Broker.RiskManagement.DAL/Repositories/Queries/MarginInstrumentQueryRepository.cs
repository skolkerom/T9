using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates.MarginInstrument;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class MarginInstrumentQueryRepository : IMarginInstrumentQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;
        private readonly IMapperService _mapperService;

        public MarginInstrumentQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory, IMapperService mapperService)
        {
            _contextFactory = contextFactory;
            _mapperService = mapperService;
        }

        private IQueryable<MarginInstrument> GetMarginInstrumentsQuery(RiskManagementReadOnlyContext context)
        {
            return context.MarginInstrument
                .Include(x => x.SecurityTypeRate);
        }
        public async Task<MarginInstrument[]> GetMarginInstruments()
        {
            await using var context = _contextFactory.Create();
            return await GetMarginInstrumentsQuery(context)
                .TagWith(nameof(GetMarginInstruments))
                .ToArrayAsync();
        }

        public async Task<MarginInstrument> GetMarginInstrument(long id)
        {
            await using var context = _contextFactory.Create();
            return await GetMarginInstrumentsQuery(context)
                .TagWith(nameof(GetMarginInstruments))
                .SingleOrDefaultAsync(m => m.Id == id && !m.IsDeleted);
        }

        public async Task<MarginInstrument> GetMarginInstrument(string isin)
        {
            await using var context = _contextFactory.Create();
            return await GetMarginInstrumentsQuery(context)
                .TagWith(nameof(GetMarginInstruments))
                .SingleOrDefaultAsync(m => m.Isin == isin && !m.IsDeleted);
        }

        public async Task<MarginInstrumentReestrAggregate[]> GetMarginInstrumentsForReestr()
        {
            await using var context = _contextFactory.Create();

            var query = GetMarginInstrumentsQuery(context);

            var md = await context.MarginInstrumentMarketData
                .FromSqlRaw("rm.sp_zfront_get_margin_instrument_market_data")
                .ToListAsync();

            var records = await (from mi in query
                join i in context.ZfInstruments on mi.Ticker equals i.InstrumentCode into ljI
                from i in ljI.DefaultIfEmpty()
                select new
                {
                    MarginInstrument = mi,
                    LotSize = (int?)i.LotSize
                }).TagWith(nameof(GetMarginInstrumentsForReestr)).ToListAsync();

            var date = DateTime.Now.Date;

            var aggregates = (from il in context.InstrumentsInMarginInstrumentList
                where il.StartDate <= date && 
                      (il.EndDate >= date || il.EndDate == null) && 
                      !il.IsDeleted
                group il by il.MarginInstrumentId
                into grp
                select new
                {
                    MarginInstrumentId = grp.Key,
                    IsShort = grp.Max(x => x.IsShort ? 1 : 0),
                    IsLong = grp.Max(x => x.IsLong ? 1 : 0)
                }).ToList();

            var instrumentAndMarketData = (from r in records
                join a in aggregates on r.MarginInstrument.Id equals a.MarginInstrumentId into lja
                from a in lja.DefaultIfEmpty()
                join m in md on r.MarginInstrument.Ticker equals m.Ticker into ljm
                from m in ljm.DefaultIfEmpty()
                select new
                {
                    MarginInstrumentData = r,
                    MarketData = m,
                    Aggregate = a
                }).ToList();

            var result = instrumentAndMarketData.Select(x =>
            {
                var dto = _mapperService.Map<MarginInstrumentReestrAggregate>(x.MarginInstrumentData.MarginInstrument);
                dto.ClosePrice = (decimal?) x.MarketData?.ClosePrice;
                dto.LotSize = x.MarginInstrumentData.LotSize ?? 1;
                dto.IsLong = x.Aggregate?.IsLong == 1;
                dto.IsShort = x.Aggregate?.IsShort == 1;
                
                return dto;
            }).ToArray();

            return result;
        }

        public async Task<MarginInstrumentImport[]> GetMarginInstrumentImports(Guid fileId)
        {
            await using var context = _contextFactory.Create();

            return context.MarginInstrumentImport.Where(i => i.FileId == fileId).ToArray();
        }
    }
}
