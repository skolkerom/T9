using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{

    public class OvernightDistributionPositionQueryRepository : IOvernightDistributionPositionQueryRepository
    {
        private readonly IContextFactory<RiskManagementContext> _context;

        public OvernightDistributionPositionQueryRepository(IContextFactory<RiskManagementContext> context)
        {
            _context = context;
        }
        public async Task<OvernightDistributionPosition[]> Get(string clientCode, long distributionId)
        {
            await using var context = _context.Create();

            var query = context.OvernightDistributionPositions.Where(x => x.OvernightDistributionId == distributionId);

            query = !string.IsNullOrWhiteSpace(clientCode) 
                ? query.Where(x => x.ClientCode == clientCode) 
                : query.Take(1000);
                
            return await query.ToArrayAsync();
        }

        public async Task<OvernightDistributionPositionAggregate[]> GetAggregated(long distributionId)
        {
            await using var context = _context.Create();

            var positionQuery = from p in context.OvernightDistributionPositions
                where p.OvernightDistributionId == distributionId && p.PositionStart != p.PositionEnd
                group p by new {p.InstrumentCode, p.Currency}
                into grp
                select new OvernightDistributionPositionAggregate
                {
                    InstrumentCode = grp.Key.InstrumentCode,
                    Currency = grp.Key.Currency,
                    PositionStart = grp.Sum(x => x.PositionStart),
                    PositionEnd = grp.Sum(x => x.PositionEnd)
                };
            
            return await positionQuery.ToArrayAsync();
        }
        
        public async Task<OvernightDistributionCurrencyPositionAggregate[]> GetCurrencyAggregated(long distributionId)
        {
            await using var context = _context.Create();
 

            var positions = await (from p in context.OvernightDistributionPositions
                where p.OvernightDistributionId == distributionId && 
                      p.InstrumentType == OvernightDistributionInstrumentType.Currency &&
                      p.PositionStart < 0
                group p by p.InstrumentCode
                into grp
                select new OvernightDistributionCurrencyPositionAggregate
                {
                    Currency = grp.Key,
                    PositionStart = grp.Sum(x => x.PositionStart),
                    PositionEnd = grp.Sum(x => x.PositionEnd)
                }).ToArrayAsync();
            

            var commissions = await (from p in context.OvernightDistributionOperations
                where p.OvernightDistributionId == distributionId &&
                      p.InstrumentType == OvernightDistributionInstrumentType.Currency
                group p by p.BaseInstrumentCode
                into grp
                select new
                {
                    Currency = grp.Key,
                    CommissionRepo1 = grp.Sum(x => x.CommissionRepo1),
                    CommissionRepo2 = grp.Sum(x => x.CommissionRepo2)
                }).ToDictionaryAsync(x=>x.Currency);

            foreach (var positionAggregate in positions)
            {
                if (commissions.ContainsKey(positionAggregate.Currency))
                {
                    var comm = commissions[positionAggregate.Currency];
                    positionAggregate.CommissionRepo1 = comm.CommissionRepo1;
                    positionAggregate.CommissionRepo2 = comm.CommissionRepo2;
                }
            }

            return positions;
        }
    }
}