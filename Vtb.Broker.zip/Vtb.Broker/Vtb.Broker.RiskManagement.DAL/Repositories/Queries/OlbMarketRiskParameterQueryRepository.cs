using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class OlbMarketRiskParameterQueryRepository : IOlbMarketRiskParameterQueryRepository
    {
        private readonly IContextFactory<OlbReadOnlyContext> _contextFactory;

        public OlbMarketRiskParameterQueryRepository(IContextFactory<OlbReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public async Task<OlbMarketRiskParameter[]> GetMarketRiskParameters(int rangeNumber)
        {
            await using var context = _contextFactory.Create();

            return await context.MarketRiskParameters.FromSqlRaw("[rm].[GetMarketRiskParameters]").ToArrayAsync();
        }
    }
}
