using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class MarginInstrumentListQueryRepository : IMarginInstrumentListQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public MarginInstrumentListQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<MarginInstrumentList[]> GetMarginInstrumentLists()
        {
            await using var context = _contextFactory.Create();

            return await context.MarginInstrumentLists
                .TagWith(nameof(GetMarginInstrumentLists))
                .ToArrayAsync();
        }

        public async Task<MarginInstrumentList[]> GetActiveMarginInstrumentLists()
        {
            await using var context = _contextFactory.Create();

            return await context.MarginInstrumentLists
                .TagWith(nameof(GetActiveMarginInstrumentLists))
                .Where(l => !l.IsDeleted)
                .ToArrayAsync();
        }

        public async Task<MarginInstrumentList> GetMarginInstrumentList(long id)
        {
            await using var context = _contextFactory.Create();

            return await context.MarginInstrumentLists
                .TagWith(nameof(GetMarginInstrumentList))
                .FirstOrDefaultAsync(x => x.Id == id);
        }
        
        public async Task<MarginInstrumentList[]> GetMarginInstrumentLists(long[] ids)
        {
            await using var context = _contextFactory.Create();

            return await context.MarginInstrumentLists
                .Include(x => x.Instruments)
                .ThenInclude(x => x.MarginInstrument)
                .TagWith(nameof(GetMarginInstrumentList))
                .Where(x => ids.Contains(x.Id))
                .ToArrayAsync();
        }
    }
}
