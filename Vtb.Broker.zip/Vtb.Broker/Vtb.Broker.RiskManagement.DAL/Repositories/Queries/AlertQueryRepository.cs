﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Alerts.Entities;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class AlertQueryRepository : IAlertQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public AlertQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        
        public async Task<Alert[]> GetAlerts()
        {
            await using var context = _contextFactory.Create();
            return await context.Alerts.Where(a => !a.IsDeleted).ToArrayAsync();
        }

        public async Task<AlertEmail[]> GetAlertEmails(long id)
        {
            await using var context = _contextFactory.Create();
            return await context.AlertEmails.Where(e => e.AlertId == id).ToArrayAsync();
        }

        public async Task<AlertEmailTemplate[]> GetAlertEmailTemplates(long alertId)
        {
            await using var context = _contextFactory.Create();
            return await context.AlertTemplates.Where(e => e.AlertId == alertId).ToArrayAsync();
        }

        public async Task<AlertEmail> GetAlertEmail(long id)
        {
            await using var context = _contextFactory.Create();
            return await context.AlertEmails.SingleOrDefaultAsync(e => e.Id == id);
        }

        public async Task<AlertEmailTemplate> GetAlertEmailTemplate(long id)
        {
            await using var context = _contextFactory.Create();
            return await context.AlertTemplates.SingleOrDefaultAsync(e => e.Id == id);
        }
    }
}