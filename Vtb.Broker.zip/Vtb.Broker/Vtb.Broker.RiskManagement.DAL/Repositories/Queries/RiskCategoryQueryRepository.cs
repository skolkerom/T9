using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{
    public class RiskCategoryQueryRepository : IRiskCategoryQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public RiskCategoryQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<RiskCategory[]> GetRiskCategoriesAsync()
        {
            await using var context = _contextFactory.Create();
            return await
                context.RiskCategories.TagWith(nameof(GetRiskCategoriesAsync))
                .ApplyIncludes()
                .ToArrayAsync();
        }

        public async Task<RiskCategory> GetRiskCategoryAsync(long id)
        {
            using var context = _contextFactory.Create();

            return await
                context.RiskCategories.TagWith(nameof(GetRiskCategoriesAsync))
                .ApplyIncludes()
                .Where(x => x.Id == id)
                .FirstOrDefaultAsync();
        }
    }
}
