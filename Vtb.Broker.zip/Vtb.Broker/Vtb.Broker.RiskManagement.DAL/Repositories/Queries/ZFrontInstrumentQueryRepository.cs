﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{

    public class ZFrontInstrumentQueryRepository : IZFrontQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;

        public ZFrontInstrumentQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<string> GetZfInstrumentType(string isin)
        {
            await using var context = _contextFactory.Create();
            return await (from i in context.ZfInstruments
                          join t in context.ZfInstrumentTypes on i.TypeId equals t.Id
                          where  i.Isin == isin
                          select t.ShortName)
            .TagWith(nameof(GetZfInstrumentType))
            .FirstOrDefaultAsync();
        }
    } 
}
