using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Queries
{


    public class HistoryQueryRepository : IHistoryQueryRepository
    {
        private readonly IContextFactory<RiskManagementReadOnlyContext> _contextFactory;
        private readonly IMapperService _mapper;

        public HistoryQueryRepository(IContextFactory<RiskManagementReadOnlyContext> contextFactory, IMapperService mapper)
        {
            _contextFactory = contextFactory;
            _mapper = mapper;
        }

        private THistory[] GetHistoryInternal<THistory>(long id)
            where THistory : class, IHistory
        {
            using var context = _contextFactory.Create();

            var query = context.Set<THistory>()
                .Where(x => x.EntityId == id);

            query = IncludeStrategies.ApplyDefaultStrategy(query)
                .OrderBy(x => x.Id);

            return query.ToArray();
        }

        public async Task<TEntity[]> GetHistory<TEntity>(long id)
            where TEntity : class, IEntity
        {
            using var context = _contextFactory.Create();

            var attr = (HistorableAttribute)typeof(TEntity).GetCustomAttribute(typeof(HistorableAttribute));

            var method = this.GetType().GetMethod(nameof(GetHistoryInternal), BindingFlags.Instance | BindingFlags.NonPublic)
                .MakeGenericMethod(attr.HistoryEntityType);

            var items = await Task.Run(() => method.Invoke(this, new object[] { id }));

            var result = (items as IEnumerable<object>)
                .Select(x => _mapper.Map<TEntity>(x))
                .ForEachEx((x, i) => x.Id = i) // assign Id to row number of history record ordered by id
                .ToArray();


            return result;
        }



    }
}
