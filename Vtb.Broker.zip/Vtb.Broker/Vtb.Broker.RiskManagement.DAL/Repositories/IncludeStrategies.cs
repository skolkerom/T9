using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Repositories
{
    public static class IncludeStrategies
    {
        class IncludeContainer<TEntity>
        {
            public IncludeContainer(Func<IQueryable<TEntity>, IQueryable<TEntity>> func)
            {
                IncludeFunc = func;
            }
            public Func<IQueryable<TEntity>, IQueryable<TEntity>> IncludeFunc { get; set; }
        }
        public static Dictionary<Type, object> _strategies
            = new Dictionary<Type, object>
            {
                {typeof(RiskCategory), new IncludeContainer<RiskCategory>(x => x.ApplyIncludes())},
                {typeof(RiskCategoryHistory), new IncludeContainer<RiskCategoryHistory>(x => x.ApplyIncludes())},
                {typeof(RiskRate), new IncludeContainer<RiskRate>(x => x.ApplyIncludes())},
                {typeof(InstrumentInMarginInstrumentListHistory), new IncludeContainer<InstrumentInMarginInstrumentListHistory>(x => x.ApplyIncludes())},
                {typeof(MarginInstrumentHistory), new IncludeContainer<MarginInstrumentHistory>(x => x.ApplyIncludes())}
            };

        public static IQueryable<TEntity> ApplyDefaultStrategy<TEntity>(IQueryable<TEntity> query)
        {
            if (!_strategies.ContainsKey(typeof(TEntity)))
                return query;

            return (_strategies[typeof(TEntity)] as IncludeContainer<TEntity>).IncludeFunc(query);
        }

        public static IQueryable<RiskCategory> ApplyIncludes(this IQueryable<RiskCategory> query)
        {
            return query
                .Include(x => x.BaseRiskCategory)
                .Include(x => x.MarginInstrumentList)
                .Include(x => x.Marketplaces)
                    .ThenInclude(x => x.Marketplace);
        }

        public static IQueryable<RiskCategoryHistory> ApplyIncludes(this IQueryable<RiskCategoryHistory> query)
        {
            return query
                .Include(x => x.BaseRiskCategory)
                .Include(x => x.MarginInstrumentList)
                .Include(x => x.Marketplaces)
                    .ThenInclude(x => x.Marketplace);
        }

        public static IQueryable<MarginInstrumentHistory> ApplyIncludes(this IQueryable<MarginInstrumentHistory> query)
        {
            return query
                .Include(x => x.TransferPlaces)
                    .ThenInclude(x => x.TransferPlace);
        }


        public static IQueryable<RiskRate> ApplyIncludes(this IQueryable<RiskRate> query)
        {
            return query.Include(x => x.MarginInstrumentList);
        }

        public static IQueryable<InstrumentInMarginInstrumentListHistory> ApplyIncludes(this IQueryable<InstrumentInMarginInstrumentListHistory> query)
        {
            return query
                .Include(x => x.List);
        }
    }
}
