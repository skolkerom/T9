using System;
using System.Linq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.RiskManagement.DAL.Contexts;

namespace Vtb.Broker.RiskManagement.DAL.Repositories
{
    public static class RiskRatesContextExtensions
    {
        public static IQueryable<RiskRate> NotDeleted(this IQueryable<RiskRate> rates)
        {
            return rates.Where(x => !x.IsDeleted);
        }

        public static IQueryable<MarginInstrumentRate> NotDeleted(this IQueryable<MarginInstrumentRate> rates)
        {
            return rates.Where(x => !x.IsDeleted);
        }

        public static IQueryable<InstrumentInMarginInstrumentList> NotDeleted(this IQueryable<InstrumentInMarginInstrumentList> rates)
        {
            return rates.Where(x => !x.IsDeleted);
        }

        public static IQueryable<RiskRate> GetActiveRiskRatesQuery(this RiskManagementContext context, DateTime date)
        {
            var query = from mr in (from r in context.RiskRates.NotDeleted()
                                    where r.RateDate <= date
                                    group r by new {r.Isin, r.Source} into grp
                                    select new
                                    {
                                        grp.Key.Isin,
                                        grp.Key.Source,
                                        RateDate = grp.Max(x => x.RateDate)
                                    })
                        join r in context.RiskRates.NotDeleted() on
                            new { mr.Source, mr.Isin, mr.RateDate } equals
                            new { r.Source, r.Isin, r.RateDate }
                        select r;

            return query;
        }        
    }
}
