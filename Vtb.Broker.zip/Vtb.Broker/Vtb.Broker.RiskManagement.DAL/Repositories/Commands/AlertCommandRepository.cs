﻿using System.Threading.Tasks;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Alerts.Entities;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class AlertCommandRepository : IAlertCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapperService;

        public AlertCommandRepository(RiskManagementContext context, IMapperService mapperService)
        {
            _context = context;
            _mapperService = mapperService;
        }
        
        public async Task SaveAsync(AlertEmail entity)
        {
            await _context.SaveEntities<AlertEmail, AlertEmailHistory>(new[]{entity}, _mapperService);
        }
        
        public async Task SaveAsync(AlertEmailTemplate entity)
        {
            await _context.SaveEntities<AlertEmailTemplate, AlertEmailTemplateHistory>(new[]{entity}, _mapperService);
        }
    }
}