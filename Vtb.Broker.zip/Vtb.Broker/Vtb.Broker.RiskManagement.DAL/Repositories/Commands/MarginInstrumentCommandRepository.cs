using System.Linq;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class MarginInstrumentCommandRepository : IMarginInstrumentCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapper;
        private readonly IAuditService _auditService;

        public MarginInstrumentCommandRepository(RiskManagementContext context, IMapperService mapper, IAuditService auditService)
        {
            _context = context;
            _mapper = mapper;
            _auditService = auditService;
        }

        public async Task Save(MarginInstrument marginInstrument)
        {
            _context.AttachRootEntityToContext(marginInstrument);

            await _context.SaveEntityWithHistory<MarginInstrument, MarginInstrumentHistory>(_auditService, marginInstrument, _mapper);
        }

        public async Task Save(MarginInstrument[] instruments)
        {
            foreach (var instrument in instruments)
            {
                await Save(instrument);
            }
        }
    }
}
