﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{


    public class InstrumentInMarginInstrumentListCommandRepository : IInstrumentInMarginInstrumentListCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapper;
        private readonly IAuditService _auditService;

        public InstrumentInMarginInstrumentListCommandRepository(RiskManagementContext context, IMapperService mapper, IAuditService auditService)
        {
            _context = context;
            _mapper = mapper;
            _auditService = auditService;
        }
        public async Task Save(InstrumentInMarginInstrumentList instrument)
        {
            AttachTransferPlaces(instrument);

            await Validate(instrument, _context);
            
            await _context.SaveEntityWithHistory<InstrumentInMarginInstrumentList, InstrumentInMarginInstrumentListHistory>(_auditService, instrument, _mapper);
        }

        private void AttachTransferPlaces(InstrumentInMarginInstrumentList instrument)
        {
            var tps = _context.MarginInstrumentTransferPlaces.Where(x => x.InstrumentInListId == instrument.Id).ToArray();

            _context.AttachNavigationPropertyCollection(tps, instrument.TransferPlaces.ToArray(),
                (x, y) => x.InstrumentInListId == y.InstrumentInListId && x.TransferPlaceId == y.TransferPlaceId);
        }

        public async Task Save(InstrumentInMarginInstrumentList[] instruments)
        {
            foreach(var i in instruments)
            {
                AttachTransferPlaces(i);
                await Validate(i, _context);
            }
            
            await _context.SaveEntities<InstrumentInMarginInstrumentList, InstrumentInMarginInstrumentListHistory>(instruments, _mapper);
        }

        private async Task Validate(InstrumentInMarginInstrumentList instrumentInList, RiskManagementContext context)
        {
            if(instrumentInList.StartDate > instrumentInList.EndDate)
                throw new UserException($"Дата начала действия {instrumentInList.StartDate.ToShortDateString()} не может быть больше даты окончания {instrumentInList.EndDate?.ToShortDateString()}");

            if(instrumentInList.IsDeleted)
                return;

            var hasDuplicate = await context.InstrumentsInMarginInstrumentList.AsNoTracking().AnyAsync(x => 
                x.ListId == instrumentInList.ListId
                && !x.IsDeleted
                && x.MarginInstrumentId == instrumentInList.MarginInstrumentId
                && x.Id != instrumentInList.Id);

            if(hasDuplicate)
            {
                throw new UserException($"Инструмент ISIN = '{instrumentInList.MarginInstrument?.Isin}' уже добавлен в список '{instrumentInList.List.Name}'");
            }

            var intersected = await context.InstrumentsInMarginInstrumentList.AsNoTracking().FirstOrDefaultAsync(x => 
                x.ListId == instrumentInList.ListId
                && x.MarginInstrumentId == instrumentInList.MarginInstrumentId
                && instrumentInList.StartDate >= x.StartDate && (instrumentInList.StartDate < x.EndDate || x.EndDate == null)
                && !x.IsDeleted
                && x.Id != instrumentInList.Id);

            if(intersected != null)
                throw new UserException($"Период действия пересекается с существующим Id = {intersected.Id}");
        }
    }
}
