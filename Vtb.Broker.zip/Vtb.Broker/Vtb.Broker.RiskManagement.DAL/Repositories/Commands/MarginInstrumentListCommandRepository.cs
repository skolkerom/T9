using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class MarginInstrumentListCommandRepository : IMarginInstrumentListCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapper;
        private readonly IAuditService _auditService;

        public MarginInstrumentListCommandRepository(RiskManagementContext context, IMapperService mapper, IAuditService auditService)
        {
            _context = context;
            _mapper = mapper;
            _auditService = auditService;
        }
        public async Task CreateCopyAsync(MarginInstrumentList instrumentList, long templateListId)
        {
            await Validate(instrumentList);

            var instruments = await _context.InstrumentsInMarginInstrumentList
                .Where(x => x.ListId == templateListId)
                .ToArrayAsync();

            var newList = _mapper.Map<MarginInstrumentList>(instrumentList);
            newList.Instruments.Clear();

            var newInstruments = instruments.Select(x =>
            {
                var copy = _mapper.Map<InstrumentInMarginInstrumentList, InstrumentInMarginInstrumentList>(x);
                

                copy.CreatedDate = instrumentList.CreatedDate;
                copy.ModifiedDate = instrumentList.ModifiedDate;
                copy.CreatedUser = instrumentList.CreatedUser;
                copy.ModifiedUser = instrumentList.ModifiedUser;
                copy.Id = 0;

                copy.List = null;
                copy.ListId = 0;

                return copy;
            }).ToArray();
            
            newList.Instruments.AddRange(newInstruments);

            await _context.SaveEntityWithHistory<MarginInstrumentList, MarginInstrumentListHistory>(_auditService, newList, _mapper);
        }

        private async Task Validate(MarginInstrumentList instrumentList) 
        {
            if (await _context.MarginInstrumentLists.AnyAsync(x => x.Code == instrumentList.Code && 
                                                                   !x.IsDeleted && 
                                                                   !instrumentList.IsDeleted &&
                                                                   x.Id != instrumentList.Id))
                throw new UserException($"Список с наименованием {instrumentList.Name} уже существует");
        }

        public async Task Save(MarginInstrumentList instrumentList)
        {
            await Validate(instrumentList);

            await _context.SaveEntityWithHistory<MarginInstrumentList, MarginInstrumentListHistory>(_auditService, instrumentList, _mapper);
        }
    }
}
