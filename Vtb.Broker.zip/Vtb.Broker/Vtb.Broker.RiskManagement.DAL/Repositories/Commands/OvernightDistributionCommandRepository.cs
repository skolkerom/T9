﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Infrastructure.Auth;
using Vtb.Broker.Interfaces.EndpointProvider;
using Vtb.Broker.Interfaces.Integration.OptimalRepoCalculator;
using Vtb.Broker.Interfaces.Transport.Http;
using Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class OvernightDistributionCommandRepository : IOvernightDistributionCommandRepository
    {
        private readonly IWebRequestService _webRequestService;
        private readonly TokenProvider _tokenProvider;

        public OvernightDistributionCommandRepository(IWebRequestService webRequestService, TokenProvider tokenProvider)
        {
            _webRequestService = webRequestService;
            _tokenProvider = tokenProvider;
        }
        
        public async Task RunOvernightDistribution(DateTime date, string clientCode)
        {
            var parameters = new RunOvernightDistributionParameters
            {
                Date = date,
                ClientCode = clientCode
            };

            var accessToken = _tokenProvider.GetAsString();

            await _webRequestService.PostAsync(Endpoints.OptimalRepoCalculator, API.RunOvernightDistrubutionUrl,
                parameters, accessToken);
        }
    }
}