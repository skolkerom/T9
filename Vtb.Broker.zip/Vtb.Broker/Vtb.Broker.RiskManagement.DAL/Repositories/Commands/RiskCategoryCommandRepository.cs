using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class RiskCategoryMarketplaceComparer : IEqualityComparer<RiskCategoryMarketplace>
    {
        public bool Equals(RiskCategoryMarketplace x, RiskCategoryMarketplace y)
        {
            if (x == y)
                return true;

            if (x == null || y == null)
                return false;

            return x.MarketplaceId == y.MarketplaceId && x.RiskCategoryId == y.RiskCategoryId;
        }

        public int GetHashCode(RiskCategoryMarketplace obj)
        {
            return obj.MarketplaceId.GetHashCode() ^ obj.RiskCategoryId.GetHashCode();
        }
    }

    public class RiskCategoryCommandRepository : IRiskCategoryCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapper;
        private readonly IAuditService _auditService;

        public RiskCategoryCommandRepository(RiskManagementContext context, IMapperService mapper,
            IAuditService auditService)
        {
            _context = context;
            _mapper = mapper;
            _auditService = auditService;
        }

        public async Task Save(RiskCategory category)
        {
            if (!category.IsDeleted)
            {
                if (await _context.RiskCategories.AnyAsync(x =>
                    x.Id != category.Id && x.Code == category.Code && !x.IsDeleted))
                    throw new UserException($"Категория с кодом {category.Code} уже существует");

                if (await _context.RiskCategories.AnyAsync(x =>
                    x.Id != category.Id && x.Name == category.Name && !x.IsDeleted))
                    throw new UserException($"Категория с наименованием {category.Name} уже существует");

                if (category.FormingPrinciple == FormingPrinciple.Auto)
                {
                    if (category.Marketplaces.Count == 0)
                    {
                        throw new UserException("Выберите маркетплейс");
                    }

                    var mpIds = category.Marketplaces.Select(x => x.Marketplace?.Id ?? x.MarketplaceId).ToArray();

                    var brc = _context.BaseRiskCategories.AsNoTracking()
                        .First(x => x.Id == category.BaseRiskCategoryId);

                    var categoriesFromDb = await _context.RiskCategories
                        .AsNoTracking()
                        .TagWith($"{nameof(RiskCategoryCommandRepository)}.{nameof(Save)}")
                        .Where(x => x.Id != category.Id &&
                                    x.FormingPrinciple == FormingPrinciple.Auto &&
                                    !x.IsDeleted &&
                                    x.BaseRiskCategoryId == category.BaseRiskCategoryId &&
                                    (x.QualifiedInvestor == category.QualifiedInvestor 
                                        || x.QualifiedInvestor == QualifiedInvestor.All 
                                        || category.QualifiedInvestor == QualifiedInvestor.All) &&
                                    (x.IndividualInvestmentAccount == category.IndividualInvestmentAccount 
                                        || x.IndividualInvestmentAccount == IndividualInvestmentAccount.All 
                                        || category.IndividualInvestmentAccount == IndividualInvestmentAccount.All))
                        .Include(x => x.Marketplaces)
                        .ToArrayAsync();

                    if (categoriesFromDb
                        .SelectMany(x => x.Marketplaces)
                        .Select(x => x.MarketplaceId)
                        .Any(x => mpIds.Contains(x)))
                        throw new UserException(
                            $"Категория с атрибутами " +
                            $"{category.FormingPrinciple.GetDescription()}, " +
                            $"{brc.Name}, " +
                            $"{category.QualifiedInvestor.GetDescription()}, " +
                            $"{category.IndividualInvestmentAccount.GetDescription()} " +
                            $"пересекается с уже существующими категориями");
                }
            }

            var existedMarketplaces = await _context.RiskCategoryMarketplaces
                .Where(x => x.RiskCategoryId == category.Id)
                .ToArrayAsync();

            _context.AttachNavigationPropertyCollection(existedMarketplaces, category.Marketplaces.ToArray(),
                (x, y) => x.MarketplaceId == y.MarketplaceId && x.RiskCategoryId == y.RiskCategoryId);

            _context.AttachRootEntityToContext(category);

            await _context.SaveEntityWithHistory<RiskCategory, RiskCategoryHistory>(_auditService, category, _mapper);
        }
    }
}