﻿using System.Threading.Tasks;
using AutoMapper;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class MarginInstrumentRateCommandRepository : IMarginInstrumentRateCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapperService;

        public MarginInstrumentRateCommandRepository(RiskManagementContext context, IMapperService mapperService)
        {
            _context = context;
            _mapperService = mapperService;
        }
        public async Task SaveAsync(MarginInstrumentRate[] marginInstrumentRates)
        {
            _context.MarginInstrumentRate.AddRange(marginInstrumentRates);
            
            await _context.SaveChangesAsync();
        }

        public async Task SaveAsEntitiesAsync(MarginInstrumentRate[] marginInstrumentRates)
        {
            await _context.SaveEntities<MarginInstrumentRate, MarginInstrumentRateHistory>(marginInstrumentRates, _mapperService);
        }
    }
}