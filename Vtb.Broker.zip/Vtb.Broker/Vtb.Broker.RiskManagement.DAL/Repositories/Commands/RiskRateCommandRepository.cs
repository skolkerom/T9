using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Mapper;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Services;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class RiskRateCommandRepository : IRiskRateCommandRepository
    {
        private readonly RiskManagementContext _context;
        private readonly IMapperService _mapper;
        private readonly IOlbWcfService _olbWcfExecuteService;
        private readonly ILogger<RiskRateCommandRepository> _logger;

        public RiskRateCommandRepository(RiskManagementContext context, IMapperService mapper,
            IOlbWcfService olbWcfExecuteService, ILogger<RiskRateCommandRepository> logger)
        {
            _context = context;
            _mapper = mapper;
            _olbWcfExecuteService = olbWcfExecuteService;
            _logger = logger;
        }
        
        public async Task SaveAsync(RiskRate[] result)
        {
            await _context.SaveEntities<RiskRate, RiskRateHistory>(result, _mapper);

            await _context.SaveChangesAsync();
        }

        public async Task SaveToOlbAsync(MarginInstrumentRate[] marginRates = null, string listCode = "")
        {
            var forAllListsFlag = 1;
            var forAllLists = forAllListsFlag.ToString();
  
            var maxId = marginRates?.Max(r => r.Id);

            var (success, fail)  =  await _olbWcfExecuteService.RefreshRates(new[]
                    {
                        ("date", DateTime.Now.Date.ToString("yyyy-MM-dd")),
                        ("list_code", listCode),
                        ("for_all_lists", forAllLists)
                    });

            if (string.IsNullOrEmpty(fail.Trim()))
            {
                await _context.Database.ExecuteSqlInterpolatedAsync($"exec [rm].[sp_set_changed_margin_instrument_rates] @maxId = {maxId}");
                _logger.LogInformation(success);
            }
            else
            {
                _logger.LogError(fail);
            }
        }
    }
}
