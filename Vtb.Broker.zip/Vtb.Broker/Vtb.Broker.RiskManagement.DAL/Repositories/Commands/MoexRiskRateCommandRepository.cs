﻿using System;
using System.Threading.Tasks;
using Vtb.Broker.Interfaces.EndpointProvider;
using Vtb.Broker.Interfaces.Integration.MoexRiskRateDownloader;
using Vtb.Broker.Interfaces.Transport.Http;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class MoexRiskRateCommandRepository : IMoexRiskRateCommandRepository
    {
        private readonly IWebRequestService _webRequestService;

        public MoexRiskRateCommandRepository(IWebRequestService webRequestService)
        {
            _webRequestService = webRequestService;
        }
        
        public async Task SaveMoexRiskFileContent(DateTime date)
        {
            await _webRequestService.PostAsync(Endpoints.MoexRiskDownloader, API.MoexRiskRates, new {Date = date});
        }
    }
}