using System.Data;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.RiskManagement.DAL.Contexts;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Services;

namespace Vtb.Broker.RiskManagement.DAL.Repositories.Commands
{
    public class OlbCommandRepository : IOlbCommandRepository 
    {
        private readonly RiskManagementContext _context;

        public OlbCommandRepository(RiskManagementContext context)
        {
            _context = context;
        }

        public async Task<(string, string)> WcfExecute(string host, string port, OlbServerType serverType, string service, string method, string parameters) 
        {
            var hostParam = new SqlParameter("@WcfHost", host);
            var portParam = new SqlParameter("@WcfPort", port);
            var serverTypeParam = new SqlParameter("@WcfName", "Wcf." + serverType);
            var serviceParam = new SqlParameter("@WcfService", service);
            var methodParam = new SqlParameter("@WcfMethod", method);
            var parametersParam = new SqlParameter("@WcfParameters", parameters);

            var successResultParam = new SqlParameter("@WcfResult", SqlDbType.VarChar, 8000) { Direction = ParameterDirection.Output };
            var failResultParam = new SqlParameter("@WcfError", SqlDbType.VarChar, 8000){ Direction = ParameterDirection.Output };

            await _context.Database.ExecuteSqlRawAsync(
                $@"EXEC dbo.OlbWcfExecute
                        @WcfHost,
                        @WcfPort,
                        @WcfName,
                        @WcfService,
                        @WcfMethod,
                        @WcfParameters,
                        @Result = @WcfResult OUT,
                        @Error = @WcfError OUT", hostParam, portParam, serverTypeParam, serviceParam, methodParam, parametersParam, successResultParam, failResultParam);

            return (successResultParam.Value?.ToString() ?? "", failResultParam.Value?.ToString() ?? "");
        }
    }
}