﻿using System;

namespace Vtb.Broker.RiskManagement.DAL
{
    public class TempTableIsinDate
    {
        public string Isin { get; set; }
        public DateTime Date { get; set; }
    }
}
