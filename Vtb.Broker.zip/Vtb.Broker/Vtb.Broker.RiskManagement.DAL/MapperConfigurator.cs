using System.Linq;
using System.Reflection;
using AutoMapper;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates.MarginInstrument;
using Vtb.Broker.Domain.Entities.Dtos;
using Vtb.Broker.Interfaces.Annotations;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.RiskManagement.DAL
{

    public static class MapperConfigurator
    {
        static void RegisterMap<TEntity, THistory>(IMapperConfigurationExpression cfg)
            where TEntity : IHasId, new()
            where THistory : IHasId, new()
        {
            cfg.CreateMap<TEntity, TEntity>();
            cfg.CreateMap<TEntity, THistory>().ForMember(x => x.Id, opt => opt.Ignore());
            cfg.CreateMap<THistory, TEntity>().ForMember(x => x.Id, opt => opt.Ignore());
        }

        public static void ConfigureTypeMappings(IMapperConfigurationExpression cfg)
        {
            var entityTypes = Assembly.GetAssembly(typeof(RiskRate)).GetTypes()
                .Where(x => typeof(IHasId).IsAssignableFrom(x))
                .ToArray();

            foreach (var type in entityTypes)
            {
                if (type.GetCustomAttribute(typeof(HistorableAttribute)) is HistorableAttribute historableAttr)
                {
                    var registerMapMethod = typeof(MapperConfigurator)
                        .GetMethods(BindingFlags.Static | BindingFlags.NonPublic)
                        .Where(x => x.Name == nameof(RegisterMap))
                        .Single();

                    var method = registerMapMethod.MakeGenericMethod(type, historableAttr.HistoryEntityType);
                    method.Invoke(null, new[] { cfg });
                }
            }

            cfg.CreateMap<MarginInstrument, MarginInstrumentReestrAggregate>();
            
            cfg.CreateMap<RiskCategoryDto, RiskCategory>(); 
            cfg.CreateMap<RiskCategoryMarketplaceDto, RiskCategoryMarketplace>();

            cfg.CreateMap<MarginInstrumentDto, MarginInstrument>()
                .ForMember(p => p.SecurityTypeRate, opt => opt.Ignore());
            cfg.CreateMap<MarginInstrumentTransferPlaceDto, MarginInstrumentTransferPlace>()
                .ForMember(p => p.InstrumentInList, opt => opt.Ignore())
                .ForMember(p => p.TransferPlace, opt => opt.Ignore());

            cfg.CreateMap<InstrumentInMarginInstrumentList, InstrumentInMarginInstrumentList>()
                .ForMember(x => x.TransferPlaces, opt => opt.MapFrom(y => y.TransferPlaces))
                .AfterMap((x, y) =>  y.TransferPlaces = x.TransferPlaces);
            
            cfg.CreateMap<InstrumentInMarginInstrumentListDto, InstrumentInMarginInstrumentList>();

            cfg.CreateMap<InstrumentInMarginInstrumentListDto, InstrumentInMarginInstrumentListSettings>();

            cfg.CreateMap<InstrumentInMarginInstrumentListSettings, InstrumentInMarginInstrumentList>()
                .ForMember(x => x.TransferPlaces, opt => opt.MapFrom(y => y.TransferPlaces))
                .AfterMap((x, y) =>  y.TransferPlaces = x.TransferPlaces);

            cfg.CreateMap<InstrumentInMarginInstrumentListImport, InstrumentInMarginInstrumentList>()
                .ForMember(x => x.Id, opt => opt.MapFrom(i => i.InstrumentListId));
            
            cfg.CreateMap<MarginInstrumentListDto, MarginInstrumentList>();
            
            cfg.CreateMap<MarginInstrumentListCopyDto, MarginInstrumentList>();

            cfg.CreateMap<RiskRateDto, RiskRate>().ForMember(x => x.Id, opt => opt.Ignore());
        }
    }
}
