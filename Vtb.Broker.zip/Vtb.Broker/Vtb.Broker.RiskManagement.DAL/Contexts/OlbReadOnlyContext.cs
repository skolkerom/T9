using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class OlbReadOnlyContext : DbContextBase
    {
        public virtual DbSet<OlbSecurity> Securities { get; set; }
        public virtual DbSet<OlbSecurityType> SecurityTypes { get; set; }
        public virtual DbSet<OlbMarket> Markets { get; set; }
        public virtual DbSet<OlbMarketRiskParameter> MarketRiskParameters { get; set; }

        public OlbReadOnlyContext([NotNull] DbContextOptions options) : base(options)
        {

        }
        public OlbReadOnlyContext(string connectionString)
            :base(connectionString)
        {
        }

        public override int SaveChanges()
        {
            throw new InvalidOperationException("Context is read only");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OlbSecurity>().HasKey(s => new {s.Isin, s.ShortName, s.CbCode});
            
            base.OnModelCreating(modelBuilder);
        }
    }
}