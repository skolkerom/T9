using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class RiskManagementReadOnlyContext : RiskManagementContext
    {

        public RiskManagementReadOnlyContext([NotNull] DbContextOptions options) 
            : base(options)
        {
        }
        public RiskManagementReadOnlyContext(string connectionString)
            :base(connectionString)
        {
        }

        public override int SaveChanges()
        {            
            throw new InvalidOperationException("Context is read only");
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {   
            throw new InvalidOperationException("Context is read only");
        }
    }
}
