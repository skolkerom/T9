﻿using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class OlbReadOnlyContextFactoryDesignTime : ContextDesignTimeFactoryBase<OlbReadOnlyContext>
    {
        public OlbReadOnlyContextFactoryDesignTime() 
            : base(ConnectionStringsNames.OlbConnection)
        {
        }
    }
}