using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class ZfInstrumentTypeConfiguration : IEntityTypeConfiguration<ZfInstrumentType>
    {
        public void Configure(EntityTypeBuilder<ZfInstrumentType> modelBuilder)
        {
            modelBuilder
                .ToView("v_zfront_instrument_type", "rm");
        }
    }
}
