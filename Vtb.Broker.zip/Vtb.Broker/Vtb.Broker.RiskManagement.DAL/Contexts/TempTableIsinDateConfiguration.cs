using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class TempTableIsinDateConfiguration : IEntityTypeConfiguration<TempTableIsinDate>
    {
        public void Configure(EntityTypeBuilder<TempTableIsinDate> modelBuilder)
        {
            modelBuilder
                .ToView("#isin_date")
                .HasNoKey();
        }
    }
}
