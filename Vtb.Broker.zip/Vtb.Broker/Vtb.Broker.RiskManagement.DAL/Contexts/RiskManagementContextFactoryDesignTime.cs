﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Utils;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class RiskManagementContextFactoryDesignTime : ContextDesignTimeFactoryBase<RiskManagementContext>
    {
        public RiskManagementContextFactoryDesignTime() 
            : base(ConnectionStringsNames.DefaultConnection)
        {
        }
    }
}