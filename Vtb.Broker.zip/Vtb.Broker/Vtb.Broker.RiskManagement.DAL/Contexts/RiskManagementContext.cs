using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.Alerts.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public partial class RiskManagementContext : DbContextBase
    {
        //view
        public virtual DbSet<ActiveRiskRate> ActiveRiskRates { get; set; }
        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<MarginInstrumentRateDto> MarginInstrumentRateDtos { get; set; }
        public virtual DbSet<MarginInstrumentRate> MarginInstrumentRate { get; set; }
        //end views
 
        public virtual DbSet<Interfaces.FileDetector.Entities.FileDetector> FileDetectors { get; set; }
        public virtual DbSet<RiskRate> RiskRates { get; set; }
        public virtual DbSet<RiskRateHistory> RiskRatesHistory { get; set; }
        public virtual DbSet<MarginInstrument> MarginInstrument { get; set; }
        public virtual DbSet<MarginInstrumentHistory> MarginInstrumentHistory { get; set; }
        public virtual DbSet<MarginInstrumentImport> MarginInstrumentImport { get; set; }
        public virtual DbSet<MarginInstrumentTransferPlace> MarginInstrumentTransferPlaces { get; set; }
        public virtual DbSet<MarginInstrumentHistoryTransferPlace> MarginInstrumentHistoryTransferPlaces { get; set; }
        public virtual DbSet<MarginInstrumentList> MarginInstrumentLists { get; set; }
        public virtual DbSet<MarginInstrumentListHistory> MarginInstrumentListsHistory { get; set; }
        public virtual DbSet<InstrumentInMarginInstrumentList> InstrumentsInMarginInstrumentList { get; set; }
        public virtual DbSet<InstrumentInMarginInstrumentListHistory> InstrumentsInMarginInstrumentListHistory { get; set; }
        public virtual DbSet<InstrumentInMarginInstrumentListImport> InstrumentInMarginInstrumentImports { get; set; }
        public virtual DbSet<RiskCategory> RiskCategories { get; set; }
        public virtual DbSet<RiskCategoryHistory> RiskCategoriesHistory { get; set; }
        public virtual DbSet<RiskCategoryHistoryMarketplace> RiskCategoryHistoryMarketplace { get; set; }

        public virtual DbSet<OvernightDistribution> OvernightDistributions { get; set; }
        public virtual DbSet<OvernightDistributionOperation> OvernightDistributionOperations { get; set; }
        public virtual DbSet<OvernightDistributionPosition> OvernightDistributionPositions { get; set; }       
        public virtual DbSet<RepoOnlineSecurity> RepoOnlineSecurities { get; set; }
        public virtual DbSet<RepoOnlineCurrency> RepoOnlineCurrencies { get; set; }

        public virtual DbSet<BaseRiskCategory> BaseRiskCategories { get; set; }
        public virtual DbSet<Marketplace> Marketplaces { get; set; }
        
        public virtual DbSet<MarketData> MarketDatas { get; set; }
        
        public virtual DbSet<SecurityTypeRate> SecurityTypeRates { get; set; }
        public virtual DbSet<ZfInstrumentType> ZfInstrumentTypes { get; set; }
        public virtual DbSet<ZfInstrument> ZfInstruments { get; set; }

        public virtual DbSet<Date> Dates { get; set; }

        public virtual DbSet<RiskCategoryMarketplace> RiskCategoryMarketplaces { get; set; }
        public virtual DbSet<Board> Boards { get; set; }
        public virtual DbSet<OlbParameter> OlbParameters { get; set; }
        public virtual DbSet<Currency> Currencies { get; set; }
        public virtual DbSet<Alert> Alerts { get; set; }
        public virtual DbSet<AlertEmail> AlertEmails { get; set; }
        public virtual DbSet<AlertEmailTemplate> AlertTemplates { get; set; }
        
        public virtual DbSet<MoexRiskRateFile> MoexRiskRates { get; set; }
        
        public RiskManagementContext([NotNull] DbContextOptions options) : base(options)
        {

        }
        public RiskManagementContext(string connectionString)
            :base(connectionString)
        {
        }
        
        public RiskManagementContext()
        {
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(RiskManagementContext).Assembly);

            base.OnModelCreating(modelBuilder);
        } 
    }
}
