using Microsoft.EntityFrameworkCore;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{    
    public partial class RiskManagementContext
    {        
        public virtual DbSet<TempTableIsinDate> IsinDate { get; set; }
        
        public virtual DbSet<TempTableMarginInstrumentMarketData> MarginInstrumentMarketData { get; set; }
        
        

    }
}