using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class ZfInstrumentConfiguration : IEntityTypeConfiguration<ZfInstrument>
    {
        public void Configure(EntityTypeBuilder<ZfInstrument> modelBuilder)
        {
            modelBuilder
                .ToView("v_zfront_instrument", "rm");
        }
    }
}
