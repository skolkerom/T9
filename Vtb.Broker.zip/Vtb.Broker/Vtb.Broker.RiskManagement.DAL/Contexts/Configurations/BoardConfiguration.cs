using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class BoardConfiguration : IEntityTypeConfiguration<Board>
    {
        public void Configure(EntityTypeBuilder<Board> modelBuilder)
        {
            modelBuilder
                .HasIndex(b => b.Code)
                .IsUnique();
        }
    }
}