using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class MarginInstrumentRateDtoConfiguration : IEntityTypeConfiguration<MarginInstrumentRateDto>
    {
        public void Configure(EntityTypeBuilder<MarginInstrumentRateDto> modelBuilder)
        {
            modelBuilder
                .ToView("dto")
                .HasNoKey(); 
        }
    }
}
