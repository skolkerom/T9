﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class MarketDataConfiguration : IEntityTypeConfiguration<MarketData>
    {
        public void Configure(EntityTypeBuilder<MarketData> modelBuilder)
        {
            modelBuilder
                .ToView("v_zfront_market_data", "rm")
                .HasNoKey();
        }
    }
}