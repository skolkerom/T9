﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class MarginInstrumentRateConfiguration : IEntityTypeConfiguration<MarginInstrumentRate>
    {
        public void Configure(EntityTypeBuilder<MarginInstrumentRate> builder)
        {
            builder.HasIndex(x => x.RateDateTime);
            
            builder
                .HasOne(x => x.InstrumentInMarginInstrumentList)
                .WithMany();
        }
    }
}