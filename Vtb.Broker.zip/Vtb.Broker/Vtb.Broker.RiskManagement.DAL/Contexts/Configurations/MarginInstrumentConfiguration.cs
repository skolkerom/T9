using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class MarginInstrumentConfiguration : IEntityTypeConfiguration<MarginInstrument>
    {
        public void Configure(EntityTypeBuilder<MarginInstrument> builder)
        {
            builder
                .HasIndex(x => x.Isin)
                .HasFilter("IsDeleted = 0")
                .IsUnique();
        }
    }
}