using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class RiskCategoryMarketplaceConfiguration : IEntityTypeConfiguration<RiskCategoryMarketplace>
    {
        public void Configure(EntityTypeBuilder<RiskCategoryMarketplace> modelBuilder)
        {
            modelBuilder
                .HasOne(x => x.Marketplace)
                .WithMany()
                .HasForeignKey(x=>x.MarketplaceId)
                .HasPrincipalKey(x => x.Id)
                .OnDelete(DeleteBehavior.ClientCascade);

            modelBuilder
                .HasOne(x => x.RiskCategory)
                .WithMany(x => x.Marketplaces)
                .HasForeignKey(x => x.RiskCategoryId)
                .OnDelete(DeleteBehavior.ClientCascade);
        }
    }
}