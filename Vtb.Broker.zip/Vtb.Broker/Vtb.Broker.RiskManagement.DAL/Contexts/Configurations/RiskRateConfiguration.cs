using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class RiskRateConfiguration : IEntityTypeConfiguration<RiskRate>
    {
        public void Configure(EntityTypeBuilder<RiskRate> modelBuilder)
        {
            modelBuilder
                .HasKey(r => r.Id);

            modelBuilder
                .HasIndex(r => new { r.RateDate, r.Isin, r.Source, r.MarginInstrumentListId })
                .HasFilter("IsDeleted = 0")
                .IsUnique();

            modelBuilder
                .HasOne(x => x.MarginInstrumentList)
                .WithMany(x => x.RiskRates)
                .HasForeignKey(x => x.MarginInstrumentListId)
                .IsRequired(false);

            modelBuilder
                .HasIndex(m => m.Isin);
        }
    }
}