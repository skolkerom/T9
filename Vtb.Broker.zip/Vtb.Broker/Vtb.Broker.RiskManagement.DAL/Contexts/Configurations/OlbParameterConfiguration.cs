﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class OlbParameterConfiguration : IEntityTypeConfiguration<Broker.Domain.Entities.OlbParameter>
    {
        public void Configure(EntityTypeBuilder<OlbParameter> builder)
        {
            builder.ToView("OlbParameters", "dbo").HasNoKey();
        }
    }
}