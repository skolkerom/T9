using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class FileDetectorConfiguration : IEntityTypeConfiguration<Interfaces.FileDetector.Entities.FileDetector>
    {
        public void Configure(EntityTypeBuilder<Interfaces.FileDetector.Entities.FileDetector> modelBuilder)
        {
            modelBuilder
                .ToView("FileDetector", "rm")
                .HasNoKey();
        }
    }
}