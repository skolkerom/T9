using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class InstrumentInMarginInstrumentListConfiguration : IEntityTypeConfiguration<InstrumentInMarginInstrumentList>
    {
        public void Configure(EntityTypeBuilder<InstrumentInMarginInstrumentList> modelBuilder)
        {
            modelBuilder
                .HasIndex(r => new { r.MarginInstrumentId, r.ListId })
                .HasFilter("IsDeleted = 0")
                .IsUnique();

            modelBuilder
                .HasOne(r => r.MarginInstrument)
                .WithMany(r => r.InstrumentInMarginInstrumentLists)
                .HasForeignKey(r => r.MarginInstrumentId)
                .OnDelete(DeleteBehavior.NoAction);

            modelBuilder
                .HasOne(r => r.List)
                .WithMany(l => l.Instruments)
                .HasForeignKey(r => r.ListId)
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}