using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class ActiveRiskRateConfiguration : IEntityTypeConfiguration<ActiveRiskRate>
    {
        public void Configure(EntityTypeBuilder<ActiveRiskRate> modelBuilder)
        {
            modelBuilder
                .ToView("v_active_risk_rate", "rm")
                .HasNoKey();
        }
    }
}