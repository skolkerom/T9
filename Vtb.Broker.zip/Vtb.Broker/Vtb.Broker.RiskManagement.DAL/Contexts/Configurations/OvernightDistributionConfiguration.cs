using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class OvernightDistributionConfiguration : IEntityTypeConfiguration<OvernightDistribution>
    {
        public void Configure(EntityTypeBuilder<OvernightDistribution> builder)
        {
            builder.ToView("OvernightDistribution", "rm");
        }
    }
}