﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class RepoOnlineCurrencyConfiguration : IEntityTypeConfiguration<RepoOnlineCurrency>
    {
        public void Configure(EntityTypeBuilder<RepoOnlineCurrency> builder)
        {
            builder.HasKey(c => c.Currency);
        }
    }
}