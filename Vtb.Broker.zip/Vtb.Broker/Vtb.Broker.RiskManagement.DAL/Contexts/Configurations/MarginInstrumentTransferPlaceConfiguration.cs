using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class MarginInstrumentTransferPlaceConfiguration : IEntityTypeConfiguration<MarginInstrumentTransferPlace>
    {
        public void Configure(EntityTypeBuilder<MarginInstrumentTransferPlace> modelBuilder)
        {
            modelBuilder
                .HasOne(i => i.InstrumentInList)
                .WithMany(p => p.TransferPlaces);

            modelBuilder
                .HasOne(i => i.TransferPlace);
        }
    }
}