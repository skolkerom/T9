using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class OvernightDistributionDetailConfiguration : IEntityTypeConfiguration<OvernightDistributionOperation>
    {
        public void Configure(EntityTypeBuilder<OvernightDistributionOperation> builder)
        {
            builder.ToView("OvernightDistributionOperation", "rm");
        }
    }
}