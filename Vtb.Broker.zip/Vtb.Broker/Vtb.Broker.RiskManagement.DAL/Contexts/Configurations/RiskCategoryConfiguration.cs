using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class RiskCategoryConfiguration : IEntityTypeConfiguration<RiskCategory>
    {
        public void Configure(EntityTypeBuilder<RiskCategory> modelBuilder)
        {
            modelBuilder
                .HasOne(x => x.BaseRiskCategory)
                .WithMany();

            modelBuilder
                .HasIndex(x => x.Name)
                .HasFilter("IsDeleted = 0")
                .IsUnique(true);

            modelBuilder
                .HasIndex(x => x.Code)
                .HasFilter("IsDeleted = 0")
                .IsUnique(true);
        }
    }
}