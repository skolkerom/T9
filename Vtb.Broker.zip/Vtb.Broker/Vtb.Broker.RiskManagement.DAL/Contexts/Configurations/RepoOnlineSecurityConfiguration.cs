﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class RepoOnlineSecurityConfiguration : IEntityTypeConfiguration<RepoOnlineSecurity>
    {
        public void Configure(EntityTypeBuilder<RepoOnlineSecurity> builder)
        {
            builder.HasKey(s => new {s.InstrumentCode, s.BaseInstrumentCode});
        }
    }
}