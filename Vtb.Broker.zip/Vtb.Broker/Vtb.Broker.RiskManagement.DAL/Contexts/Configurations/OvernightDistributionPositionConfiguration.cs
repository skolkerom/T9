using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.DAL.Contexts.Configurations
{
    public class OvernightDistributionPositionConfiguration : IEntityTypeConfiguration<OvernightDistributionPosition>
    {
        public void Configure(EntityTypeBuilder<OvernightDistributionPosition> builder)
        {
            builder.ToView("OvernightDistributionPosition", "rm");
        }
    }
}