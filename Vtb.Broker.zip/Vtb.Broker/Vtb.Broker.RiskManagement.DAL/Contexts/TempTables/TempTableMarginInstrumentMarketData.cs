﻿using System.ComponentModel.DataAnnotations;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class TempTableMarginInstrumentMarketData
    { 
        public string Ticker { get; set; }
        public double? ClosePrice { get; set; }
    }
}