﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Vtb.Broker.RiskManagement.DAL.Contexts
{
    public class TempTableMarginInstrumentMarketDataConfiguration : IEntityTypeConfiguration<TempTableMarginInstrumentMarketData>
    {
        public void Configure(EntityTypeBuilder<TempTableMarginInstrumentMarketData> modelBuilder)
        {
            modelBuilder
                .ToView("#TempTableMarginInstrumentMarketData")
                .HasNoKey();
        }
    }
}