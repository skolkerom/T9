using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Vtb.Broker.RiskManagement.DAL
{
    /// <summary>
    /// DTO for rm.sp_get_margin_instrument_rates
    /// </summary>
    public class MarginInstrumentRateDto
    {
        public long InstrumentListId { get; set; }
        public string Isin { get; set; }
        
        [Column(TypeName = "decimal(19,8)")]
        public decimal? RateShort { get; set; }
        
        [Column(TypeName = "decimal(19,8)")]
        public decimal? RateLong { get; set; }
        
        [Column(TypeName = "decimal(19,8)")]
        public decimal? RateShortStandart { get; set; }
        
        [Column(TypeName = "decimal(19,8)")]
        public decimal? RateLongStandart { get; set; }
        public DateTime RateDate { get; set; }
    }
}
