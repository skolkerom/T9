﻿using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Jobs;
using Vtb.Broker.OptimalRepoCalculator.Services;

namespace Vtb.Broker.OptimalRepoCalculator.Jobs
{
    public class RepoOnlineDataJob : IJob
    {
        private readonly RepoOnlineDataSaver _repoOnlineDataSaver;

        public RepoOnlineDataJob(RepoOnlineDataSaver repoOnlineDataSaver)
        {
            _repoOnlineDataSaver = repoOnlineDataSaver;
        }
        
        public async Task Execute(JobContext context)
        {
            await _repoOnlineDataSaver.Save();
        }
    }
}