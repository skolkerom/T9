﻿using System;
using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Jobs;
using Vtb.Broker.OptimalRepoCalculator.Services;
using IJob = Vtb.Broker.Interfaces.Jobs.IJob;

namespace Vtb.Broker.OptimalRepoCalculator.Jobs
{
    public class CreateOvernightDistrubutionJob : IJob
    {
        private readonly Orchestrator _orchestrator;

        public CreateOvernightDistrubutionJob(Orchestrator orchestrator)
        {
            _orchestrator = orchestrator;
        }
        
        public async Task Execute(JobContext context)
        {
            await _orchestrator.GenerateRepoOperationsAndSaveResults(DateTime.Now.Date);
        }
    }
}