﻿namespace Vtb.Broker.OptimalRepoCalculator.DAL
{
    public class CurrencyRepoRate
    {
        public string ClientCode { get; set; }
        public decimal SumFrom { get; set; }
        public decimal SumTo { get; set; }
        public int? SecurityTypeId { get; set; }
        public int? SecurityTypeRate { get; set; }
        public decimal Part1Value { get; set; }
        public decimal Part2Value { get; set; }
        public string PaymCurrISO { get; set; }
        public string InstrKod { get; set; }
        public string TypeCode { get; set; }
    }
}