using System;
using System.ComponentModel.DataAnnotations.Schema;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.OptimalRepoCalculator.DAL
{
    public class Position
    {
        public string ClientCode { get; set; }
        public string CurrencyCode { get; set; }

        public string InstrumentCode { get; set; }

        public int InstrumentId { get; set; }
        
        public int StorageId { get; set; }

        public TypeInstrument TypeInstrument { get; set; }

        [NotMapped]
        public OvernightDistributionInstrumentType InstrumentType => 
            TypeInstrument == TypeInstrument.Security 
                ? OvernightDistributionInstrumentType.Security
                : OvernightDistributionInstrumentType.Currency;

        public decimal Remain { get; set; }

        public DateTime DatePart1 { get; set; }

        public DateTime DatePart2 { get; set; }

        public decimal? NKDPart1 { get; set; }

        public decimal? NKDPart2 { get; set; }
        
        public string ClientType { get; set; }

        [NotMapped]
        public bool IsIndividualInvestmentAccount => ClientType == "I";
    }
}