﻿using System.Linq;
using System.Threading.Tasks;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Commands
{
    public class RepoCommandRepository : IRepoCommandRepository
    {
        private readonly IContextFactory<Context> _contextFactory;

        public RepoCommandRepository(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public async Task Save<T>(T[] repoData) where T : class
        {
            await using var context = _contextFactory.Create();

            await using var tran = await context.Database.BeginTransactionAsync();

            if (!repoData.Any())
                await context.BulkDeleteAsync(await context.Set<T>().ToListAsync());
            else 
                await context.BulkInsertOrUpdateOrDeleteAsync(repoData, x => x.UseTempDB = true);
            
            await tran.CommitAsync();
        }
    }

    public interface IRepoCommandRepository
    {
        Task Save<T>(T[] repoData) where T : class;
    }
}