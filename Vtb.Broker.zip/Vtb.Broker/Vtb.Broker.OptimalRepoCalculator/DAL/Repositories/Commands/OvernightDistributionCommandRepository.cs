using System.Threading.Tasks;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Commands
{
    public interface IOvernightDistributionCommandRepository
    {
        Task Save(OvernightDistribution distribution);
        Task Save(OvernightDistributionOperation[] details);
        Task Save(OvernightDistributionPosition[] positions);
        Task MapDistributionsToZFrontOperations(long requestId);
    }

    public class OvernightDistributionCommandRepository : IOvernightDistributionCommandRepository
    {
        private readonly IContextFactory<Context> _contextFactory;

        public OvernightDistributionCommandRepository(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public async Task Save(OvernightDistribution distribution)
        {
            await using var context =  _contextFactory.Create();
            context.AttachRootEntityToContext(distribution);

            await context.SaveChangesAsync();
        }

        public async Task Save(OvernightDistributionOperation[] details)
        {
            await using var context =  _contextFactory.Create();
            
            await context.BulkInsertAsync(details);
        }

        public async Task Save(OvernightDistributionPosition[] positions)
        {
            await using var context =  _contextFactory.Create();
            
            await context.BulkInsertAsync(positions);
        }

        public async Task MapDistributionsToZFrontOperations(long requestId)
        {
            await using var context = _contextFactory.Create();

            await context.Database.ExecuteSqlInterpolatedAsync($"exec [rm].sp_zfront_generate_optimal_repo_operations @requestId={requestId}");
        }
    }
}