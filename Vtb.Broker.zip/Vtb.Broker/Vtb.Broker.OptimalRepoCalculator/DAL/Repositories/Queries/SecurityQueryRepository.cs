using System;
using System.Threading.Tasks;
using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries
{
    public interface ISecurityQueryRepository
    {
         Task<Security[]> GetSecurities(DateTime date);
    }
    public class SecurityQueryRepository : ISecurityQueryRepository
    {
        private readonly IContextFactory<Context> _contextFactory;

        public SecurityQueryRepository(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<Security[]> GetSecurities(DateTime date)
        {
            await using var context = _contextFactory.Create();

            return await context.GetSecurities(date);
        }
    }
}