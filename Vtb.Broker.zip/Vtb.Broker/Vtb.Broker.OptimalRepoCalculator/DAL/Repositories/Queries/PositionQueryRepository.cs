using System;
using System.Threading.Tasks;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries
{
    public interface IPositionQueryRepository
    {
         Task<InstrumentPosition[]> GetInstrumentPositions(string clientCode, DateTime date);
    }
    public class PositionQueryRepository : IPositionQueryRepository
    {
        private readonly IContextFactory<Context> _contextFactory;

        public PositionQueryRepository(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<InstrumentPosition[]> GetInstrumentPositions(string clientCode, DateTime date)
        {
            await using var context = _contextFactory.Create();

            return await context.GetInstrumentPositions(clientCode, date);
        }
    }
}