﻿using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.OptimalRepoCalculator.Services;

namespace Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries
{
    public interface IRepoQueryRepository
    {
        Task<OvernightDistribution> GetRepoData(DateTime date, string clientCode, int? requestId);
    }
    
    public class RepoQueryRepository : IRepoQueryRepository
    {
        private readonly IPositionQueryRepository _positionQueryRepository;
        private readonly ICurrencyRateQueryRepository _currencyRateQueryRepository;
        private readonly OvernightDistributionGenerator _overnightDistributionGenerator;

        public RepoQueryRepository(IPositionQueryRepository positionQueryRepository,
            ICurrencyRateQueryRepository currencyRateQueryRepository,
            OvernightDistributionGenerator overnightDistributionGenerator)
        {
            _positionQueryRepository = positionQueryRepository;
            _currencyRateQueryRepository = currencyRateQueryRepository;
            _overnightDistributionGenerator = overnightDistributionGenerator;
        }
        
        public async Task<OvernightDistribution> GetRepoData(DateTime date, string clientCode, int? requestId)
        {
            var instrumentPositions = await _positionQueryRepository.GetInstrumentPositions(clientCode, date);

            var rates = await _currencyRateQueryRepository.GetRates();

            var overnightDistribution = _overnightDistributionGenerator.GenerateOvernightDistribution(date, instrumentPositions, rates, requestId);
            return overnightDistribution;
        }
    }
}