﻿using System.Linq;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries
{
    public interface ICurrencyRateQueryRepository
    {
        Task<Rate[]> GetRates();
    }
    
    public class CurrencyRateQueryRepository : ICurrencyRateQueryRepository
    {
        private readonly IContextFactory<Context> _contextFactory;

        public CurrencyRateQueryRepository(IContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        public async Task<Rate[]> GetRates()
        {
            await using var context = _contextFactory.Create();

            var ratesFromDb = await context.GetCurrencyRepoRates();
            
            static bool IsCurrencyRate(CurrencyRepoRate rate) => rate.TypeCode == "DS_SHORT";
            static bool IsSecurityRate(CurrencyRepoRate rate) => rate.TypeCode == "CURR_CB_LONG";

            var rates = ratesFromDb.Select(x => new Rate
                {
                    Rate1 = x.Part1Value / 100M,
                    Rate2 = x.Part2Value / 100M,
                    ClientCode = x.ClientCode,
                    PaymentCurrency = IsCurrencyRate(x) ? null : x.PaymCurrISO,
                    VolumeFrom = IsCurrencyRate(x) ? -x.SumTo : x.SumFrom,
                    VolumeTo = IsCurrencyRate(x) ? -x.SumFrom : x.SumTo,
                    TariffId = x.SecurityTypeRate == 0 ? null : x.SecurityTypeRate,
                    InstrumentType = IsSecurityRate(x)
                        ? OvernightDistributionInstrumentType.Security
                        : IsCurrencyRate(x)
                            ? OvernightDistributionInstrumentType.Currency
                            : OvernightDistributionInstrumentType.None
                })
                .Where(x => x.InstrumentType != OvernightDistributionInstrumentType.None)
                .ToArray();

            return rates;
        }
    }
}