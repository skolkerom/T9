﻿using Vtb.Broker.Infrastructure.EF;

namespace Vtb.Broker.OptimalRepoCalculator.DAL
{
    public class ContextFactoryDesignTime : ContextDesignTimeFactoryBase<Context>
    {
        public ContextFactoryDesignTime() 
            : base(ConnectionStringsNames.DefaultConnection)
        {
        }
    }
}