namespace Vtb.Broker.OptimalRepoCalculator.DAL
{
    public enum TypeInstrument : byte
    {
        CurrencyRub = 0,
        CurrencyOther = 1,
        CurrencyObligation = 2,
        Security = 3
    }
}