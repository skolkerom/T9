using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;
using Vtb.Broker.Utils;

namespace Vtb.Broker.OptimalRepoCalculator.DAL
{
    public class Context : DbContextBase
    {
        public virtual DbSet<Position> Positions { get; set; }
        public virtual DbSet<Security> Securities { get; set; }
        public virtual DbSet<CurrencyRepoRate> CurrencyRepoRates { get; set; }

        public virtual DbSet<OvernightDistribution> OvernightDistributions { get; set; }
        public virtual DbSet<OvernightDistributionOperation> OvernightDistributionDetails { get; set; }
        public virtual DbSet<OvernightDistributionPosition> OvernightDistributionPositions { get; set; }
        public virtual DbSet<RepoOnlineSecurity> RepoOnlineSecurities { get; set; }
        public virtual DbSet<RepoOnlineCurrency> RepoOnlineCurrencies { get; set; }

        public Context(DbContextOptions options) : base(options)
        {
        }

        public Context(string connectionString) : base(connectionString)
        {
        }

        public async Task<CurrencyRepoRate[]> GetCurrencyRepoRates()
        {
            var timeout = 30 * 60;
            var dboVnRepoRate = "dbo.VN_REPO_Rate";
            
            try
            {
                Database.SetCommandTimeout(timeout);

                var items = await CurrencyRepoRates.FromSqlInterpolated($"{dboVnRepoRate}").ToArrayAsync();

                items = items.ToArray();

                return items;
            }
            catch (SqlException e) when (e.Message.StartsWith("Execution Timeout Expired"))
            {
                throw new Exception($"Превышение таймаута({timeout} секунд) при вызове процедуры {dboVnRepoRate}");
            }
        }

        public async Task<InstrumentPosition[]> GetInstrumentPositions(string clientCode, DateTime date)
        {
            var positions = await GetPositions(clientCode, date);
            var securities = (await GetSecurities(date)).ToLookup(x => x.InstrumentCode);

            var instrumentPositions = positions.Select(x =>
            {
                var security = securities[x.InstrumentCode].FirstOrDefault();

                if (x.InstrumentCode == "RUR")
                    return new InstrumentPosition
                    {
                        Instrument = new Instrument
                        {
                            InstrumentCode = x.InstrumentCode,
                            CurrencyCode = x.CurrencyCode,
                            Repo1Date = x.DatePart1,
                            Repo2Date = x.DatePart2,
                            Price = 1,
                            FxRate = 1,
                            InstrumentType = OvernightDistributionInstrumentType.Currency,
                            ExcludeForIndividualInvestmentAccount = security?.IssExclude ?? false 
                        },
                        StorageId = x.StorageId,
                        Quantity = x.Remain,
                        ClientCode = x.ClientCode,
                        IsIndividualInvestmentAccount = x.IsIndividualInvestmentAccount
                    };

                if (security == null)
                    return null;

                var price = security.IsPercentPrice
                    ? security.Nominal * (security.AmortizationFactor1 ?? 1) * security.AveragePriceLong / 100
                    : security.AveragePriceLong;

                var instrument = new InstrumentPosition
                {
                    Instrument = new Instrument
                    {
                        InstrumentCode = x.InstrumentCode,
                        CurrencyCode = x.CurrencyCode,
                        Repo1Date = x.DatePart1,
                        Repo2Date = x.DatePart2,
                        Price = x.TypeInstrument != TypeInstrument.Security
                            ? 1
                            : price ?? 0,
                        FxRate = security.CcyRate ?? 1,
                        InstrumentType = x.InstrumentType,
                        TariffId = security.TypeRateRepo == 0 ? null : security.TypeRateRepo,
                        Nkd1 = x.NKDPart1,
                        Nkd2 = x.NKDPart2,
                        ExcludeForIndividualInvestmentAccount = security.IssExclude
                    },
                    StorageId = x.StorageId,
                    Quantity = x.Remain,
                    ClientCode = x.ClientCode,
                    IsIndividualInvestmentAccount = x.IsIndividualInvestmentAccount
                };

                return instrument;
            })
                .Where(x => x != null && 
                            (x.Instrument.InstrumentType == OvernightDistributionInstrumentType.Security && x.Instrument.TariffId != null ||
                             x.Instrument.InstrumentType == OvernightDistributionInstrumentType.Currency))
                .ToArray();

            return instrumentPositions;
        }
        
        public async Task<Position[]> GetPositions(string clientCode, DateTime date)
        {
            var timeout = 30 * 60;
            var dboVnRepoRemain = "dbo.VN_REPO_Remain";

            try
            {
                Database.SetCommandTimeout(timeout);
                
//            var items = await Positions.FromSqlInterpolated($@"select '74475270' as ClientCode, '840' as CurrencyCode, 'USD' as InstrumentCode, 247791 as InstrumentId, 0 as StorageId, cast (1 as tinyint) as TypeInstrument,  cast(-74167.34 as decimal(19,8)) as Remain, cast ('20200207' as date) as DatePart1, cast('20200210' as date) as DatePart2, 16.09722200 as NKDPart1, 16.88888900 as  NKDPart2, null as ClientType union all
//            select '74475270' as ClientCode, '810' as CurrencyCode, 'RUR' as InstrumentCode, 0 as InstrumentId, 0 as StorageId, '0' as TypeInstrument,  241577.22 as Remain, '20200207' as DatePart1, '20200210' as DatePart2, null as NKDPart1, null as NKDPart2, null as ClientType union all
//            select '74475270' as ClientCode, '840' as CurrencyCode, 'XS0810596832' as InstrumentCode, 213666 as InstrumentId, 1 as StorageId, '3' as TypeInstrument,  1220.00 as Remain, '20200207' as DatePart1, '20200210' as DatePart2, null as NKDPart1, null as NKDPart2, null as ClientType union all
//            select '74475270' as ClientCode, '978' as CurrencyCode, 'EUR' as InstrumentCode, 247792 as InstrumentId, 0 as StorageId, '1' as TypeInstrument,  -249572.00 as Remain, '20200207' as DatePart1, '20200210' as DatePart2, null as NKDPart1, null as NKDPart2, null as ClientType").ToArrayAsync();

                var items = await Positions
                    .FromSqlInterpolated($"{dboVnRepoRemain} @deal_date = {date}, @client_code = {clientCode}")
                    .ToArrayAsync();


                if (clientCode != null)
                    items = items.Where(x => x.ClientCode == clientCode).ToArray();

                var positions = EnumerableExtensions.ForEachEx(items,
                        x =>
                        {
                            if (x.TypeInstrument != TypeInstrument.Security)
                                x.InstrumentCode = x.InstrumentCode.Substring(0, 3);
                        })
                    .GroupBy(x => new {x.ClientCode, x.InstrumentCode, x.InstrumentId, x.StorageId})
                    .SelectMany(x =>
                    {
                        var ti0 = x.FirstOrDefault(z => z.TypeInstrument == TypeInstrument.CurrencyRub ||
                                                        z.TypeInstrument == TypeInstrument.CurrencyOther);

                        if (ti0 == null)
                            return x.ToArray();

                        var result = ti0.Remain < 0
                            ? new[]
                            {
                                new Position
                                {
                                    ClientCode = x.Key.ClientCode,
                                    InstrumentCode = x.Key.InstrumentCode,
                                    InstrumentId = x.Key.InstrumentId,
                                    StorageId = x.Key.StorageId,
                                    CurrencyCode = ti0.CurrencyCode,
                                    DatePart1 = ti0.DatePart1,
                                    DatePart2 = ti0.DatePart2,
                                    NKDPart1 = ti0.NKDPart1,
                                    NKDPart2 = ti0.NKDPart2,
                                    Remain = x.Sum(r => r.Remain),
                                    TypeInstrument = ti0.TypeInstrument,
                                    ClientType = ti0.ClientType
                                }
                            }
                            : new[] {ti0};

                        return result;
                    })
                    .Where(x => x.InstrumentType == OvernightDistributionInstrumentType.Security && x.Remain > 0 ||
                                x.InstrumentType == OvernightDistributionInstrumentType.Currency && x.Remain < 0 &&
                                x.InstrumentCode != "RUR" ||
                                x.InstrumentType == OvernightDistributionInstrumentType.Currency && x.Remain > 0 &&
                                x.InstrumentCode == "RUR")
                    .ToArray();

                return positions;
            }
            catch (SqlException e) when (e.Message.StartsWith("Execution Timeout Expired"))
            {
                throw new Exception($"Превышение таймаута({timeout} секунд) при вызове процедуры {dboVnRepoRemain}");
            }
        }

        public async Task<Security[]> GetSecurities(DateTime date)
        {
            var timeout = 60 * 30;
            var dboVnRepoSecurities = "dbo.VN_REPO_Securities";
            
            try
            {
                Database.SetCommandTimeout(timeout);

                
                var items = await Securities.FromSqlInterpolated($"{dboVnRepoSecurities} @date = {date}")
                    .ToArrayAsync();

                return items;
            }
            catch (SqlException e) when (e.Message.StartsWith("Execution Timeout Expired"))
            {
                throw new Exception($"Превышение таймаута({timeout} секунд) при вызове процедуры {dboVnRepoSecurities}");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Position>().ToView("fake_view_positions").HasNoKey();
            modelBuilder.Entity<Security>().ToView("fake_view_securities").HasNoKey();
            modelBuilder.Entity<CurrencyRepoRate>().ToView("fake_view_currencyRepoRate").HasNoKey();

            modelBuilder.Entity<OvernightDistributionOperation>()
                .HasOne(x => x.OvernightDistribution)
                .WithMany(x => x.OvernightDistributionOperations)
                .HasForeignKey(x => x.OvernightDistributionId)
                .IsRequired();

            modelBuilder.Entity<OvernightDistributionPosition>()
                .HasOne(x => x.OvernightDistribution)
                .WithMany(x => x.OvernightDistributionPositions)
                .HasForeignKey(x => x.OvernightDistributionId)
                .IsRequired();
            
            modelBuilder.Entity<OvernightDistribution>()
                .HasIndex(x => x.RequestId)
                .HasFilter("RequestId is not null")
                .IsUnique();

            modelBuilder.Entity<RepoOnlineSecurity>()
                .HasKey(s => new {s.InstrumentCode, s.BaseInstrumentCode});

            modelBuilder.Entity<RepoOnlineCurrency>()
                .HasKey(c => c.Currency);
        }
    }
}