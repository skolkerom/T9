using System;

namespace Vtb.Broker.OptimalRepoCalculator.DAL
{
    public class Security
    {
        public int InstrumentId { get; set; }
        public string InstrumentCode { get; set; }
        public bool IsPercentPrice { get; set; }

        public decimal? AveragePriceShort { get; set; }
        public DateTime? AveragePriceDateShort { get; set; }
        public decimal? AveragePriceLong { get; set; }

        public DateTime? AveragePriceDateLong { get; set; }
        public DateTime? DealPart2ValueDate { get; set; }
        public string Ccy { get; set; }

        public decimal? CcyRate { get; set; }

        public decimal? Nominal { get; set; }

        public decimal? AmortizationFactor1 { get; set; }

        public decimal? AmortizationFactor2 { get; set; }

        public decimal? NkdAtPart1ValueDate { get; set; }

        public decimal? NkdAtPart2ValueDate { get; set; }

        public bool IsCurrencyMarket { get; set; }
        
        public bool IssExclude { get; set; }
        
        public int? TypeRateRepo { get; set; }
    }
}