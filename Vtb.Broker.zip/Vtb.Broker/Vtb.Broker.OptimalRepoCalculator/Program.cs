﻿using Vtb.Broker.Infrastructure.Host;
using Vtb.Broker.Interfaces.EndpointProvider;
using Vtb.Broker.OptimalRepoCalculator.DAL;

namespace Vtb.Broker.OptimalRepoCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Bootstrap.Run<Startup, Context>(args, Endpoints.OptimalRepoCalculator, new ContextFactoryDesignTime());
        }
    }
}
