using System;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.Interfaces.UnitOfWork;
using Vtb.Broker.OptimalRepoCalculator.DAL;

namespace Vtb.Broker.OptimalRepoCalculator
{
    public class OptimalRepoUnitOfWork : UnitOfWork<Context>, IUnitOfWork
    {
        public OptimalRepoUnitOfWork(IServiceProvider serviceProvider) : base(serviceProvider)
        {
        }
    }
}
