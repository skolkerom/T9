﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vtb.Broker.OptimalRepoCalculator
{
    public static class TupleExtensions
    {
        public static string TupleToString(this (double, List<(string, int)>) t)
        {
            var (d, l) = t;
            return d.ToString() + " " + l.Aggregate("", (s, i) => s + i.ToString()); 
        }
    }
}
