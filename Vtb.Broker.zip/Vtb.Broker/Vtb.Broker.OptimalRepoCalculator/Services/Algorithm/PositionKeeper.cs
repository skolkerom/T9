﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class PositionKeeper
    {
        private readonly Dictionary<PositionKey, InstrumentPosition> _positionsDict;

        public PositionKeeper(InstrumentPosition[] instrumentPositions)
        {
            _positionsDict = instrumentPositions.ToDictionary(PositionKey.FromInstrumentPosition);
        }

        public void ApplyTransactions(InstrumentSelectorResult[] transactions)
        {
            foreach (var transaction in transactions)
            {
                ApplyTransaction(transaction);
            }
        }

        public void ApplyTransaction(InstrumentSelectorResult transaction)
        {
            _positionsDict[PositionKey.FromInstrumentPosition(transaction.InstrumentPosition)].Quantity -= transaction.Quantity;

            _positionsDict[PositionKey.FromInstrumentPosition(transaction.BaseInstrumentPosition)].Quantity
                += Math.Round(
                    transaction.Quantity * transaction.InstrumentPosition.Instrument.PriceWithNkd1InRUR /
                    transaction.BaseInstrumentPosition.Instrument.FxRate,
                    2, MidpointRounding.AwayFromZero);


            _positionsDict[PositionKey.FromInstrumentPosition(transaction.BaseInstrumentPosition)].Quantity -=
                Math.Round(transaction.Quantity * transaction.InstrumentPosition.Instrument.GetEffectiveRate(transaction.Rate.Rate2) *
                           transaction.InstrumentPosition.Instrument.PriceWithNkd1InRUR
                           / transaction.BaseInstrumentPosition.Instrument.FxRate, 2, MidpointRounding.AwayFromZero);
        }

        public Dictionary<PositionKey, InstrumentPosition> Positions => _positionsDict;
    }
}