using System.Diagnostics;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    [DebuggerDisplay("ClientCode = {ClientCode}, InstrumentCode = {InstrumentCode}, Currency = {Currency}")]
    public class PositionKey
    {
        public string ClientCode { get;  }
        public string InstrumentCode { get; }
        public string Currency { get;  }
        
        public int StorageId { get;  }

        public PositionKey(string clientCode, string instrumentCode, string currency, int storageId)
        {
            ClientCode = clientCode;
            InstrumentCode = instrumentCode;
            Currency = currency;
            StorageId = storageId;
        }

        public static PositionKey FromInstrumentPosition(InstrumentPosition position)
        {
            return new PositionKey(position.ClientCode, position.Instrument.InstrumentCode,
                position.Instrument.CurrencyCode, position.StorageId);
        }

        public override bool Equals(object obj)
        {
            var other = obj as PositionKey;
            
            if (other == null)
                return false;

            return other.ClientCode == ClientCode &&
                other.InstrumentCode == InstrumentCode &&
                other.Currency == Currency &&
                other.StorageId == StorageId;
        }

        public override int GetHashCode()
        {
            return ClientCode.GetHashCode() ^
                InstrumentCode.GetHashCode() ^
                Currency.GetHashCode() ^ 
                StorageId.GetHashCode();
        }
    }
}
