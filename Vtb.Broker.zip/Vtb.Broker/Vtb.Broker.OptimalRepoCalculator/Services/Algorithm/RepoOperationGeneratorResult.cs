﻿using System.Collections.Generic;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class RepoOperationGeneratorResult
    {
        public InstrumentSelectorResult[] CalcResults { get; set; }

        public Dictionary<PositionKey, InstrumentPosition> Positions { get; set; }

        public string ClientCode { get; set; }
    }
}