﻿using System.Collections.Generic;
using System.Linq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.OptimalRepoCalculator.DAL;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class RepoOperationGenerator
    {
        private readonly InstrumentSelector _instrumentSelector;

        public RepoOperationGenerator(InstrumentSelector instrumentSelector)
        {
            _instrumentSelector = instrumentSelector;
        }

        public RepoOperationGeneratorResult GenerateRepoOperations(InstrumentPosition[] instruments,
            RateProvider ratesProvider, string clientCode)
        {
            var positionKeeper = new PositionKeeper(instruments);
            
            var result = new List<InstrumentSelectorResult>();

            bool operationGenerated;

            do
            {
                operationGenerated = false;
                
                foreach (var i in instruments.Where(x => x.Quantity < 0 && 
                                                         x.Instrument.InstrumentType != OvernightDistributionInstrumentType.Security))
                {
                    var iterationResult = _instrumentSelector
                        .SelectInstruments(clientCode, instruments, ratesProvider, i.Instrument.InstrumentCode);

                    if (iterationResult.Length > 0)
                    {
                        operationGenerated = true;
                        result.AddRange(iterationResult);
                    }

                    positionKeeper.ApplyTransactions(iterationResult);
                }
            } while (operationGenerated);

            var aggregatedOperations = (from r in result
                group r by new
                {
                    BaseInstrumentPosKey  = PositionKey.FromInstrumentPosition(r.BaseInstrumentPosition), 
                    InstrumentPosKey = PositionKey.FromInstrumentPosition(r.InstrumentPosition), 
                    r.Rate
                }
                into grp
                select new InstrumentSelectorResult
                {
                    Quantity = grp.Sum(x => x.Quantity),
                    Rate = grp.Key.Rate,
                    InstrumentPosition = grp.Last().InstrumentPosition,
                    BaseInstrumentPosition = grp.Last().BaseInstrumentPosition
                }).ToArray();

            return new RepoOperationGeneratorResult
            {
                CalcResults = aggregatedOperations,
                Positions = positionKeeper.Positions
            };
        }
    }
}