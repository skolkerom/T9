﻿using System.Diagnostics;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    [DebuggerDisplay("Rate1 = {Rate1}, Rate2 = {Rate2}, VolumeFrom = {VolumeFrom}, VolumeTo = {VolumeTo}, ClientCode = {ClientCode}, PaymentCurrency = {PaymentCurrency}, InstrumentType = {InstrumentType}, TariffId = {TariffId}")]
    public class Rate
    {
        public decimal Rate1 { get; set; }
        public decimal Rate2 { get; set; }
        
        public decimal VolumeFrom { get; set; }
        public decimal VolumeTo { get; set; }
        
        public string ClientCode { get; set; }
        public string PaymentCurrency { get; set; }
        
        public int? TariffId { get; set; }
        
        public OvernightDistributionInstrumentType InstrumentType { get; set; }

        public override string ToString()
        {
            return
                $"InstrumentType = {InstrumentType} Rate1 = {Rate1} Rate2 = {Rate2} VolumeFrom = {VolumeFrom} VolumeTo = {VolumeTo} ClientCode = {ClientCode} PaymentCurrency = {PaymentCurrency} TariffId = {TariffId}";
        }
    }
}