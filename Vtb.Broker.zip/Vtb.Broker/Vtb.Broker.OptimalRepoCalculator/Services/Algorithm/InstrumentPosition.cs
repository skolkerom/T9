﻿using System;
using System.Diagnostics;
using Microsoft.AspNetCore.DataProtection.AuthenticatedEncryption;
using Vtb.Broker.OptimalRepoCalculator.DAL;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    [DebuggerDisplay("Instrument = {Instrument.InstrumentCode}, Quantity = {Quantity}")]
    public class InstrumentPosition
    {
        public string ClientCode { get; set; }
        public Instrument Instrument { get; set; }
        
        public int StorageId { get; set; }
        
        public bool IsIndividualInvestmentAccount { get; set; }

        private decimal _quantity;

        public decimal Quantity
        {
            get => _quantity;
            set
            {
                //if (Math.Round(value, 2) != value)
                //    throw new Exception("Quantity has precision = 2");
                
                _quantity = value;
            }
        }
    }
}
