﻿using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class RateKey
    {
        public string ClientCode { get; set; }
        public OvernightDistributionInstrumentType InstrumentType { get; set; }
        public string Currency { get; set; }
        
        public decimal? Volume { get; set; }
        public int? TariffId { get; set; }
    }
}