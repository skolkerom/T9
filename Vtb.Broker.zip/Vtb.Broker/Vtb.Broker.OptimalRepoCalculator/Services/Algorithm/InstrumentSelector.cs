using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Interfaces.Mapper;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class InstrumentSelector
    {
        private readonly IMapperService _mapper;

        public InstrumentSelector(IMapperService mapper)
        {
            _mapper = mapper;
        }
 
        public InstrumentSelectorResult[] SelectInstruments(string clientCode, InstrumentPosition[] instruments, RateProvider rateProvider, string currency)
        {
            var instrumentsCopies = instruments.Select(x => _mapper.Map<InstrumentPosition>(x)).ToArray();

            var baseInstrument = instrumentsCopies.First(x => x.Instrument.InstrumentCode == currency);
            var notCurrencyInstruments = instrumentsCopies
                .Where(x =>
                {
                    if (x.Instrument.InstrumentType == OvernightDistributionInstrumentType.Currency &&
                        x.Instrument.InstrumentCode != "RUR")
                        return false;
                    
                    if (baseInstrument.IsIndividualInvestmentAccount &&
                        x.Instrument.ExcludeForIndividualInvestmentAccount)
                        return false;
                    
                    return x.Instrument.InstrumentCode != currency;
                })
                .ToArray();

            var sumToCover = Math.Round(-baseInstrument.Quantity * baseInstrument.Instrument.FxRate, 2, MidpointRounding.AwayFromZero);

            var instrDict = new Dictionary<InstrumentPosition, decimal>();

            foreach (var instrument in notCurrencyInstruments)
                instrDict[instrument] = 0;

            InstrumentPosition lastBestInstrumentPosition = null;

            var ratesDict =
                notCurrencyInstruments.ToDictionary(x => x, x => rateProvider.GetRate(
                    new RateKey
                    {
                        ClientCode = clientCode,
                        InstrumentType = x.Instrument.InstrumentType,
                        Currency = currency,
                        TariffId = x.Instrument.TariffId
                    }));
            
            while (sumToCover > 0)
            {
                // нет смысла перекрывать меньше одного цента, мы не можем создавать такие операции
                if (sumToCover < baseInstrument.Instrument.LotSize * baseInstrument.Instrument.FxRate)
                    sumToCover = baseInstrument.Instrument.LotSize * baseInstrument.Instrument.FxRate;
                        
                var bestInstrument = notCurrencyInstruments
                    .Where(x=>x.Quantity * x.Instrument.PriceWithNkd1InRUR / baseInstrument.Instrument.FxRate >= baseInstrument.Instrument.LotSize)
                    .OrderBy(x =>
                    {
                        var rate = ratesDict[x];
                        var commission = x.Instrument.CalculateMinimalCommission(sumToCover, rate.Rate1 + rate.Rate2);
                        return commission;
                    })
                    .FirstOrDefault();

                if (bestInstrument == null)
                    break;

                var priceInCurrency = bestInstrument.Instrument.PriceWithNkd1InRUR;

                var qToCover = lastBestInstrumentPosition == bestInstrument
                    ? (sumToCover / priceInCurrency).Ceiling(bestInstrument.Instrument.LotSize)
                    : (sumToCover / priceInCurrency).Floor(bestInstrument.Instrument.LotSize);

                var minQToCover = Math.Min(qToCover, bestInstrument.Quantity);

                sumToCover = Math.Round(sumToCover - minQToCover * priceInCurrency, 2, MidpointRounding.AwayFromZero);
                bestInstrument.Quantity -= minQToCover;

                lastBestInstrumentPosition = bestInstrument;
                instrDict[bestInstrument] += minQToCover;
            }


            foreach (var item in instrDict
                .Where(x => x.Value > 0)
                .OrderByDescending(x =>
                {
                    var rate = ratesDict[x.Key];
                    return x.Key.Instrument.CalculateMinimalCommission(Math.Abs(sumToCover),
                        rate.Rate1 + rate.Rate2);
                }))
            {
                if (sumToCover >= 0)
                    break;

                var priceInCurrency = item.Key.Instrument.PriceWithNkd1InRUR;

                var baseInstrumentLot = baseInstrument.Instrument.LotSize * baseInstrument.Instrument.FxRate;

                var qToCover = (Math.Abs(sumToCover) / priceInCurrency).Floor(item.Key.Instrument.LotSize);
                var minQToCover = Math.Min(qToCover, item.Value);

                var newInstrQty = instrDict[item.Key] - minQToCover;
                // если после снятия остается меньше одного цента в перекрываемой валюте 
                if (newInstrQty > 0 && newInstrQty * item.Key.Instrument.PriceWithNkd1InRUR < baseInstrumentLot)
                {
                    var safeSum = sumToCover - baseInstrument.Instrument.LotSize * baseInstrument.Instrument.FxRate;

                    if (safeSum <= 0)
                        continue;

                    qToCover = (Math.Abs(safeSum) / priceInCurrency).Floor(item.Key.Instrument.LotSize);
                    minQToCover = Math.Min(qToCover, item.Value);
                    newInstrQty = instrDict[item.Key] - minQToCover;
                }

                instrDict[item.Key] = newInstrQty;

                item.Key.Quantity += minQToCover;
                sumToCover = Math.Round(sumToCover + minQToCover * priceInCurrency, 2,
                    MidpointRounding.AwayFromZero);
            }

            return instrDict
                .Where(x => x.Value > 0)
                .Select(x =>
                {
                    var volume = Math.Round(x.Value * x.Key.Instrument.PriceWithNkd1InRUR / baseInstrument.Instrument.FxRate, 2,
                        MidpointRounding.AwayFromZero);

                    return new InstrumentSelectorResult
                    {
                        BaseInstrumentPosition = baseInstrument,
                        InstrumentPosition = x.Key,
                        Quantity = x.Value,
                        Rate = rateProvider.GetRate(new RateKey
                        {
                            ClientCode = clientCode,
                            InstrumentType = x.Key.Instrument.InstrumentType,
                            Currency = currency,
                            Volume = volume,
                            TariffId = x.Key.Instrument.TariffId
                        })
                    };
                }).ToArray();
        }
    }
}
