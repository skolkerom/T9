﻿using System;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class Instrument
    {
        public string InstrumentCode { get; set; }
        public decimal Price { get; set; }
        public string CurrencyCode { get; set; }
        public decimal FxRate { get; set; }
        
        public DateTime Repo1Date { get; set; }
        public DateTime Repo2Date { get; set; }
        
        public decimal? Nkd1 { get; set; }
        public decimal? Nkd2 { get; set; }
        
        public int? TariffId { get; set; }
        
        public OvernightDistributionInstrumentType InstrumentType { get; set; }
        
        public decimal LotSize => InstrumentType == OvernightDistributionInstrumentType.Security
            ? 1M
            : 0.01M;

        public decimal PriceWithNkd1 => Price + (Nkd1 ?? 0);
        public decimal PriceWithNkd2 => Price + (Nkd2 ?? 0);
        
        public bool ExcludeForIndividualInvestmentAccount { get; set; }
        
        public decimal PriceWithNkd1InRUR => CurrencyCode.IsRUB() ? PriceWithNkd1 : PriceWithNkd1 * FxRate;
        public decimal PriceWithNkd2InRUR => CurrencyCode.IsRUB() ? PriceWithNkd1 : PriceWithNkd1 * FxRate;
        
        public decimal GetCommission(decimal rate) => (PriceWithNkd1 * rate) * DateDiff / (DateTime.IsLeapYear(DateTime.Now.Year) ? 366 : 365);

        public int DateDiff => Math.Max(1, (Repo2Date.Date - Repo1Date.Date).Days);
        
        public decimal GetEffectiveRate(decimal rate)
        {
            return rate * DateDiff / 365M;
        }
        
        public decimal GetCommissionInRUR(decimal rate) => CurrencyCode.IsRUB() ? GetCommission(rate) : GetCommission(rate) * FxRate;

        public decimal CalculateMinimalCommission(decimal sumToCover, decimal rate)
        {
            return MathExtensions.Ceiling(Math.Abs(sumToCover) / PriceWithNkd1InRUR, LotSize) * GetCommissionInRUR(rate);
        }

        public override string ToString()
        {
            return
                $"InstrumentCode = {InstrumentCode} InstrumentType = {InstrumentType} Price = {Price} CurrencyCode = {CurrencyCode} FxRate = {FxRate} Repo1Date = {Repo1Date} Repo2Date = {Repo2Date} Nk1 = {Nkd1} Nkd2 = {Nkd2} TariffId = {TariffId}";
        }
    }
}