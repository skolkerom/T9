﻿using System;
using System.Linq;

namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class RateProvider
    {
        private readonly ILookup<string, Rate> _ratesByClientCodeLookup;
        private readonly Rate[] _defaultRates;

        public RateProvider(Rate[] rates)
        {
            _ratesByClientCodeLookup = rates.ToLookup(x => x.ClientCode);

            _defaultRates = rates.Where(x => x.ClientCode == null).ToArray();
        }

        /// <summary>
        /// Вычисляет ставку на основе приоритетов атрибутов (в порядке убывания значимости): Клиент, Валюта, Тип инструмента<br/>
        /// Если приоритеты равны возвращает максимальную ставку<br/>
        /// Если volume не указан возвращает максимальную ставку<br/>
        /// </summary>
        public Rate GetRate(RateKey rateKey)
        {
            //в базе максимальная константа 1000000000
            if (rateKey.Volume > 1000000000)
                rateKey.Volume = 1000000000;
            
            var maxPoints = 0;
            var maxRate = 0M;
            var initialRate = new Rate
            {
                Rate1 = 0,
                Rate2 = 0
            };

            var bestRate = initialRate; 

            var rates = _ratesByClientCodeLookup[rateKey.ClientCode].Concat(_defaultRates);

            foreach (var rate in rates)
            {     
                if(rate.InstrumentType != rateKey.InstrumentType)
                    continue;
                
                if(!string.IsNullOrWhiteSpace(rate.PaymentCurrency) && rate.PaymentCurrency != rateKey.Currency)
                    continue;

                if (rate.TariffId != null && rate.TariffId != rateKey.TariffId)
                    continue;
                
                var points = 0;
                    
                if (rate.ClientCode == rateKey.ClientCode)
                    points += 1000;

                if (rate.PaymentCurrency == rateKey.Currency)
                    points += 100;

                if (rateKey.TariffId != null && rate.TariffId == rateKey.TariffId)
                    points += 10;
                    
                if (rateKey.Volume != null)
                {
                    if(rate.VolumeFrom > rateKey.Volume || rate.VolumeTo < rateKey.Volume)
                        continue;
                }
                
                if (points > maxPoints)
                {
                    maxPoints = points;
                    bestRate = rate;
                    maxRate = rate.Rate1;
                }
                else if (points == maxPoints)
                {
                    if (rate.Rate1 + rate.Rate2 > maxRate)
                    {
                        maxRate = rate.Rate1 + rate.Rate2;
                        bestRate = rate;
                    }
                }
            }

            if (initialRate == bestRate)
                throw new Exception(
                    $"Rate not found. ClientCode = {rateKey.ClientCode}, instrumentType = {rateKey.InstrumentType}, currency = {rateKey.Currency}, volume ={rateKey.Volume}");

            return bestRate;
        }
    }
}