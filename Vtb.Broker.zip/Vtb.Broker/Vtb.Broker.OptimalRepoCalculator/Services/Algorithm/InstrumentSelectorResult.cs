namespace Vtb.Broker.OptimalRepoCalculator.Services.Algorithm
{
    public class InstrumentSelectorResult
    {
        public InstrumentPosition BaseInstrumentPosition { get; set; }
        public InstrumentPosition InstrumentPosition { get; set; }
        public decimal Quantity { get; set; }
        public Rate Rate { get; set; }
    }
}
