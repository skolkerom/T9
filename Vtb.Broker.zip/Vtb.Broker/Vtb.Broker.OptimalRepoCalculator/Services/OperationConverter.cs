﻿using System;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator.Services
{
    public class OperationConverter
    {
        private readonly ILogger<OvernightDistributionGenerator> _logger;

        public OperationConverter(
            ILogger<OvernightDistributionGenerator> logger)
        {
            _logger = logger;
        }

        public OvernightDistributionOperation ConvertToOvernightOperation(InstrumentSelectorResult x)
        {
            var fx = x.InstrumentPosition.Instrument.FxRate /
                     x.BaseInstrumentPosition.Instrument.FxRate;

            var rateRepo1 = x.InstrumentPosition.Instrument.GetEffectiveRate(x.Rate.Rate2);

            var commissionRepo1 = x.Quantity * x.InstrumentPosition.Instrument.PriceWithNkd1 * rateRepo1 * fx;

            var volumeRepo1 = Math.Round(x.Quantity * x.InstrumentPosition.Instrument.PriceWithNkd1 * fx, 2,
                MidpointRounding.AwayFromZero);

            var rateRepo2 = x.InstrumentPosition.Instrument.GetEffectiveRate(x.Rate.Rate1);

            var repo2Price = (x.InstrumentPosition.Instrument.PriceWithNkd1 * (1 + rateRepo2) -
                              (x.InstrumentPosition.Instrument.Nkd2 ?? 0))
                             * fx;

            var repo1Price = x.InstrumentPosition.Instrument.Price * fx;

            var nkd1 = x.Quantity * (x.InstrumentPosition.Instrument.Nkd1 ?? 0) * fx;

            var nkd2 = x.Quantity * (x.InstrumentPosition.Instrument.Nkd2 ?? 0) * fx;

            var volumeRepo2 = Math.Round((repo2Price + (x.InstrumentPosition.Instrument.Nkd2 ?? 0) * fx) * x.Quantity,
                2, MidpointRounding.AwayFromZero);

            var commissionRepo2 = volumeRepo2 - volumeRepo1;

            _logger.LogInformation($@"ClientCode = {x.InstrumentPosition.ClientCode}
StorageId = {x.InstrumentPosition.StorageId}
Quantity = {x.Quantity}
Rate = {x.Rate}
BaseInstrument = {x.BaseInstrumentPosition.Instrument}
Instrument = {x.InstrumentPosition.Instrument}
FX = {fx}
Repo1Rate = {rateRepo1}
Repo2Rate = {rateRepo2}
CommissionRepo1 = {commissionRepo1}
CommissionRepo2 = {commissionRepo2}
Repo1Price = {repo1Price}
Repo2Price = {repo2Price}
Nkd1 = {nkd1}
Nkd2 = {nkd2}
Repo2Volume = {volumeRepo2}
Repo1Volume = {volumeRepo1}
");
            return new OvernightDistributionOperation
            {
                InstrumentCode = x.InstrumentPosition.Instrument.InstrumentCode,
                Quantity = x.Quantity,
                PriceRepo1 = repo1Price,
                PriceRepo2 = repo2Price,
                Currency = x.InstrumentPosition.Instrument.CurrencyCode,
                FX = x.InstrumentPosition.Instrument.FxRate,
                CommissionRepo1 = Math.Round(commissionRepo1, 2, MidpointRounding.AwayFromZero),
                CommissionRepo2 = Math.Round(commissionRepo2, 2, MidpointRounding.AwayFromZero),
                BaseInstrumentCode = x.BaseInstrumentPosition.Instrument.InstrumentCode,
                BaseInstrumentFX = x.BaseInstrumentPosition.Instrument.FxRate,
                InstrumentType = x.InstrumentPosition.Instrument.InstrumentType,
                OperationType = x.InstrumentPosition.Instrument.InstrumentType ==
                                OvernightDistributionInstrumentType.Currency
                    ? OvernightDistributionOperationType.Swap
                    : OvernightDistributionOperationType.Repo,
                Volume1 = volumeRepo1,
                Volume2 = volumeRepo2,
                BaseInstrumentStorageId = x.BaseInstrumentPosition.StorageId,
                InstrumentStorageId = x.InstrumentPosition.StorageId,
                Nkd1 = nkd1,
                Nkd2 = nkd2
            };
        }
    }
}