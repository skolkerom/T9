using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Interfaces.Audit;
using Vtb.Broker.Interfaces.Audit.Entities;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Commands;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries;

namespace Vtb.Broker.OptimalRepoCalculator.Services
{
    public class Orchestrator
    {
        private readonly IOptimalRepoUnitOfWorkFactory _uowFactory;
        private readonly IAuditService _auditService;
        private readonly IRepoQueryRepository _repoQueryRepository;
        private readonly ICurrentUserProvider _currentUserProvider;

        public Orchestrator(IOptimalRepoUnitOfWorkFactory uowFactory,
            IAuditService auditService,
            IRepoQueryRepository repoQueryRepository, ICurrentUserProvider currentUserProvider)
        { 
            _uowFactory = uowFactory;
            _auditService = auditService;
            _repoQueryRepository = repoQueryRepository;
            _currentUserProvider = currentUserProvider;
        }

        public async Task<OvernightDistribution> GenerateRepoOperationsAndSaveResults(DateTime date,
            string clientCode = null, int? requestId = null)
        {
            var user = _currentUserProvider.GetCurrentUser();
            
            var overnightDistribution = await _repoQueryRepository.GetRepoData(date, clientCode, requestId);

            overnightDistribution.User = user.Login;

            var overnightOperations = overnightDistribution.OvernightDistributionOperations.ToArray();
            var positionDistribution = overnightDistribution.OvernightDistributionPositions.ToArray();

            using var uow = _uowFactory.Get();

            var commandRepository = uow.GetRepository<IOvernightDistributionCommandRepository>();
            
            overnightDistribution.OvernightDistributionPositions = null;
            overnightDistribution.OvernightDistributionOperations = null;
            await commandRepository.Save(overnightDistribution);

            foreach (var x in overnightOperations)
                x.OvernightDistributionId = overnightDistribution.Id;

            foreach (var p in positionDistribution)
                p.OvernightDistributionId = overnightDistribution.Id;

            await commandRepository.Save(overnightOperations);            
            await commandRepository.Save(positionDistribution);

            overnightDistribution.EndDate = DateTime.Now;

            await commandRepository.Save(overnightDistribution);

            if (requestId != null)
                await commandRepository.MapDistributionsToZFrontOperations(requestId.Value);

            await _auditService.SaveAsync(new Audit
            {
                User = User.SystemUser.Login,
                Message = $"Date = {date:dd.MM.yyyy}, ClientCode = {clientCode}, RequestId = {requestId}",
                ActionType = AuditActionType.OvernightRepoGeneration
            });
            
            return overnightDistribution;
        }
    }
}
