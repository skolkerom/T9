﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Commands;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries;

namespace Vtb.Broker.OptimalRepoCalculator.Services
{
    public class RepoOnlineDataSaver
    {
        private readonly IRepoQueryRepository _repoQueryRepository;
        private readonly IRepoCommandRepository _repoCommandRepository;

        public RepoOnlineDataSaver(IRepoQueryRepository repoQueryRepository, IRepoCommandRepository repoCommandRepository)
        {
            _repoQueryRepository = repoQueryRepository;
            _repoCommandRepository = repoCommandRepository;
        }
        
        public async Task Save()
        {
            var repoData = await _repoQueryRepository.GetRepoData(DateTime.Now.Date, null, null);

            var curRepoData = GetCurrencyRepoData(repoData.OvernightDistributionPositions);

            var secRepoData = GetSecurityRepoData(repoData.OvernightDistributionOperations);

            await _repoCommandRepository.Save(curRepoData);
            await _repoCommandRepository.Save(secRepoData);
        }

        private static RepoOnlineSecurity[] GetSecurityRepoData(List<OvernightDistributionOperation> operations)
        {
            return (from o in operations
                    where o.OperationType == OvernightDistributionOperationType.Repo
                    group o by new {o.InstrumentCode, o.BaseInstrumentCode}
                    into og
                    select new RepoOnlineSecurity
                    {
                        BaseInstrumentCode = og.Key.BaseInstrumentCode,
                        InstrumentCode = og.Key.InstrumentCode,
                        Quantity = og.Sum(o => o.Quantity),
                        Volume = og.Sum(o => o.Volume1)
                    }).ToArray();
        }

        private static RepoOnlineCurrency[] GetCurrencyRepoData(List<OvernightDistributionPosition> positions)
        {
            return (from r in positions
                where r.PositionStart < 0
                group r by r.InstrumentCode
                into rg
                select new RepoOnlineCurrency
                {
                    Currency = rg.Key, 
                    Position = rg.Sum(r => r.PositionStart)
                }).ToArray();
        }
    }
}