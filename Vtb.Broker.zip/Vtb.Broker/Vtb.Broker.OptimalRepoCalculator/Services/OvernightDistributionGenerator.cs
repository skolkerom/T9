﻿using System;
using System.Linq;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.OptimalRepoCalculator.DAL;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;
using Vtb.Broker.Utils;

namespace Vtb.Broker.OptimalRepoCalculator.Services
{
    public class OvernightDistributionGenerator
    {
        private readonly RepoOperationGenerator _repoOperationGenerator;
        private readonly OperationConverter _converter;

        public OvernightDistributionGenerator(RepoOperationGenerator repoOperationGenerator, OperationConverter converter)
        {
            _repoOperationGenerator = repoOperationGenerator;
            _converter = converter;
        }
        
        public OvernightDistribution GenerateOvernightDistribution(DateTime date, InstrumentPosition[] instrumentPositions, Rate[] rates, int? requestId)
        {
            var ratesProvider = new RateProvider(rates);

            var clients = instrumentPositions.Select(x => x.ClientCode).Distinct();

            var overnightDistribution = new OvernightDistribution
            {
                Date = date.Date,
                RequestId = requestId
            };

            var positionDistribution = instrumentPositions
                .Select(x => new OvernightDistributionPosition
                {
                    ClientCode = x.ClientCode,
                    InstrumentCode = x.Instrument.InstrumentCode,
                    Currency = x.Instrument.CurrencyCode,
                    PositionStart = x.Quantity,
                    PositionEnd = x.Quantity,
                    InstrumentType = x.Instrument.InstrumentType,
                    StorageId = x.StorageId
                })
                .ToDictionary(x => new PositionKey(x.ClientCode, x.InstrumentCode, x.Currency, x.StorageId));

            var repoOperations = clients.AsParallel().Select(client =>
            {
                var posByClient = instrumentPositions.Where(x => x.ClientCode == client).ToArray();

                return new
                {
                    ClientCode = client,
                    Result = _repoOperationGenerator.GenerateRepoOperations(posByClient, ratesProvider, client)
                };
            }).ToArray();

            var overnightOperations = repoOperations.SelectMany(item =>
                item.Result.CalcResults.Select(x =>
                {
                    var detail =  _converter.ConvertToOvernightOperation(x);

                    detail.OvernightDistribution = overnightDistribution;
                    detail.ClientCode = item.ClientCode;
                    return detail;
                })).ToArray();

            repoOperations
                .SelectMany(x => x.Result.Positions
                    .Select(z => new {Position = z, x.ClientCode}))
                .ForEachEx(x =>
                    positionDistribution[x.Position.Key].PositionEnd = x.Position.Value.Quantity);
            
            overnightDistribution.OvernightDistributionOperations.AddRange(overnightOperations);
            overnightDistribution.OvernightDistributionPositions.AddRange(positionDistribution.Values);

            return overnightDistribution;
        }
    }
}