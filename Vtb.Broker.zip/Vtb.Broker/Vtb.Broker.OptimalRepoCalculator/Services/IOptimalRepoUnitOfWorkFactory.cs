using Vtb.Broker.Interfaces.UnitOfWork;

namespace Vtb.Broker.OptimalRepoCalculator.Services
{
    public interface IOptimalRepoUnitOfWorkFactory : IUnitOfWorkFactory
    {
        
    }
}
