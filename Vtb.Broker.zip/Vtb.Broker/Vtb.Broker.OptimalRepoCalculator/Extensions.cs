namespace Vtb.Broker.OptimalRepoCalculator
{
    public static class Extensions
    {
        public static bool IsRUB(this string currency)
        {
            return currency == "RUR" || currency == "RUB";
        }
    }
}
