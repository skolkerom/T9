using System;

namespace Vtb.Broker.OptimalRepoCalculator
{
    public static class MathExtensions
    {
        public static decimal Ceiling(this decimal number, decimal precision)
        {
            return Math.Ceiling(number / precision) * precision;
        }

        public static decimal Floor(this decimal number, decimal precision)
        {
            return Math.Floor(number / precision) * precision;
        }
    }
}
