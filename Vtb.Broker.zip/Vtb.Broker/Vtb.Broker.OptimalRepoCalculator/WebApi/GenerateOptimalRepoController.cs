﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Vtb.Broker.Domain.Entities.Interfaces;
using Vtb.Broker.Interfaces.Integration.OptimalRepoCalculator;
using Vtb.Broker.OptimalRepoCalculator.Services;

namespace Vtb.Broker.OptimalRepoCalculator.WebApi
{
    [ApiController]
    [Route("[controller]")]
    public class GenerateOptimalRepoController
    {
        private readonly Orchestrator _orchestrator;

        public GenerateOptimalRepoController(Orchestrator orchestrator)
        {
            _orchestrator = orchestrator;
        }

        [HttpPost]
        [Route(API.RunOvernightDistrubutionUrl)]
        [Authorize]
        public async Task<long> Post([FromBody]RunOvernightDistributionParameters optimalRepoParameter)
        {
            var date = optimalRepoParameter.Date;
            var clientCode = optimalRepoParameter.ClientCode;
            var requestId = optimalRepoParameter.RequestId;
            
            return (await _orchestrator.GenerateRepoOperationsAndSaveResults(date, clientCode, requestId)).Id;
        }
    }
}