﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.OptimalRepoCalculator.DAL;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Commands;
using Vtb.Broker.OptimalRepoCalculator.DAL.Repositories.Queries;
using Vtb.Broker.OptimalRepoCalculator.Jobs;
using Vtb.Broker.OptimalRepoCalculator.Services;
using Vtb.Broker.OptimalRepoCalculator.Services.Algorithm;

namespace Vtb.Broker.OptimalRepoCalculator
{
    public static class IocConfigurator
    {
        public static void RegisterServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IOptimalRepoUnitOfWorkFactory, OptimalRepoUnitOfWorkFactory>();

            services.AddTransient<OptimalRepoUnitOfWork>();
            services.AddScoped<RepoOperationGenerator>();
            services.AddScoped<ISecurityQueryRepository, SecurityQueryRepository>();
            services.AddScoped<IPositionQueryRepository, PositionQueryRepository>();
            services.AddScoped<ICurrencyRateQueryRepository, CurrencyRateQueryRepository>();
            services.AddScoped<IOvernightDistributionCommandRepository, OvernightDistributionCommandRepository>();
            services.AddScoped<IRepoQueryRepository, RepoQueryRepository>();
            services.AddScoped<IRepoCommandRepository, RepoCommandRepository>();
            
            var connectionString = configuration.GetConnectionString(ConnectionStringsNames.DefaultConnection);

            services.AddSingleton<IContextFactory<Context>>(container =>
                new ContextFactory<Context>(() => new Context(connectionString),
                    container.GetRequiredService<ILoggerFactory>()));

            services.AddTransient<Orchestrator>();
            services.AddTransient<OvernightDistributionGenerator>();
            services.AddTransient<InstrumentSelector>();
            services.AddTransient<OperationConverter>();
            services.AddTransient<RepoOnlineDataSaver>();
            
            services.AddTransient<CreateOvernightDistrubutionJob>();
            services.AddTransient<RepoOnlineDataJob>();
        }    
    }
}
