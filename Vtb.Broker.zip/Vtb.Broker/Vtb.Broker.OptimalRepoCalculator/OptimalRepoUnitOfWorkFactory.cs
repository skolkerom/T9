using System;
using Vtb.Broker.Infrastructure.EF;
using Vtb.Broker.OptimalRepoCalculator.Services;

namespace Vtb.Broker.OptimalRepoCalculator
{
    public class OptimalRepoUnitOfWorkFactory : UnitOfWorkFactory<OptimalRepoUnitOfWork>, IOptimalRepoUnitOfWorkFactory
    {
        public OptimalRepoUnitOfWorkFactory(IServiceProvider serviceProvider) 
            : base(serviceProvider)
        {
        }
    }
} 
