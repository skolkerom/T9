﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.OptimalRepoCalculator.Migrations
{
    public partial class OptimalRepoCalculator_NkdPrecision : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "PositionStart",
                schema: "rm",
                table: "OvernightDistributionPosition",
                type: "decimal(19,2)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.AlterColumn<decimal>(
                name: "PositionEnd",
                schema: "rm",
                table: "OvernightDistributionPosition",
                type: "decimal(19,2)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.AlterColumn<decimal>(
                name: "Nkd2",
                schema: "rm",
                table: "OvernightDistributionOperation",
                type: "decimal(38,15)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)",
                oldNullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "Nkd1",
                schema: "rm",
                table: "OvernightDistributionOperation",
                type: "decimal(38,15)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)",
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<decimal>(
                name: "PositionStart",
                schema: "rm",
                table: "OvernightDistributionPosition",
                type: "decimal(18,2)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(19,2)");

            migrationBuilder.AlterColumn<decimal>(
                name: "PositionEnd",
                schema: "rm",
                table: "OvernightDistributionPosition",
                type: "decimal(18,2)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(19,2)");

            migrationBuilder.AlterColumn<decimal>(
                name: "Nkd2",
                schema: "rm",
                table: "OvernightDistributionOperation",
                type: "decimal(18,2)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(38,15)",
                oldNullable: true);

            migrationBuilder.AlterColumn<decimal>(
                name: "Nkd1",
                schema: "rm",
                table: "OvernightDistributionOperation",
                type: "decimal(18,2)",
                nullable: true,
                oldClrType: typeof(decimal),
                oldType: "decimal(38,15)",
                oldNullable: true);
        }
    }
}
