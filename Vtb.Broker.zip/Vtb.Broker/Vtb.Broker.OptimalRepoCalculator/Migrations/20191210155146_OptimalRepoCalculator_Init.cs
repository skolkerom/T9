﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.OptimalRepoCalculator.Migrations
{
    public partial class OptimalRepoCalculator_Init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "rm");

            migrationBuilder.CreateTable(
                name: "OvernightDistribution",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<DateTime>(nullable: false),
                    StartDate = table.Column<DateTime>(nullable: false),
                    EndDate = table.Column<DateTime>(nullable: false),
                    RequestId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OvernightDistribution", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OvernightDistributionOperation",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OvernightDistributionId = table.Column<long>(nullable: false),
                    BaseInstrumentCode = table.Column<string>(nullable: true),
                    BaseInstrumentStorageId = table.Column<int>(nullable: false),
                    BaseInstrumentFX = table.Column<decimal>(type: "decimal(19,8)", nullable: false),
                    ClientCode = table.Column<string>(nullable: true),
                    InstrumentCode = table.Column<string>(nullable: true),
                    InstrumentStorageId = table.Column<int>(nullable: false),
                    Currency = table.Column<string>(nullable: true),
                    FX = table.Column<decimal>(type: "decimal(19,8)", nullable: false),
                    PriceRepo1 = table.Column<decimal>(type: "decimal(38,15)", nullable: false),
                    PriceRepo2 = table.Column<decimal>(type: "decimal(38,15)", nullable: false),
                    Quantity = table.Column<decimal>(type: "decimal(19,8)", nullable: false),
                    Volume1 = table.Column<decimal>(type: "decimal(19,8)", nullable: false),
                    Volume2 = table.Column<decimal>(type: "decimal(19,8)", nullable: false),
                    CommissionRepo1 = table.Column<decimal>(type: "decimal(19,2)", nullable: false),
                    CommissionRepo2 = table.Column<decimal>(type: "decimal(19,2)", nullable: false),
                    InstrumentType = table.Column<byte>(nullable: false),
                    OperationType = table.Column<byte>(nullable: false),
                    Nkd1 = table.Column<decimal>(nullable: true),
                    Nkd2 = table.Column<decimal>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OvernightDistributionOperation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OvernightDistributionOperation_OvernightDistribution_OvernightDistributionId",
                        column: x => x.OvernightDistributionId,
                        principalSchema: "rm",
                        principalTable: "OvernightDistribution",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OvernightDistributionPosition",
                schema: "rm",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OvernightDistributionId = table.Column<long>(nullable: false),
                    ClientCode = table.Column<string>(nullable: false),
                    InstrumentType = table.Column<byte>(nullable: false),
                    InstrumentCode = table.Column<string>(nullable: false),
                    Currency = table.Column<string>(nullable: false),
                    PositionStart = table.Column<decimal>(nullable: false),
                    PositionEnd = table.Column<decimal>(nullable: false),
                    StorageId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OvernightDistributionPosition", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OvernightDistributionPosition_OvernightDistribution_OvernightDistributionId",
                        column: x => x.OvernightDistributionId,
                        principalSchema: "rm",
                        principalTable: "OvernightDistribution",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OvernightDistributionOperation_OvernightDistributionId",
                schema: "rm",
                table: "OvernightDistributionOperation",
                column: "OvernightDistributionId");

            migrationBuilder.CreateIndex(
                name: "IX_OvernightDistributionPosition_OvernightDistributionId",
                schema: "rm",
                table: "OvernightDistributionPosition",
                column: "OvernightDistributionId");
            
            migrationBuilder.CreateIndex(
                name: "IX_OvernightDistribution_RequestId",
                schema: "rm",
                table: "OvernightDistribution",
                column: "RequestId",
                unique: true,
                filter: "RequestId is not null");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OvernightDistributionOperation",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "OvernightDistributionPosition",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "OvernightDistribution",
                schema: "rm");
        }
    }
}
