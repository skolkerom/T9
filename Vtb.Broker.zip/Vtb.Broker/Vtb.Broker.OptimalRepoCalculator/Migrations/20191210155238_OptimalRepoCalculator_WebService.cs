﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.OptimalRepoCalculator.Migrations
{
    public partial class OptimalRepoCalculator_WebService : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var dir = MigrationExtensions.GetSqlScriptsDirectory();
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Procedures", "sp_zfront_generate_optimal_repo.sql")));
            migrationBuilder.Sql(File.ReadAllText(Path.Combine(dir, "Procedures", "sp_zfront_generate_optimal_repo_operations.sql")));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            
        }
    }
}
