﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.OptimalRepoCalculator.Migrations
{
    public partial class OptimalRepoCalculator_OvernightDistribution_UserColumn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "User",
                schema: "rm",
                table: "OvernightDistribution",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "User",
                schema: "rm",
                table: "OvernightDistribution");
        }
    }
}
