﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Vtb.Broker.OptimalRepoCalculator.Migrations
{
    public partial class AddRepoOnlineJob : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "RepoOnlineCurrency",
                schema: "rm",
                columns: table => new
                {
                    Currency = table.Column<string>(nullable: false),
                    Position = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RepoOnlineCurrency", x => x.Currency);
                });

            migrationBuilder.CreateTable(
                name: "RepoOnlineSecurity",
                schema: "rm",
                columns: table => new
                {
                    InstrumentCode = table.Column<string>(nullable: false),
                    BaseInstrumentCode = table.Column<string>(nullable: false),
                    Quantity = table.Column<decimal>(nullable: false),
                    Volume = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RepoOnlineSecurity", x => new { x.InstrumentCode, x.BaseInstrumentCode });
                    table.UniqueConstraint("AK_RepoOnlineSecurity_BaseInstrumentCode_InstrumentCode", x => new { x.BaseInstrumentCode, x.InstrumentCode });
                });

            migrationBuilder.Sql(@"insert into rm.JobSchedule(Code, Description, Cron, IsDeleted, ApplicationName)
                    values('RepoOnlineDataJob', 'Update REPO online data', '0 */15 10-21 * * ?', 0, 'OptimalRepoCalculator')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RepoOnlineCurrency",
                schema: "rm");

            migrationBuilder.DropTable(
                name: "RepoOnlineSecurity",
                schema: "rm");
        }
    }
}
