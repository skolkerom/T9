﻿using System.IO;
using Microsoft.EntityFrameworkCore.Migrations;
using Vtb.Broker.Utils;

namespace Vtb.Broker.OptimalRepoCalculator.Migrations
{
    public partial class FixGenerateOptimalRepoProcedure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var script = Path.Combine(MigrationExtensions.GetSqlScriptsDirectory(), "Procedures", "sp_zfront_generate_optimal_repo_operations.sql");
            migrationBuilder.Sql(File.ReadAllText(script));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
