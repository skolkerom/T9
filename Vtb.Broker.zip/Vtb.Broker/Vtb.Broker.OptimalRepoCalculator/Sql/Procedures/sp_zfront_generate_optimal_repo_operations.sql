-- Процедура генерации сделок внебиржевого валютного РЕПО
-- 2019-12-11 / BR-18580 / Вишняков Р.Н.

create or alter procedure [rm].[sp_zfront_generate_optimal_repo_operations] @requestId bigint
as 
begin 
	set nocount on

   if(object_id('tempdb..#RepoSecurities') is not null)
      drop table #RepoSecurities 

   create table #RepoSecurities(
     InstrumentId        int not null,  
     InstrumentCode      varchar(30) collate database_default not null,
     IsPercentPrice      bit, 
     AveragePriceShort    decimal(19, 6) null,
     AveragePriceDateShort date null, 
     AveragePriceLong        decimal(19, 6) null,
     AveragePriceDateLong     date null, 
     Ccy              char(3) collate database_default null, 
     CcyRate           decimal(19, 6) null, 
     CcyRateDate        datetime null, 
     Nominal           decimal(19, 6)  null, 
     AmortizationFactor1  decimal(19, 10) null, 
     AmortizationFactor2  decimal(19, 10) null, 
     NkdAtPart1ValueDate  decimal(19, 10) null, 
     NkdAtPart2ValueDate  decimal(19, 10) null, 
     IsCurrencyMarket        bit not null default(0),
     TypeRateRepo           int null  default(0),
     DealTimeValueDate    datetime null,
     DealTimeValueTime    time null,
     DealValPart1ValueDate datetime,
     DealValPart2ValueDate datetime,
     DealPart1ValueDate   datetime null, 
     DealPart1ValueTime   time null,    
     DealPart2ValueDate   datetime null, 
     DealPart2ValueTime   time null, 
     DealPayPart1ValueDate datetime null, 
     DealPayPart1ValueTime time null, 
     DealPayPart2ValueDate datetime null, 
     DealPayPart2ValueTime time null)
     
   declare @repoDate datetime
   
   select @repoDate = d.Date 
        from rm.OvernightDistribution d 
        where d.RequestId = @requestId
        
   exec VN_REPO_Securities @date = @repoDate, @type = 2 

   if(object_id('tempdb..#Counterparty') is not null)
      drop table #Counterparty

   create table #Counterparty(CounterpartyCode nvarchar(max) collate database_default)
   
   insert #Counterparty
   exec VN_REPO_Tech_Company @repoDate

   declare @PlaceId int

   select @PlaceId = place_id 
   from v_instruments where id = 200164

   if(object_id('tempdb..#RepoOperations') is not null)
      drop table #RepoOperations

   ;with Operations as
   (select 'repo_bnd' as SchemeId, 
         'SER'+ right('00000000' + cast(ROW_NUMBER() over(order by o.Id) as varchar(max)), 8) as SerId,  
         @PlaceId as PlaceId,
         r.DealTimeValueDate + cast(r.DealTimeValueTime as datetime) as DealDate,
         r.DealPart1ValueDate + cast(r.DealPart1ValueTime as datetime) as DeliveryPart1Date,
         r.DealPayPart1ValueDate + cast(r.DealPayPart1ValueTime as datetime) as PaymentPart1Date,
         r.DealPart2ValueDate + cast(r.DealPart2ValueTime as datetime) as DeliveryPart2Date,
         r.DealPayPart2ValueDate + cast(r.DealPayPart2ValueTime as datetime) as PaymentPart2Date,
         c.currency_code as CurrencyCode, 
         cp.CounterpartyCode, 
         o.Id, 
         o.OvernightDistributionId, 
         o.BaseInstrumentCode, 
         o.BaseInstrumentFX, 
         o.ClientCode, 
         o.InstrumentCode, 
         o.Currency, 
         o.FX, 
         o.PriceRepo1, 
         o.PriceRepo2, 
         o.Quantity, 
         o.CommissionRepo1, 
         o.CommissionRepo2, 
         o.InstrumentType, 
         o.OperationType, 
         o.Volume1, 
         o.Volume2, 
         round(o.Nkd1, 2) Nkd1,         
         case 
            --если из за округления НКД 2 и 1 оказались одинаковые добавим один цент ко второй части
            when o.Nkd2 > 0 and round(o.Nkd2, 2) = round(o.Nkd1, 2) then round(o.Nkd2, 2) + 0.01
            else round(o.Nkd2, 2)
         end Nkd2,
         o.BaseInstrumentStorageId, 
         o.InstrumentStorageId, 
         d.Date, 
         d.RequestId
   from rm.OvernightDistributionOperation o
   join rm.OvernightDistribution d on o.OvernightDistributionId = d.Id
   join v_currency c on c.ISO = o.BaseInstrumentCode 
   join #RepoSecurities r on r.InstrumentCode = o.InstrumentCode
   cross join #Counterparty cp
   where d.RequestId = @requestId and OperationType = 1) --генерируем только РЕПО, СВОПы пропускаем

   insert into tt_deals_repo_VN(
      b_s,
      doc_id,
      original_doc_id,
      sheme_id,
      client_code,
      qty,
      price,
      date,
      id,
      place_id,
      deliv_date,
      paym_date,
      nkd,
      cts,
      fee,
      porto,
      currency_code,
      storage_id,
      volume)
   /* Client repo part 1 */
   select 'S' as BuySell,                                 
         SerId + '-1' as DocId,
         SerId + '-1' as OrgDocId, 
         SchemeId,
         ClientCode, 
         Quantity, 
         PriceRepo1 as Price, 
         DealDate,
        InstrumentId, 
         PlaceId,
         DeliveryPart1Date as DeliveryDate,
         PaymentPart1Date as PaymentDate,
         o.Nkd1 as Nkd, 
         RequestId as Cts, 
         CommissionRepo1 as Fee,
         CounterpartyCode as Porto, 
         CurrencyCode, 
         InstrumentStorageId,
         Volume1 as Volume
      from Operations o
      join #RepoSecurities r on r.InstrumentCode = o.InstrumentCode
   union all
   /* Client repo part 2 */
   select 'B' as BuySell, 
         SerId + '-3' as DocId, 
         SerId + '-3' as OrgDocId, 
         SchemeId,
         ClientCode, 
         Quantity, 
         PriceRepo2 as Price,
         DealDate, 
         r.InstrumentId, 
         PlaceId,
         DeliveryPart2Date as DeliveryDate,
         PaymentPart2Date as PaymentDate,
         o.Nkd2 as Nkd,
         RequestId as Cts, 
         --CommissionRepo2 as Fee,
         0 as Fee, 
         CounterpartyCode as Porto, 
         CurrencyCode, 
         InstrumentStorageId,
         Volume2
      from Operations o
      join #RepoSecurities r on r.InstrumentCode = o.InstrumentCode
   union all
   /* Counterparty repo part 1 */
   select 'B', 
         SerId + '-2', 
         SerId + '-2' as OrgDocId, 
         SchemeId,
         CounterpartyCode, 
         Quantity, 
         PriceRepo1, 
         DealDate, 
         r.InstrumentId, 
         PlaceId,
         DeliveryPart1Date as DeliveryDate,
         PaymentPart1Date as PaymentDate,
         o.Nkd1 as Nkd,
         RequestId as Cts, 
         --CommissionRepo1 as Fee, 
         0 as Fee,
         ClientCode as Porto, 
         CurrencyCode, 
         InstrumentStorageId,
         Volume1
      from Operations o
      join #RepoSecurities r on r.InstrumentCode = o.InstrumentCode
   union all
   /* Counterparty repo part 2 */
   select 'S', 
         SerId + '-4', 
         SerId + '-4', 
         SchemeId,
         CounterpartyCode, 
         Quantity, 
         PriceRepo2, 
         DealDate, 
         r.InstrumentId, 
         PlaceId,
         DeliveryPart2Date as DeliveryDate,
         PaymentPart2Date as PaymentDate,
         o.Nkd2 as Nkd,
         RequestId as Cts, 
         --CommissionRepo2 as Fee, 
         0 as Fee,
         ClientCode as Porto, 
         CurrencyCode, 
         InstrumentStorageId,
         Volume2
      from Operations o
      join #RepoSecurities r on r.InstrumentCode = o.InstrumentCode
end
