-- Процедура вызова веб-сервиса для генерации РЕПО
-- 2019-12-11 / BR-18580 / Абакумов О.В.

create or alter proc [rm].[sp_zfront_generate_optimal_repo]
    @date date,
    @clientCode varchar(255) = null,
    @requestId int = null
as
set nocount on
begin try
  
  declare @response nvarchar(max) = null
  declare @url nvarchar(max) = null
  declare @request nvarchar(max) = 
    (select @date as [date], @clientCode as clientCode, @requestId as requestId for json path, without_array_wrapper)
  declare @timeout int = 20 * 60 * 1000

  select @url = Host from rm.Endpoint where Code='OptimalRepoCalculator'

  set @url = @url + '/GenerateOptimalRepo'
  
  declare @token varchar(max)

  declare @newLine varchar(2) =  CHAR(13) + CHAR(10)

  exec [rm].[sp_zfront_get_auth_token] @user = 'zfront_optimal_repo', @password = 'password', @token = @token out

  declare @header nvarchar(max) = 'Content-Type: application/json' + @newLine + 'Authorization: Bearer ' + @token

  exec dbo.sp_http_request
         @url        = @url,
         @method     = 'POST',
         @header     = @header output,
         @timeout    = @timeout,
         @request    = @request,
         @response   = @response output

end try
begin catch
    declare @error varchar(max) = error_message()
    set @response = 'Адрес URL: ' + isnull(@url, '') + @newLine + 'Параметры вызова сервиса: ' + isnull(@request, '') + @newLine
    set @error = @response + @error
    raiserror(@error, 16, 1)
end catch
