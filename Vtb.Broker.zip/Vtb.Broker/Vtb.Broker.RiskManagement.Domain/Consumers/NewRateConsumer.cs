using System.Linq;
using System.Threading.Tasks;
using Vtb.Broker.Utils;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Services;

namespace Vtb.Broker.RiskManagement.Domain.Consumers
{
    public class NewRateConsumer : IConsumer<RiskRate[]>
    {
        private readonly IRiskRateService _riskRateService;

        public NewRateConsumer(IRiskRateService riskRateService)
        {
            _riskRateService = riskRateService;
        }

        public async Task Consume(MessageContext<RiskRate[]> messageContext)
        {
            if (messageContext.Message.Any())
            {
                var source = messageContext.Message.First().Source;
                await _riskRateService.SaveAsync(messageContext.Message, source);
            }
        }
    }
}