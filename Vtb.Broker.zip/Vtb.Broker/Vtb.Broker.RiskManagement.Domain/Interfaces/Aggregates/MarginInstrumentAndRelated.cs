﻿namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Aggregates
{
    public class MarginInstrumentAndRelated
    {
        
    }
}