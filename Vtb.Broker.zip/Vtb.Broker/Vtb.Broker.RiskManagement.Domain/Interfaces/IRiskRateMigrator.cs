﻿using System;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces
{
    public interface IRiskRateMigrator
    {
        void Migrate();
    }
}
