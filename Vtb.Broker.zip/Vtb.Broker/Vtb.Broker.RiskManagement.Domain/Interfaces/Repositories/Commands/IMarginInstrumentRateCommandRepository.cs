﻿using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Interfaces.Mapper;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IMarginInstrumentRateCommandRepository
    {
        Task SaveAsync(MarginInstrumentRate[] marginInstrumentRates);
        Task SaveAsEntitiesAsync(MarginInstrumentRate[] marginInstrumentRates);
    }
}