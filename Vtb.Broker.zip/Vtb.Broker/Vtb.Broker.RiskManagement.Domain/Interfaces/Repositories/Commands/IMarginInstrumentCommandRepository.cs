using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IMarginInstrumentCommandRepository
    {
        Task Save(MarginInstrument instrument);
        Task Save(MarginInstrument[] instruments);
    }
}