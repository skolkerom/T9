using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IMarginInstrumentListCommandRepository    
    {
        Task Save(MarginInstrumentList instrumentList);
        Task CreateCopyAsync(MarginInstrumentList instrumentList, long templateId);
    }
}