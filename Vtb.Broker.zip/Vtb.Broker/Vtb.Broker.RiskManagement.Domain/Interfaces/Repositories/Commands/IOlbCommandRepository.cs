using System.Threading.Tasks;
using Vtb.Broker.RiskManagement.Domain.Interfaces.Services;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IOlbCommandRepository
    {
        Task<(string, string)> WcfExecute(string host, string port, OlbServerType serverType, string service, string method, string parameters); 
    }
}
