using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IRiskRateCommandRepository
    {
        Task SaveAsync(RiskRate[] rates);
        Task SaveToOlbAsync(MarginInstrumentRate[] marginRates = null, string listCode = "");
    }
}