﻿using System;
using System.Threading.Tasks;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IMoexRiskRateCommandRepository
    {
        Task SaveMoexRiskFileContent(DateTime date);
    }
}