using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IRiskCategoryCommandRepository
    {
        Task Save(RiskCategory category);
    }
}