﻿using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Alerts.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Commands
{
    public interface IAlertCommandRepository
    {
        Task SaveAsync(AlertEmail entity);
        Task SaveAsync(AlertEmailTemplate entity);
    }
}