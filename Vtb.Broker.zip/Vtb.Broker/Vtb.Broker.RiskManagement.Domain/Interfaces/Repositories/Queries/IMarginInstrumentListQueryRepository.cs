using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IMarginInstrumentListQueryRepository
    {
        Task<MarginInstrumentList[]> GetMarginInstrumentLists();
        Task<MarginInstrumentList[]> GetMarginInstrumentLists(long[] ids);
        Task<MarginInstrumentList> GetMarginInstrumentList(long id);
        Task<MarginInstrumentList[]> GetActiveMarginInstrumentLists();
    }
}