using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IHistoryQueryRepository
    {
        Task<TEntity[]> GetHistory<TEntity>(long id)
            where TEntity : class, IEntity;
    }
}
