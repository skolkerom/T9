using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IInstrumentInMarginInstrumentListQueryRepository
    {
        Task<InstrumentInMarginInstrumentList> GetInstrumentInMarginInstrumentListAsync(long id);
        Task<InstrumentInMarginInstrumentListHistory[]> GetInstrumentInMarginInstrumentListHistoryAsync(long entityId);
        Task<InstrumentInMarginInstrumentList[]> GetInstrumentsInListByInstrumentIdAsync(long marginInstrumentId, long[] listIds);
        Task<InstrumentInMarginInstrumentListImport[]> GetInstrumentInListImportsAsync(Guid fileId);
        Task<InstrumentInMarginInstrumentList[]> GetInstrumentsInListByListIdAsync(long listId);
    }
}