﻿using System.Threading.Tasks;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{

    public interface IZFrontQueryRepository
    {
        Task<string> GetZfInstrumentType(string isin);
    } 
}