using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates.MarginInstrument;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IMarginInstrumentQueryRepository
    {
        Task<MarginInstrument[]> GetMarginInstruments();
        Task<MarginInstrument> GetMarginInstrument(long id);
        Task<MarginInstrument> GetMarginInstrument(string isin);

        Task<MarginInstrumentReestrAggregate[]> GetMarginInstrumentsForReestr();
        Task<MarginInstrumentImport[]> GetMarginInstrumentImports(Guid fileId);
    }
}