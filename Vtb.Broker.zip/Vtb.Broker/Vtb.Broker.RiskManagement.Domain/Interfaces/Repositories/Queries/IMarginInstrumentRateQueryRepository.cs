using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IMarginInstrumentRateQueryRepository
    {
        Task<MarginInstrumentRate[]> GetMarginInstrumentRates(DateTime date, long listId, long? instrumentInListId);
        Task<MarginInstrumentRate[]> GetMarginInstrumentRatesHistory(long instrumentInListId);
        Task<MarginInstrumentRate[]> GetMarginInstrumentRates(DateTime date, MarginInstrumentList[] lists);
    }
}