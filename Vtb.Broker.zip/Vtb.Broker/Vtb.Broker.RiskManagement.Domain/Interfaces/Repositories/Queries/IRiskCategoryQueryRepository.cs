using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IRiskCategoryQueryRepository
    {
        Task<RiskCategory[]> GetRiskCategoriesAsync();
        Task<RiskCategory> GetRiskCategoryAsync(long id);
    }
}