using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IOlbQueryRepository
    {
        Task<OlbSecurity[]> GetOlbSecurities();
        Task<OlbSecurity[]> GetOlbSecuritiesDistinctByShortName();
        Task<OlbParameter[]> GetOlbParameters();
    }
}