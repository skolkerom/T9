using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IRiskRateQueryRepository
    {
        Task<RiskRate> GetRiskRate(long id);
        Task<RiskRate[]> GetActiveRiskRates(string isin, long listId, DateTime rateDate);
        Task<RiskRate[]> GetActiveRiskRates((string isin, DateTime rateDate)[] datesAndIsins);
        Task<RiskRate[]> GetRiskRatesWithIdsAsync(RiskRate[] rates);
        Task<RiskRate[]> GetRiskRates(string isin);
    }
}