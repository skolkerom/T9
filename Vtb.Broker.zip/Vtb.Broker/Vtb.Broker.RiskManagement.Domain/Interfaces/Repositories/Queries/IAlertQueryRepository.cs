﻿using System.Threading.Tasks;
using Vtb.Broker.Interfaces.Alerts.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Repositories.Queries
{
    public interface IAlertQueryRepository
    {
        Task<Alert[]> GetAlerts();
        Task<AlertEmail[]> GetAlertEmails(long id);
        Task<AlertEmailTemplate[]> GetAlertEmailTemplates(long alertId);
        Task<AlertEmail> GetAlertEmail(long id);
        Task<AlertEmailTemplate> GetAlertEmailTemplate(long id);
    }
}