using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.Services
{
    public interface IBoardService
    {
        Task<Board[]> GetBoardsAsync();        
    }


}

