using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates;
using Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public interface IOvernightDistributionOperationQueryRepository
    {
        Task<OvernightDistributionOperation[]> Get(string clientCode, long distributionId);

        Task<OvernightDistributionOperationAggregate[]> GetAggregated(long overnightDistributionId);
    }
}