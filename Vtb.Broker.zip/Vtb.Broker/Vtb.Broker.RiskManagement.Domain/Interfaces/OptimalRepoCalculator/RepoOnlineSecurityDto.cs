﻿namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public class RepoOnlineSecurityDto
    {
        public string InstrumentCode { get; set; }
        public string InstrumentName { get; set; }
        public decimal? UsdValue { get; set; }
        public decimal? UsdQuantity { get; set; }
        public decimal? EurValue { get; set; }
        public decimal? EurQuantity { get; set; }
        public decimal? TotalQuantity { get; set; }
    }
}