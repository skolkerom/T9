using System;
using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public interface IOvernightDistributionService
    {
        Task<OvernightDistribution[]> GetDistributions(DateTime date);

        Task<OvernightDistributionPosition[]> GetPositions(long overnightDistributionId, string clientCode);
        Task<OvernightDistributionPositionAggregate[]> GetAggregatedPositions(long overnightDistributionId);
        Task<OvernightDistributionCurrencyPositionAggregate[]> GetAggregatedCurrencyPositions(long overnightDistributionId);

        Task<OvernightDistributionOperation[]> GetOperations(long overnightDistributionId, string clientCode);

        Task<OvernightDistributionOperationAggregate[]> GetAggregatedOperations(
            long overnightDistributionId);

        Task RunOvernightDistribution(DateTime date, string clientCode);
    }
}