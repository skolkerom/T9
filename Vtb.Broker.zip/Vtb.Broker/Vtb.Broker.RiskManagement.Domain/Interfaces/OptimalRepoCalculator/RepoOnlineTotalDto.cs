﻿using System.Collections;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public class RepoOnlineTotalDto 
    {
        public string Name { get; set; }
        public decimal? UsdValue { get; set; }
        public decimal? EurValue { get; set; }
    }
}