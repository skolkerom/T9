﻿using System;
using System.Threading.Tasks;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public interface IOvernightDistributionCommandRepository
    {
        Task RunOvernightDistribution(DateTime date, string clientCode);
    }
}