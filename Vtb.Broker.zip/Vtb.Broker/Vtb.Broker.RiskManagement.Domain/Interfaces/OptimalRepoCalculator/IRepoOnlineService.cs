﻿using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public interface IRepoOnlineService
    {
        Task<RepoOnlineCurrencyDto[]> GetCurrencyData();
        Task<RepoOnlineSecurityDto[]> GetSecurityData();
        Task<RepoOnlineTotalDto[]> GetRepoOnlineTotal(RepoOnlineCurrencyDto[] cur, RepoOnlineSecurityDto[] sec);
    }
}