using System.Threading.Tasks;
using Vtb.Broker.Domain.Entities;
using Vtb.Broker.Domain.Entities.Aggregates;
using Vtb.Broker.Domain.Entities.Aggregates.OvernightDistribution;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public interface IOvernightDistributionPositionQueryRepository
    {
        Task<OvernightDistributionPosition[]> Get(string clientCode, long distributionId);
        Task<OvernightDistributionPositionAggregate[]> GetAggregated(long distributionId);
        Task<OvernightDistributionCurrencyPositionAggregate[]> GetCurrencyAggregated(long distributionId);
    }
}