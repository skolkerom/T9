﻿namespace Vtb.Broker.RiskManagement.Domain.Interfaces.OptimalRepoCalculator
{
    public class RepoOnlineCurrencyDto
    {
        public decimal? UsdValue { get; set; }
        public decimal? EurValue { get; set; }
    }
}