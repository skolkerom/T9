﻿using System;
using System.Threading.Tasks;

namespace Vtb.Broker.RiskManagement.Domain.Interfaces.MoexRiskRateDownloader
{
    public interface IMoexRiskRateQueryRepository
    {
        Task<byte[]> GetMoexRiskFileContent(DateTime date);
    }
}